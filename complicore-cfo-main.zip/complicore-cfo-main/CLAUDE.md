# CompliCore CFO — Claude Code Build Guide

## Project Overview
A Gemini-powered CFO Agent that ingests real revenue data and generates actionable fiscal reports.

**Stack:** React 19 + Vite 6 + Tailwind 4 + Express + Firebase (Auth + Firestore) + Gemini SDK + Stripe

**Dev server:** `npm run dev` → http://localhost:3000 (Express serves Vite in middleware mode)

**Entry points:**
- Frontend: `src/main.tsx` → `src/App.tsx`
- Backend: `server.ts` (Express + Vite middleware)
- AI service: `src/services/geminiService.ts`
- Firebase: `src/firebase.ts`

---

## Phase Status

| Phase | Name | Status |
|-------|------|--------|
| 0 | Sanitization & Foundation | ✅ COMPLETE |
| **1** | **Data Ingestion (CSV/JSON Upload)** | **🔨 BUILD NOW** |
| 2 | CFO Analysis Service (Gemini) | pending |
| 3 | Actionable Insights Dashboard | pending |
| 4 | Stripe & Auth Hardening | pending |

---

## Phase 1 Specification — Data Ingestion

### Goal
Allow authenticated users to upload CSV or JSON files containing revenue/financial data. Parse, validate, preview, and persist to Firestore. Display all uploaded datasets in the UI.

### Backend Changes (`server.ts`)

Add two endpoints:

1. **POST `/api/upload-revenue`**
   - Accept `multipart/form-data` with a single file field named `file`
   - Accept only `.csv` and `.json` files (reject others with 400)
   - Max file size: 5MB
   - Parse the file:
     - CSV: use `papaparse` npm package → parse to array of objects
     - JSON: `JSON.parse()` → validate it's an array of objects
   - Validate required columns exist (flexible — just check at least one numeric value column exists)
   - Return parsed preview (first 10 rows) + column names + row count
   - Use `multer` for multipart handling

2. **POST `/api/save-revenue-dataset`**
   - Accept JSON body: `{ userId, name, source, rows, columns, rowCount }`
   - Save to Firestore collection `revenueDatasets` (document per dataset)
   - Firestore document shape:
     ```typescript
     {
       id: string,           // auto-generated
       userId: string,
       name: string,         // user-provided dataset name
       source: "csv" | "json",
       columns: string[],
       rowCount: number,
       rows: object[],       // all rows (not just preview)
       uploadedAt: Timestamp
     }
     ```
   - Return `{ id, success: true }`

Install new backend deps:
```bash
npm install multer papaparse
npm install -D @types/multer @types/papaparse
```

### Frontend Changes (`src/`)

#### 1. New component: `src/components/DataUpload.tsx`
A full-featured upload panel with:
- Drag-and-drop zone (accept `.csv`, `.json`)
- File browser button as fallback
- "Dataset Name" text input
- Upload progress indicator (spinner while parsing)
- Preview table (first 10 rows, scrollable) after successful parse
- "Save to Library" button (disabled until parse succeeds)
- Success/error toast using `sonner`
- Clear/reset button

Design: dark glass card, consistent with existing UI tokens (`bg-surface`, `text-on-surface`, `border-white/10`, `primary` accent).

#### 2. New component: `src/components/DatasetLibrary.tsx`
Displays all saved datasets for the current user:
- Fetches from Firestore: `collection(db, 'revenueDatasets')` filtered by `userId`
- Card grid layout (responsive, 1–3 columns)
- Each card shows: name, source badge (CSV/JSON), row count, upload date
- "View" button → opens a modal/sheet with full data table (paginated, 50 rows/page)
- "Delete" button → removes from Firestore with confirmation

#### 3. Add a new nav item in `App.tsx`
Add "Data Library" to the sidebar navigation (use `Database` icon from lucide-react).
Wire it to show `<DatasetLibrary />` when active.

Add "Upload Data" button/CTA in the dashboard header that opens `<DataUpload />` as a Sheet/Modal.

#### 4. Update `src/services/geminiService.ts`
Add a new export:
```typescript
export async function analyzeUploadedDataset(columns: string[], sampleRows: object[]): Promise<string>
```
- Sends first 20 rows + column names to Gemini
- Prompt: identify what financial metrics are present, suggest what CFO analysis is possible
- Returns markdown string
- Called after successful parse in `DataUpload.tsx` to give instant AI feedback on the data

### Firestore Security Rules (`firestore.rules`)
Update rules to allow authenticated users to read/write their own `revenueDatasets`:
```
match /revenueDatasets/{docId} {
  allow read, write: if request.auth != null && request.auth.uid == resource.data.userId;
  allow create: if request.auth != null && request.auth.uid == request.resource.data.userId;
}
```

### Error States to Handle
- File too large (>5MB) → show error before upload
- Unsupported file type → show error on drop/select
- Parse failure (malformed CSV/JSON) → show specific error message
- Network error during save → toast error, keep data in state so user can retry
- Firestore permission denied → prompt re-login

### Definition of Done for Phase 1
- [ ] User can drag-and-drop or select a CSV or JSON file
- [ ] File is parsed client-side preview (first 10 rows) displayed before saving
- [ ] AI gives instant feedback on what the data contains
- [ ] User names the dataset and saves it to Firestore
- [ ] Dataset Library shows all saved datasets
- [ ] User can view full data in a paginated modal
- [ ] User can delete a dataset
- [ ] All upload/save operations show loading states and success/error toasts
- [ ] Works on mobile (responsive layout)

---

## Code Conventions
- TypeScript strict mode — no `any` except where third-party types force it
- Tailwind 4 utility classes — match existing color tokens (`surface`, `primary`, `on-surface`, etc.)
- `motion/react` for animations (already installed)
- `sonner` for toasts (already installed)
- All Firestore calls in component files directly (no separate service layer for Phase 1 — keep it simple)
- No new global state management — use React local state + Firestore `onSnapshot`
- Dark mode only — do not add light mode variants

## Environment Variables Required
```
GEMINI_API_KEY=        # Google AI Studio key
STRIPE_SECRET_KEY=     # Stripe secret (server-side)
VITE_STRIPE_PUBLISHABLE_KEY=
VITE_STRIPE_PRO_PRICE_ID=
APP_URL=               # e.g. http://localhost:3000
```
Firebase config is hardcoded in `src/firebase.ts` (project: complicore-cfo).
