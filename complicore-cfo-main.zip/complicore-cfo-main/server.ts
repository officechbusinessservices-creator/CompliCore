import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import Stripe from "stripe";
import dotenv from "dotenv";
import multer from "multer";
import Papa from "papaparse";
import admin from "firebase-admin";
import * as Sentry from "@sentry/node";
import rateLimit from "express-rate-limit";

dotenv.config();

Sentry.init({
  dsn: process.env.SENTRY_DSN || "",
  enabled: !!process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV || "development",
  tracesSampleRate: 0.1,
});

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "sk_test_placeholder");

// ── Firebase Admin SDK ────────────────────────────────────────
if (!admin.apps.length) {
  if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
    admin.initializeApp({
      credential: admin.credential.cert(
        JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON)
      ),
    });
  } else {
    admin.initializeApp({
      credential: admin.credential.applicationDefault(),
    });
  }
}
const adminDb = admin.firestore();

// ── Firestore Subscription Helpers ───────────────────────────
async function updateSubscriptionInFirestore(
  customerId: string,
  sub: Stripe.Subscription
) {
  const usersSnap = await adminDb
    .collection("users")
    .where("stripeCustomerId", "==", customerId)
    .limit(1)
    .get();
  if (usersSnap.empty) return;
  const userId = usersSnap.docs[0].id;

  await adminDb
    .collection("users")
    .doc(userId)
    .collection("subscription")
    .doc("data")
    .set(
      {
        stripeCustomerId: customerId,
        stripeSubscriptionId: sub.id,
        plan: "pro",
        status: sub.status,
        // In Stripe API v21+, current_period_end lives on SubscriptionItem
        currentPeriodEnd: (() => {
          const periodEnd = sub.items?.data?.[0]?.current_period_end;
          return periodEnd
            ? admin.firestore.Timestamp.fromMillis(periodEnd * 1000)
            : null;
        })(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
}

async function cancelSubscriptionInFirestore(customerId: string) {
  const usersSnap = await adminDb
    .collection("users")
    .where("stripeCustomerId", "==", customerId)
    .limit(1)
    .get();
  if (usersSnap.empty) return;
  const userId = usersSnap.docs[0].id;

  await adminDb
    .collection("users")
    .doc(userId)
    .collection("subscription")
    .doc("data")
    .set(
      {
        plan: "free",
        status: "canceled",
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
}

// Multer — memory storage, 5 MB limit
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = file.originalname.split(".").pop()?.toLowerCase();
    if (ext === "csv" || ext === "json") {
      cb(null, true);
    } else {
      cb(new Error("Only .csv and .json files are accepted."));
    }
  },
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  const checkoutLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10,
    message: { error: "Too many checkout attempts. Please try again later." },
    standardHeaders: true,
    legacyHeaders: false,
  });

  const webhookLimiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 100,
    message: { error: "Too many webhook requests." },
    standardHeaders: true,
    legacyHeaders: false,
  });

  // ── Stripe Webhook — raw body MUST come before express.json() ─
  app.post(
    "/api/stripe/webhook",
    webhookLimiter,
    express.raw({ type: "application/json" }),
    async (req, res) => {
      const sig = req.headers["stripe-signature"] as string;
      const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

      if (!webhookSecret) {
        return res.status(500).json({ error: "Webhook secret not configured" });
      }

      let event: Stripe.Event;
      try {
        event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : "Unknown error";
        console.error("Webhook signature verification failed:", msg);
        return res.status(400).send(`Webhook Error: ${msg}`);
      }

      // Only process subscription events — ignore others silently
      const subEvents = new Set([
        "customer.subscription.created",
        "customer.subscription.updated",
        "customer.subscription.deleted",
      ]);

      if (subEvents.has(event.type)) {
        const subscription = event.data.object as Stripe.Subscription;
        const customerId =
          typeof subscription.customer === "string"
            ? subscription.customer
            : (subscription.customer as Stripe.Customer)?.id;

        if (customerId) {
          try {
            if (event.type === "customer.subscription.deleted") {
              await cancelSubscriptionInFirestore(customerId);
            } else {
              await updateSubscriptionInFirestore(customerId, subscription);
            }
          } catch (err) {
            console.error("[stripe-webhook] Error updating Firestore:", err);
            Sentry.captureException(err);
          }
        }
      }

      res.json({ received: true });
    }
  );

  app.use(express.json());

  // ── Revenue Upload Endpoint ──────────────────────────────────────
  app.post("/api/upload-revenue", upload.single("file"), (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded." });
      }

      const ext = req.file.originalname.split(".").pop()?.toLowerCase();
      const text = req.file.buffer.toString("utf-8");
      let rows: Record<string, unknown>[];

      if (ext === "csv") {
        const result = Papa.parse<Record<string, unknown>>(text, {
          header: true,
          skipEmptyLines: true,
          dynamicTyping: true,
        });
        if (result.errors.length > 0) {
          return res.status(400).json({
            error: `CSV parse error: ${result.errors[0].message}`,
          });
        }
        rows = result.data;
      } else {
        // JSON
        let parsed: unknown;
        try {
          parsed = JSON.parse(text);
        } catch {
          return res.status(400).json({ error: "Invalid JSON file." });
        }
        if (!Array.isArray(parsed)) {
          return res.status(400).json({ error: "JSON must be an array of objects." });
        }
        rows = parsed as Record<string, unknown>[];
      }

      if (rows.length === 0) {
        return res.status(400).json({ error: "File contains no data rows." });
      }

      const columns = Object.keys(rows[0]);
      const hasNumeric = columns.some(k => typeof rows[0][k] === "number");
      if (!hasNumeric) {
        return res.status(400).json({
          error: "No numeric value column detected. Please upload financial data.",
        });
      }

      return res.json({
        preview: rows.slice(0, 10),
        columns,
        rowCount: rows.length,
        source: ext === "csv" ? "csv" : "json",
      });
    } catch (error: unknown) {
      console.error("[upload-revenue]", error);
      Sentry.captureException(error);
      const msg = error instanceof Error ? error.message : "Upload failed.";
      return res.status(500).json({ error: msg });
    }
  });

  // ── Stripe Checkout Session Endpoint ─────────────────────────────
  app.post("/api/create-checkout-session", checkoutLimiter, async (req, res) => {
    try {
      const {
        priceId,
        successUrl,
        cancelUrl,
        mode = "subscription",
        userId,
      } = req.body;

      if (!process.env.STRIPE_SECRET_KEY) {
        return res.status(500).json({ error: "Stripe secret key is not configured." });
      }

      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: [
          {
            price: priceId,
            quantity: 1,
          },
        ],
        mode: mode as Stripe.Checkout.SessionCreateParams.Mode,
        success_url: successUrl,
        cancel_url: cancelUrl,
        ...(userId ? { metadata: { userId } } : {}),
      });

      // Persist stripeCustomerId on the user doc so webhooks can look them up
      if (userId && session.customer) {
        const customerId =
          typeof session.customer === "string"
            ? session.customer
            : session.customer.id;
        await adminDb.collection("users").doc(userId).set(
          { stripeCustomerId: customerId },
          { merge: true }
        );
      }

      res.json({ url: session.url });
    } catch (error: unknown) {
      console.error("[create-checkout-session]", error);
      Sentry.captureException(error);
      const msg = error instanceof Error ? error.message : "Checkout error";
      res.status(500).json({ error: msg });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
