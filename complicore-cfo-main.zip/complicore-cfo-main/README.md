# CompliCore CFO MVP

## The Truth
This repository was audited on 2026-03-28. The previous "Synthetic Intelligence" narrative was found to be a documentation-only shell. This MVP is a total rebuild focused on **Real Revenue Intelligence**.

## MVP Scope: CFO Agent
- **Problem:** High-growth startups have revenue data but no real-time fiscal synthesis.
- **Solution:** A Gemini-powered CFO agent that analyzes revenue exports and provides actionable fiscal reports.
- **Exclusions:** No "Agent Team Management", no "Plaid/Quickbooks Sync" (yet), no "Autonomous Fiscal Synchronization".

## Tech Stack
- **Frontend:** React + Vite + Tailwind + Lucide + Motion
- **Backend:** Express (Node.js) + tsx
- **Database:** Firestore (User Profiles, Revenue Data, Agent Insights)
- **Auth:** Firebase Google Sign-in
- **AI:** Google Gemini SDK (@google/genai)
- **Payments:** Stripe (Pro Subscription + Sprint Setup Add-on)

## Implementation Phases
1. **Phase 0:** Sanitization & Foundation (COMPLETE)
2. **Phase 1:** Data Ingestion (CSV/JSON Upload)
3. **Phase 2:** CFO Analysis Service (Gemini Integration)
4. **Phase 3:** Actionable Insights Dashboard
5. **Phase 4:** Stripe & Auth Hardening

## Security Note
- All legacy "leaked" keys have been flagged for revocation.
- This repo uses environment variables for all secrets.
