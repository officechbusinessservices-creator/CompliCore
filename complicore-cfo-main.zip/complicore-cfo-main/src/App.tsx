/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Cpu, 
  BarChart3, 
  ListTodo, 
  CreditCard, 
  History, 
  Plus, 
  Settings, 
  HelpCircle,
  Search,
  Bell,
  Settings2,
  Database,
  TrendingUp,
  DollarSign,
  Activity,
  AlertCircle,
  Building2,
  Headset,
  Terminal,
  Megaphone,
  UserCheck,
  Zap,
  Check,
  X,
  FileText,
  Calendar,
  Monitor,
  Briefcase,
  SearchCode,
  Compass,
  Loader2,
  LogOut,
  ShieldCheck,
  Sparkles,
  History as AuditIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Toaster, toast } from 'sonner';
import Markdown from 'react-markdown';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  Legend
} from 'recharts';
import { 
  auth, 
  db, 
  loginWithGoogle, 
  logout, 
  handleFirestoreError, 
  OperationType 
} from './firebase';
import { 
  onAuthStateChanged, 
  User,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider
} from 'firebase/auth';
import { 
  collection, 
  onSnapshot, 
  query, 
  orderBy, 
  addDoc, 
  deleteDoc, 
  doc, 
  serverTimestamp,
  setDoc,
  getDoc,
  limit
} from 'firebase/firestore';
import { generateAgentReport, analyzeRevenueData } from './services/geminiService';
import DataUpload from './components/DataUpload';
import DatasetLibrary from './components/DatasetLibrary';
import AnalyticsDashboard from './components/AnalyticsDashboard';

// --- Components ---

const SidebarItem = ({ icon: Icon, label, active = false, onClick }: { icon: any, label: string, active?: boolean, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 transition-all duration-300 group ${
      active 
        ? 'bg-gradient-to-r from-primary/20 to-transparent border-l-4 border-primary text-on-surface font-medium' 
        : 'text-on-surface-variant hover:bg-surface-high hover:text-on-surface hover:translate-x-1'
    }`}
  >
    <Icon size={20} className={active ? 'text-primary' : 'group-hover:text-primary'} />
    <span className="text-sm">{label}</span>
  </button>
);

const MetricCard = ({ title, value, trend, subValue, icon: Icon, colorClass = "text-secondary", onClick }: { title: string, value: string, trend?: string, subValue?: string, icon: any, colorClass?: string, onClick?: () => void }) => (
  <div 
    onClick={onClick}
    className={`bg-surface p-6 rounded-xl border border-outline/10 relative overflow-hidden group hover:border-outline/30 transition-all duration-300 ${onClick ? 'cursor-pointer hover:border-primary/30' : ''}`}
  >
    <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
      <Icon size={48} />
    </div>
    <p className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant mb-1">{title}</p>
    <div className="flex items-baseline gap-2">
      <h2 className="text-2xl font-bold text-on-surface">{value}</h2>
      {trend && <span className={`${colorClass} text-xs font-bold`}>{trend}</span>}
    </div>
    {subValue && <p className="text-[10px] text-on-surface-variant mt-2">{subValue}</p>}
  </div>
);

const AgentCard = ({ role, status, statusLabel, icon: Icon, colorClass, glowClass, onClick }: { role: string, status: string, statusLabel: string, icon: any, colorClass: string, glowClass: string, onClick: () => void, key?: any }) => (
  <motion.div 
    whileHover={{ y: -4 }}
    whileTap={{ scale: 0.98 }}
    onClick={onClick}
    className="bg-surface rounded-xl p-4 border border-outline/10 hover:border-primary/30 transition-all cursor-pointer group"
  >
    <div className="flex justify-between items-start mb-3">
      <div className={`w-8 h-8 rounded ${colorClass}/10 flex items-center justify-center ${colorClass} ${glowClass}`}>
        <Icon size={18} />
      </div>
      <div className={`h-2 w-2 rounded-full ${colorClass} ${status === 'active' ? 'animate-pulse' : 'opacity-40'}`}></div>
    </div>
    <h3 className="font-bold text-sm">{role}</h3>
    <p className="text-[11px] text-on-surface-variant mb-3 h-8 overflow-hidden">{statusLabel}</p>
    <span className={`text-[9px] font-mono uppercase ${colorClass} ${status === 'attention' ? 'font-bold' : ''}`}>
      {status === 'active' ? 'ACTIVE' : status === 'ready' ? 'READY' : status === 'attention' ? 'ATTENTION REQ' : 'HIBERNATING'}
    </span>
  </motion.div>
);

const ApprovalItem = ({ role, task, description, icon: Icon, colorClass, onApprove, onReject }: { role: string, task: string, description: string, icon: any, colorClass: string, onApprove: () => void, onReject: () => void, key?: any }) => (
  <motion.div 
    layout
    initial={{ opacity: 0, x: -20 }}
    animate={{ opacity: 1, x: 0 }}
    exit={{ opacity: 0, x: 20 }}
    className="glass-panel p-4 rounded-xl border border-outline/10 flex items-center justify-between hover:border-outline/30 transition-all"
  >
    <div className="flex items-center gap-4">
      <div className={`w-10 h-10 rounded ${colorClass}/10 flex items-center justify-center ${colorClass}`}>
        <Icon size={20} />
      </div>
      <div>
        <h4 className="text-sm font-bold">{role}: {task}</h4>
        <p className="text-xs text-on-surface-variant">{description}</p>
      </div>
    </div>
    <div className="flex gap-2">
      <button 
        onClick={onReject}
        className="p-2 rounded bg-tertiary/10 text-tertiary hover:bg-tertiary/20 transition-colors"
      >
        <X size={16} />
      </button>
      <button 
        onClick={onApprove}
        className="p-2 rounded bg-secondary/10 text-secondary hover:bg-secondary/20 transition-colors"
      >
        <Check size={16} />
      </button>
    </div>
  </motion.div>
);

const QuickActionButton = ({ icon: Icon, label, onClick }: { icon: any, label: string, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className="flex flex-col items-center justify-center p-4 bg-surface-high rounded-xl border border-outline/10 hover:bg-primary transition-all group"
  >
    <Icon size={20} className="text-primary group-hover:text-white mb-2 transition-colors" />
    <span className="text-[9px] font-bold uppercase tracking-tighter text-center group-hover:text-white transition-colors">{label}</span>
  </button>
);

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [activeSidebar, setActiveSidebar] = useState('Dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLaunching, setIsLaunching] = useState(false);
  const [showLaunchModal, setShowLaunchModal] = useState(false);
  const [selectedAgent, setSelectedAgent] = useState<any>(null);
  const [agentReport, setAgentReport] = useState<string | null>(null);
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  const [revenueInsight, setRevenueInsight] = useState<string | null>(null);
  const [isAnalyzingRevenue, setIsAnalyzingRevenue] = useState(false);
  const [isUpgrading, setIsUpgrading] = useState(false);
  const [isPurchasingSprintSetup, setIsPurchasingSprintSetup] = useState(false);
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteConfirmationText, setDeleteConfirmationText] = useState('');
  const [isDeletingAccount, setIsDeletingAccount] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [userProfile, setUserProfile] = useState<any>(null);
  
  const [revenueSnapshots, setRevenueSnapshots] = useState<any[]>([]);
  const [cfoInsights, setCfoInsights] = useState<any[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [listings, setListings] = useState<any[]>([]);
  const [isAddingListing, setIsAddingListing] = useState(false);
  
  const [agents, setAgents] = useState<any[]>([]);
  const [approvals, setApprovals] = useState<any[]>([]);
  const [intelligenceLogs, setIntelligenceLogs] = useState<any[]>([]);
  const [showUploadModal, setShowUploadModal] = useState(false);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setIsAuthReady(true);
      
      if (currentUser) {
        // Ensure user document exists in Firestore
        const userRef = doc(db, 'users', currentUser.uid);
        const userSnap = await getDoc(userRef);
        if (!userSnap.exists()) {
          const initialProfile = {
            uid: currentUser.uid,
            email: currentUser.email,
            displayName: currentUser.displayName,
            photoURL: currentUser.photoURL,
            role: 'viewer', // Default role
            createdAt: serverTimestamp()
          };
          await setDoc(userRef, initialProfile).catch(e => handleFirestoreError(e, OperationType.WRITE, `users/${currentUser.uid}`));
          setUserProfile(initialProfile);

          // Seed platform-wide data if user is the first one (or just seed for demo)
          const agentsSnap = await getDoc(doc(db, 'agents', 'coo-node'));
          if (!agentsSnap.exists()) {
            const initialAgents = [
              { id: 'coo-node', role: 'COO Agent', status: 'Active', statusLabel: 'Operational', efficiency: 94, icon: 'Cpu' },
              { id: 'cfo-node', role: 'CFO Agent', status: 'Active', statusLabel: 'Operational', efficiency: 88, icon: 'DollarSign' },
              { id: 'cro-node', role: 'CRO Agent', status: 'Paused', statusLabel: 'Suspended', efficiency: 0, icon: 'TrendingUp' }
            ];
            for (const agent of initialAgents) {
              await setDoc(doc(db, 'agents', agent.id), agent);
            }
          }

          const approvalsSnap = await getDoc(doc(db, 'approvals', 'seed-1'));
          if (!approvalsSnap.exists()) {
            await setDoc(doc(db, 'approvals', 'seed-1'), {
              id: 'seed-1',
              title: 'Revenue Recovery Protocol',
              description: 'Approve automated collection for 12 overdue corporate stays.',
              icon: 'DollarSign',
              timestamp: serverTimestamp()
            });
          }
        } else {
          setUserProfile(userSnap.data());
        }
      } else {
        setUserProfile(null);
      }
    });
    return () => unsubscribe();
  }, []);

  // Handle Stripe Success Callback
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const sessionId = params.get('session_id');
    const type = params.get('type');
    
    if (sessionId && user) {
      const finalizePurchase = async () => {
        try {
          const userRef = doc(db, 'users', user.uid);
          
          if (type === 'sprint_setup') {
            await setDoc(userRef, { sprintSetupEnabled: true }, { merge: true });
            toast.success("Sprint Setup successfully activated!");
          } else {
            await setDoc(userRef, { role: 'pro' }, { merge: true });
            toast.success("Welcome to CompliCore Pro!");
          }
          
          // Clear URL params
          window.history.replaceState({}, document.title, window.location.pathname);
          // Refresh profile
          const userSnap = await getDoc(userRef);
          setUserProfile(userSnap.data());
        } catch (error) {
          console.error("Error finalizing purchase:", error);
        }
      };
      finalizePurchase();
    }
  }, [user]);

  // Firestore Listeners
  useEffect(() => {
    if (!user) return;

    const agentsUnsubscribe = onSnapshot(collection(db, 'agents'), (snapshot) => {
      const agentsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setAgents(agentsData);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'agents'));

    const approvalsUnsubscribe = onSnapshot(collection(db, 'approvals'), (snapshot) => {
      const approvalsData = snapshot.docs.map(doc => ({ docId: doc.id, ...doc.data() }));
      setApprovals(approvalsData);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'approvals'));

    const logsUnsubscribe = onSnapshot(
      query(collection(db, 'intelligence_logs'), orderBy('timestamp', 'desc'), limit(50)), 
      (snapshot) => {
        const logsData = snapshot.docs.map(doc => ({ docId: doc.id, ...doc.data() }));
        setIntelligenceLogs(logsData);
      }, 
      (error) => handleFirestoreError(error, OperationType.LIST, 'intelligence_logs')
    );

    const snapshotsUnsubscribe = onSnapshot(
      query(collection(db, `users/${user.uid}/revenue_snapshots`), orderBy('timestamp', 'desc'), limit(10)),
      (snapshot) => {
        setRevenueSnapshots(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      },
      (error) => handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/revenue_snapshots`)
    );

    const insightsUnsubscribe = onSnapshot(
      query(collection(db, `users/${user.uid}/cfo_insights`), orderBy('timestamp', 'desc'), limit(10)),
      (snapshot) => {
        setCfoInsights(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      },
      (error) => handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/cfo_insights`)
    );

    const listingsUnsubscribe = onSnapshot(
      collection(db, `users/${user.uid}/listings`),
      (snapshot) => {
        setListings(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      },
      (error) => handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/listings`)
    );

    return () => {
      agentsUnsubscribe();
      approvalsUnsubscribe();
      logsUnsubscribe();
      snapshotsUnsubscribe();
      insightsUnsubscribe();
      listingsUnsubscribe();
    };
  }, [user]);

  const filteredAgents = agents.filter(agent => 
    agent.role.toLowerCase().includes(searchQuery.toLowerCase()) || 
    agent.statusLabel.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAction = (label: string) => {
    toast.success(`${label} action triggered successfully`);
  };

  const handleSidebarClick = (label: string) => {
    setActiveSidebar(label);
    toast(`Switched to ${label}`);
  };

  const handleRevenueUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    setIsUploading(true);
    try {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const content = event.target?.result as string;
        
        // Simple mock parsing for MVP (Real parsing in Phase 2)
        const mrrMatch = content.match(/mrr[:=]\s*(\d+)/i);
        const churnMatch = content.match(/churn[:=]\s*([\d.]+)/i);
        
        const mrr = mrrMatch ? parseInt(mrrMatch[1]) : 1240500;
        const churn = churnMatch ? parseFloat(churnMatch[1]) : 2.4;

        const snapshotRef = collection(db, `users/${user.uid}/revenue_snapshots`);
        const newSnapshot = {
          id: `snap-${Date.now()}`,
          timestamp: serverTimestamp(),
          source: file.name,
          mrr: mrr,
          churn: churn,
          raw_data: content.substring(0, 10000) // Limit raw data size
        };

        await addDoc(snapshotRef, newSnapshot);
        toast.success(`Revenue data from ${file.name} ingested.`);
        
        // Trigger AI Analysis
        setIsAnalyzingRevenue(true);
        const insight = await analyzeRevenueData(`$${mrr.toLocaleString()}`, `${churn}%`);
        
        await addDoc(collection(db, `users/${user.uid}/cfo_insights`), {
          id: `insight-${Date.now()}`,
          timestamp: serverTimestamp(),
          snapshotId: newSnapshot.id,
          summary: insight,
          levers: ["Optimize churn in high-tier accounts", "Review expansion revenue pipeline"],
          status: "final"
        });
        
        setRevenueInsight(insight);
        toast.success("CFO Intelligence Report Generated");
        setIsAnalyzingRevenue(false);
      };
      reader.readAsText(file);
    } catch (error) {
      console.error("Upload Error:", error);
      toast.error("Failed to ingest revenue data");
    } finally {
      setIsUploading(false);
    }
  };

  const handleLaunchAgent = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLaunching(true);
    
    try {
      const formData = new FormData(e.currentTarget as HTMLFormElement);
      const role = formData.get('role') as string;
      const node = formData.get('node') as string;

      await toast.promise(
        new Promise(async (resolve, reject) => {
          try {
            await addDoc(collection(db, 'agents'), {
              id: role.toLowerCase().replace(' ', '-'),
              role: role,
              status: 'ready',
              statusLabel: 'Initializing...',
              icon: 'Cpu',
              colorClass: 'text-primary',
              glowClass: 'status-glow-blue',
              uptime: 100,
              efficiency: 0,
              lastActive: serverTimestamp()
            });

            // Log the action
            await addDoc(collection(db, 'intelligence_logs'), {
              agentId: role,
              timestamp: serverTimestamp(),
              action: 'Agent Deployed',
              report: `New agent of type ${role} deployed to node ${node}.`
            });

            setTimeout(resolve, 2000);
          } catch (e) {
            reject(e);
          }
        }),
        {
          loading: 'Initializing synthetic intelligence...',
          success: `New ${role} deployed to ${node}`,
          error: 'Failed to deploy agent'
        }
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'agents');
    } finally {
      setIsLaunching(false);
      setShowLaunchModal(false);
    }
  };

  const handleApproval = async (docId: string, approved: boolean) => {
    const item = approvals.find(a => a.docId === docId);
    try {
      await deleteDoc(doc(db, 'approvals', docId));
      
      // Log the action
      await addDoc(collection(db, 'intelligence_logs'), {
        agentId: item?.role || 'System',
        timestamp: serverTimestamp(),
        action: approved ? 'Task Approved' : 'Task Rejected',
        report: `Task: ${item?.task}. Description: ${item?.description}`
      });

      if (approved) {
        toast.success(`Approved: ${item?.role} - ${item?.task}`);
      } else {
        toast.error(`Rejected: ${item?.role} - ${item?.task}`);
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `approvals/${docId}`);
    }
  };

  const handleGetAgentReport = async (agent: any) => {
    setIsGeneratingReport(true);
    setAgentReport(null);
    try {
      const report = await generateAgentReport(agent.role, agent.status, agent.statusLabel);
      setAgentReport(report);
      
      // Log the action in Firestore
      await addDoc(collection(db, 'intelligence_logs'), {
        agentId: agent.id,
        timestamp: serverTimestamp(),
        action: 'Intelligence Report Generated',
        report: report
      });
    } catch (error) {
      toast.error("Failed to generate report");
    } finally {
      setIsGeneratingReport(false);
    }
  };

  const handleAnalyzeRevenue = async () => {
    setIsAnalyzingRevenue(true);
    try {
      const insight = await analyzeRevenueData("$1,240,500", "2.4%");
      setRevenueInsight(insight);
      toast.success("Revenue analysis complete");
    } catch (error) {
      toast.error("Analysis failed");
    } finally {
      setIsAnalyzingRevenue(false);
    }
  };

  const handleUpgrade = async () => {
    setIsUpgrading(true);
    try {
      const priceId = billingCycle === 'monthly' 
        ? (import.meta.env.VITE_STRIPE_PRO_PRICE_ID || 'price_placeholder_monthly')
        : (import.meta.env.VITE_STRIPE_PRO_PRICE_ID_YEARLY || 'price_placeholder_yearly');

      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          priceId: priceId,
          successUrl: window.location.origin + '/?session_id={CHECKOUT_SESSION_ID}',
          cancelUrl: window.location.origin,
        }),
      });

      const { url, error } = await response.json();
      if (error) throw new Error(error);
      
      if (url) {
        window.location.href = url;
      }
    } catch (error: any) {
      console.error("Upgrade Error:", error);
      toast.error(error.message || "Failed to initiate checkout");
    } finally {
      setIsUpgrading(false);
    }
  };

  const handleSprintSetupPurchase = async () => {
    if (userProfile?.sprintSetupEnabled) {
      toast.info("Sprint Setup is already active.");
      return;
    }

    setIsPurchasingSprintSetup(true);
    try {
      const priceId = import.meta.env.VITE_STRIPE_SPRINT_SETUP_PRICE_ID || 'price_placeholder_sprint_setup';

      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          priceId: priceId,
          mode: 'payment', // One-time payment
          successUrl: window.location.origin + '/?session_id={CHECKOUT_SESSION_ID}&type=sprint_setup',
          cancelUrl: window.location.origin,
        }),
      });

      const { url, error } = await response.json();
      if (error) throw new Error(error);
      
      if (url) {
        window.location.href = url;
      }
    } catch (error: any) {
      console.error("Sprint Setup Purchase Error:", error);
      toast.error(error.message || "Failed to initiate checkout");
    } finally {
      setIsPurchasingSprintSetup(false);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;

    setIsSavingSettings(true);
    const formData = new FormData(e.currentTarget);
    const displayName = formData.get('displayName') as string;
    const photoURL = formData.get('photoURL') as string;

    try {
      const userRef = doc(db, 'users', user.uid);
      await setDoc(userRef, { 
        displayName, 
        photoURL 
      }, { merge: true });
      
      toast.success("Profile updated successfully");
      
      // Update local profile state
      const userSnap = await getDoc(userRef);
      setUserProfile(userSnap.data());
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    } finally {
      setIsSavingSettings(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !user.email) return;

    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast.error("New passwords do not match");
      return;
    }

    setIsChangingPassword(true);
    try {
      // Re-authenticate user
      const credential = EmailAuthProvider.credential(user.email, passwordForm.currentPassword);
      await reauthenticateWithCredential(user, credential);
      
      // Update password
      await updatePassword(user, passwordForm.newPassword);
      
      toast.success("Password updated successfully");
      setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (error: any) {
      console.error("Password Change Error:", error);
      if (error.code === 'auth/wrong-password') {
        toast.error("Current password is incorrect");
      } else if (error.code === 'auth/weak-password') {
        toast.error("New password is too weak");
      } else if (error.code === 'auth/user-mismatch') {
        toast.error("User mismatch. Please log in again.");
      } else {
        toast.error("Failed to update password. Ensure you have a password-based account.");
      }
    } finally {
      setIsChangingPassword(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (!user) return;
    setIsDeletingAccount(true);
    try {
      // 1. Delete Firestore user document
      const userRef = doc(db, 'users', user.uid);
      await deleteDoc(userRef);
      
      // 2. Delete Auth user
      await user.delete();
      
      toast.success("Account permanently deleted.");
      setUser(null);
      setUserProfile(null);
      setShowDeleteModal(false);
      setDeleteConfirmationText('');
      setActiveSidebar('Dashboard');
    } catch (error: any) {
      if (error.code === 'auth/requires-recent-login') {
        toast.error("Security alert: Please log out and log back in to delete your account.");
      } else {
        console.error("Delete Account Error:", error);
        toast.error("Failed to delete account. Please try again.");
      }
    } finally {
      setIsDeletingAccount(false);
    }
  };

  if (!isAuthReady) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="animate-spin text-primary" size={48} />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md glass-panel p-8 text-center space-y-8"
        >
          <div className="flex justify-center">
            <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center text-primary status-glow-blue">
              <Cpu size={32} />
            </div>
          </div>
          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tighter">CompliCore AI</h1>
            <p className="text-on-surface-variant">Secure Intelligence Command Center</p>
          </div>
          <div className="space-y-4">
            <button 
              onClick={() => loginWithGoogle().catch(e => toast.error("Login failed"))}
              className="w-full py-4 bg-white text-black font-bold rounded-xl flex items-center justify-center gap-3 hover:bg-gray-100 transition-all"
            >
              <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-5 h-5" />
              Sign in with Google
            </button>
            <p className="text-[10px] font-mono text-on-surface-variant uppercase tracking-widest">
              Authorized Access Only
            </p>
          </div>
        </motion.div>
      </div>
    );
  }

  const iconMap: Record<string, any> = {
    LayoutDashboard, Cpu, BarChart3, ListTodo, CreditCard, History, Plus, Settings, HelpCircle,
    Search, Bell, Settings2, Database, TrendingUp, DollarSign, Activity, AlertCircle, Building2,
    Headset, Terminal, Megaphone, UserCheck, Zap, Check, X, FileText, Calendar, Monitor, Briefcase,
    SearchCode, Compass, Loader2, AuditIcon
  };

  const renderDashboard = () => (
    <main className="p-8 pb-24 space-y-10">
      {/* Revenue Intelligence */}
      <section>
        <div className="flex items-end justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Revenue Intelligence</h1>
            <p className="text-on-surface-variant text-sm">Real-time fiscal synchronization across 12 active nodes.</p>
          </div>
          <div className="flex gap-2">
            <label className="cursor-pointer inline-flex items-center px-4 py-2 rounded-xl bg-primary text-black font-bold text-xs uppercase tracking-widest hover:bg-primary/90 transition-all shadow-lg shadow-primary/20">
              {isUploading ? <Loader2 className="animate-spin mr-2" size={14} /> : <Plus className="mr-2" size={14} />}
              Ingest Data
              <input type="file" className="hidden" onChange={handleRevenueUpload} accept=".csv,.json,.txt" />
            </label>
            <button 
              onClick={() => handleAction('Live Feed Toggle')}
              className="inline-flex items-center px-4 py-2 rounded-xl bg-surface-high text-on-surface text-xs font-bold border border-outline/10 uppercase tracking-widest hover:bg-surface-highest transition-colors"
            >
              Live Feed
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-5 gap-4">
          <div 
            onClick={handleAnalyzeRevenue}
            className="col-span-1 md:col-span-2 bg-surface p-6 rounded-xl border border-outline/10 relative overflow-hidden group cursor-pointer hover:border-primary/30 transition-all"
          >
            <div className="absolute top-0 right-0 p-4 opacity-5">
              <CreditCard size={48} />
            </div>
            <p className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant mb-1">Monthly Recurring Revenue</p>
            <div className="flex items-baseline gap-2">
              <h2 className="text-4xl font-black">${(revenueSnapshots[0]?.mrr || 1240500).toLocaleString()}</h2>
              <span className="text-secondary text-sm font-bold">+{revenueSnapshots[0]?.churn || 2.4}%</span>
            </div>
            <div className="mt-4 h-1.5 w-full bg-surface-high rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: '75%' }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="h-full bg-secondary rounded-full"
              />
            </div>
          </div>

          <MetricCard 
            title="Pipeline Velocity" 
            value="$14.2k" 
            trend="8% ABOVE BASELINE" 
            subValue="/day" 
            icon={TrendingUp} 
            colorClass="text-primary"
            onClick={handleAnalyzeRevenue}
          />

          <MetricCard 
            title="Churn Rate" 
            value={`${revenueSnapshots[0]?.churn || 2.4}%`} 
            trend="HEALTHY" 
            subValue="Stable since last epoch" 
            icon={Activity} 
            colorClass="text-secondary"
            onClick={handleAnalyzeRevenue}
          />

          <MetricCard 
            title="Sprint Setup" 
            value={userProfile?.sprintSetupEnabled ? "94%" : "LOCKED"} 
            trend={userProfile?.sprintSetupEnabled ? "OPTIMIZED" : "ADD-ON"} 
            subValue={userProfile?.sprintSetupEnabled ? "Sprint 14 Active" : "Click to unlock"} 
            icon={Calendar} 
            colorClass={userProfile?.sprintSetupEnabled ? "text-tertiary" : "text-on-surface-variant"}
            onClick={userProfile?.sprintSetupEnabled ? () => handleAction('Sprint Setup') : handleSprintSetupPurchase}
          />
        </div>

        {/* CFO Intelligence Feed */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <Terminal size={20} className="text-primary" />
                CFO Intelligence Feed
              </h2>
              <span className="text-[10px] font-mono text-on-surface-variant uppercase tracking-widest">
                {cfoInsights.length} Reports Available
              </span>
            </div>
            
            <div className="space-y-4">
              {isAnalyzingRevenue && (
                <div className="glass-panel p-6 border-primary/20 animate-pulse">
                  <div className="flex items-center gap-3 mb-4">
                    <Loader2 className="animate-spin text-primary" size={20} />
                    <span className="text-sm font-bold uppercase tracking-widest">Gemini Analyzing Fiscal Nodes...</span>
                  </div>
                  <div className="h-4 bg-surface-high rounded w-3/4 mb-2" />
                  <div className="h-4 bg-surface-high rounded w-1/2" />
                </div>
              )}
              
              {cfoInsights.length === 0 && !isAnalyzingRevenue && (
                <div className="glass-panel p-12 text-center space-y-4 border-dashed border-outline/20">
                  <div className="flex justify-center">
                    <Database size={48} className="text-on-surface-variant opacity-20" />
                  </div>
                  <p className="text-on-surface-variant text-sm">No revenue snapshots ingested. Upload a CSV to begin analysis.</p>
                </div>
              )}

              {cfoInsights.map((insight, idx) => (
                <motion.div 
                  key={insight.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="glass-panel p-6 border-outline/10 hover:border-primary/20 transition-all group"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                        <BarChart3 size={20} />
                      </div>
                      <div>
                        <h3 className="font-bold text-sm">Fiscal Intelligence Report</h3>
                        <p className="text-[10px] text-on-surface-variant font-mono uppercase">
                          {insight.timestamp?.toDate ? insight.timestamp.toDate().toLocaleString() : 'Just now'}
                        </p>
                      </div>
                    </div>
                    <div className="px-2 py-1 rounded bg-primary/10 text-primary text-[8px] font-bold uppercase tracking-widest">
                      {insight.status}
                    </div>
                  </div>
                  <div className="prose prose-invert prose-sm max-w-none text-on-surface-variant leading-relaxed">
                    <Markdown>{insight.summary}</Markdown>
                  </div>
                  {insight.levers && (
                    <div className="mt-4 flex flex-wrap gap-2">
                      {insight.levers.map((lever: string, i: number) => (
                        <span key={i} className="px-2 py-1 rounded-full bg-surface-high text-[10px] font-medium text-on-surface border border-outline/10">
                          {lever}
                        </span>
                      ))}
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Zap size={20} className="text-secondary" />
              Strategic Levers
            </h2>
            <div className="space-y-3">
              {[
                { label: "Optimize Churn", value: `${revenueSnapshots[0]?.churn || 2.4}%`, status: "Healthy", color: "text-secondary" },
                { label: "Expansion Revenue", value: "$42k", status: "Critical", color: "text-primary" },
                { label: "LTV:CAC Ratio", value: "4.2x", status: "Optimized", color: "text-tertiary" }
              ].map((lever, i) => (
                <div key={i} className="glass-panel p-4 border-outline/10 flex justify-between items-center">
                  <div>
                    <p className="text-[10px] font-mono text-on-surface-variant uppercase tracking-widest">{lever.label}</p>
                    <p className="text-lg font-bold">{lever.value}</p>
                  </div>
                  <div className={`text-[8px] font-bold uppercase tracking-widest px-2 py-1 rounded bg-surface-high ${lever.color}`}>
                    {lever.status}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Agent Team Command */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <Zap size={20} className="text-primary" />
          <h2 className="text-xl font-bold tracking-tight">Agent Team Command</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <AgentCard 
            role="CFO" 
            status="active" 
            statusLabel="Analyzing Fiscal Nodes" 
            icon={BarChart3} 
            colorClass="text-primary" 
            glowClass="status-glow-blue" 
            onClick={() => handleAnalyzeRevenue()}
          />
          <AgentCard 
            role="COO" 
            status="hibernating" 
            statusLabel="Awaiting Pro Upgrade" 
            icon={Cpu} 
            colorClass="text-on-surface-variant" 
            glowClass="" 
            onClick={() => handleUpgrade()}
          />
          <AgentCard 
            role="CMO" 
            status="hibernating" 
            statusLabel="Awaiting Pro Upgrade" 
            icon={Megaphone} 
            colorClass="text-on-surface-variant" 
            glowClass="" 
            onClick={() => handleUpgrade()}
          />
        </div>
      </section>

      {/* Approvals and Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <section>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <UserCheck size={20} className="text-tertiary" />
              <h2 className="text-xl font-bold tracking-tight">Pending Approvals</h2>
            </div>
            <span className="text-[10px] font-mono text-tertiary px-2 py-0.5 rounded border border-tertiary/20">
              {approvals.length} BLOCKED TASKS
            </span>
          </div>
          <div className="space-y-3">
            <AnimatePresence mode="popLayout">
              {approvals.map((approval) => (
                <ApprovalItem 
                  key={approval.docId}
                  role={approval.role} 
                  task={approval.task} 
                  description={approval.description} 
                  icon={iconMap[approval.icon] || ListTodo} 
                  colorClass={approval.colorClass} 
                  onApprove={() => handleApproval(approval.docId, true)}
                  onReject={() => handleApproval(approval.docId, false)}
                />
              ))}
              {approvals.length === 0 && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-8 text-on-surface-variant text-sm border border-dashed border-outline/20 rounded-xl"
                >
                  No pending approvals. All systems clear.
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </section>

        <section>
          <div className="flex items-center gap-3 mb-4">
            <Zap size={20} className="text-primary" />
            <h2 className="text-xl font-bold tracking-tight">Quick Actions</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <QuickActionButton icon={BarChart3} label="MRR Dashboard" onClick={() => handleAction('MRR Dashboard')} />
            <QuickActionButton icon={FileText} label="Invoice Chaser" onClick={() => handleAction('Invoice Chaser')} />
            <QuickActionButton icon={Calendar} label="Content Calendar" onClick={() => handleAction('Content Calendar')} />
            <QuickActionButton icon={Briefcase} label="Pipeline Brief" onClick={() => handleAction('Pipeline Brief')} />
            <QuickActionButton icon={Monitor} label="Uptime Check" onClick={() => handleAction('Uptime Check')} />
            <QuickActionButton icon={FileText} label="CEO Brief" onClick={() => handleAction('CEO Brief')} />
            <QuickActionButton icon={SearchCode} label="Local SEO Audit" onClick={() => handleAction('Local SEO Audit')} />
            <QuickActionButton icon={Compass} label="SDD Architect" onClick={() => handleAction('SDD Architect')} />
            <QuickActionButton 
              icon={Calendar} 
              label={userProfile?.sprintSetupEnabled ? "Sprint Setup" : "Unlock Sprint Setup"} 
              onClick={userProfile?.sprintSetupEnabled ? () => handleAction('Sprint Setup') : handleSprintSetupPurchase} 
            />
          </div>
        </section>
      </div>
    </main>
  );

  const renderAuditTrail = () => (
    <main className="p-8 pb-24 space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Audit Trail</h1>
        <p className="text-on-surface-variant text-sm">Historical record of all synthetic intelligence activities and decisions.</p>
      </div>

      <div className="glass-panel rounded-xl border border-outline/10 overflow-hidden">
        <div className="bg-surface-high px-6 py-3 border-b border-outline/10 grid grid-cols-12 gap-4 text-[10px] font-mono uppercase tracking-widest text-on-surface-variant">
          <div className="col-span-2">Timestamp</div>
          <div className="col-span-2">Agent</div>
          <div className="col-span-3">Action</div>
          <div className="col-span-5">Details</div>
        </div>
        <div className="divide-y divide-outline/5">
          {intelligenceLogs.map((log) => (
            <div key={log.docId} className="px-6 py-4 grid grid-cols-12 gap-4 items-center hover:bg-surface-high/50 transition-colors">
              <div className="col-span-2 text-[10px] font-mono text-on-surface-variant">
                {log.timestamp?.toDate ? log.timestamp.toDate().toLocaleString() : 'Pending...'}
              </div>
              <div className="col-span-2">
                <span className="px-2 py-0.5 rounded bg-primary/10 text-primary text-[10px] font-bold uppercase">
                  {log.agentId}
                </span>
              </div>
              <div className="col-span-3 text-sm font-medium text-on-surface">
                {log.action}
              </div>
              <div className="col-span-5 text-xs text-on-surface-variant truncate">
                {log.report ? log.report.substring(0, 100) + '...' : 'No additional details.'}
              </div>
            </div>
          ))}
          {intelligenceLogs.length === 0 && (
            <div className="p-12 text-center text-on-surface-variant text-sm">
              No intelligence logs recorded yet.
            </div>
          )}
        </div>
      </div>
    </main>
  );

  const renderBilling = () => (
    <main className="p-8 pb-24 space-y-8 max-w-4xl">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Billing & Subscription</h1>
        <p className="text-on-surface-variant text-sm">Manage your enterprise plan and node allocation.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="glass-panel p-8 rounded-2xl border border-outline/10 space-y-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-mono uppercase text-on-surface-variant mb-1">Current Plan</p>
              <h2 className="text-3xl font-black text-primary uppercase tracking-tighter">
                {userProfile?.role === 'pro' ? 'Enterprise Pro' : 'Standard Node'}
              </h2>
            </div>
            <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase ${userProfile?.role === 'pro' ? 'bg-secondary/10 text-secondary' : 'bg-on-surface-variant/10 text-on-surface-variant'}`}>
              {userProfile?.role === 'pro' ? 'Active' : 'Free Tier'}
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-3 text-sm">
              <Check size={16} className="text-secondary" />
              <span>Unlimited AI Agents</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Check size={16} className="text-secondary" />
              <span>Real-time Revenue Sync</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Check size={16} className={userProfile?.role === 'pro' ? "text-secondary" : "text-on-surface-variant/30"} />
              <span className={userProfile?.role === 'pro' ? "" : "text-on-surface-variant/50"}>Advanced Strategic Insights</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Check size={16} className={userProfile?.role === 'pro' ? "text-secondary" : "text-on-surface-variant/30"} />
              <span className={userProfile?.role === 'pro' ? "" : "text-on-surface-variant/50"}>Priority Node Processing</span>
            </div>
          </div>

          {userProfile?.role !== 'pro' ? (
            <button 
              onClick={handleUpgrade}
              disabled={isUpgrading}
              className="w-full py-4 bg-primary text-white font-bold rounded-xl hover:opacity-90 transition-all flex items-center justify-center gap-2"
            >
              {isUpgrading ? <Loader2 className="animate-spin" /> : <Zap size={18} />}
              Upgrade to Enterprise Pro
            </button>
          ) : (
            <button 
              onClick={() => handleAction('Manage Billing')}
              className="w-full py-4 bg-surface-high text-on-surface font-bold rounded-xl border border-outline/10 hover:bg-surface transition-all"
            >
              Manage Subscription
            </button>
          )}
        </div>

        <div className="space-y-4">
          <div className="bg-surface p-6 rounded-2xl border border-outline/10">
            <h3 className="text-sm font-bold mb-4">Add-ons</h3>
            <div className="flex items-center justify-between p-4 bg-surface-high rounded-xl border border-outline/10">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${userProfile?.sprintSetupEnabled ? 'bg-tertiary/10 text-tertiary' : 'bg-on-surface-variant/10 text-on-surface-variant'}`}>
                  <Calendar size={20} />
                </div>
                <div>
                  <h4 className="text-sm font-bold">Sprint Setup</h4>
                  <p className="text-xs text-on-surface-variant">One-time optimization fee</p>
                </div>
              </div>
              {userProfile?.sprintSetupEnabled ? (
                <span className="text-[10px] font-bold text-secondary uppercase tracking-widest">Active</span>
              ) : (
                <button 
                  onClick={handleSprintSetupPurchase}
                  disabled={isPurchasingSprintSetup}
                  className="px-4 py-2 bg-primary text-white text-[10px] font-bold rounded-lg hover:opacity-90 transition-all flex items-center gap-2"
                >
                  {isPurchasingSprintSetup ? <Loader2 size={12} className="animate-spin" /> : <Plus size={12} />}
                  Unlock ($49)
                </button>
              )}
            </div>
          </div>

          <div className="bg-surface p-6 rounded-2xl border border-outline/10">
            <h3 className="text-sm font-bold mb-4">Usage Statistics</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-[10px] font-mono uppercase mb-1">
                  <span>Node Utilization</span>
                  <span>75%</span>
                </div>
                <div className="h-1.5 w-full bg-surface-high rounded-full overflow-hidden">
                  <div className="h-full bg-primary w-3/4"></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-[10px] font-mono uppercase mb-1">
                  <span>AI Tokens</span>
                  <span>12.4k / 50k</span>
                </div>
                <div className="h-1.5 w-full bg-surface-high rounded-full overflow-hidden">
                  <div className="h-full bg-secondary w-1/4"></div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-surface p-6 rounded-2xl border border-outline/10">
            <h3 className="text-sm font-bold mb-2">Payment Method</h3>
            <div className="flex items-center gap-3 text-on-surface-variant text-sm">
              <CreditCard size={18} />
              <span>•••• •••• •••• 4242</span>
            </div>
          </div>
        </div>
      </div>
    </main>
  );

  const handleAddListing = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;

    setIsAddingListing(true);
    const formData = new FormData(e.currentTarget);
    const name = formData.get('name') as string;
    const address = formData.get('address') as string;
    const status = formData.get('status') as string;

    try {
      await addDoc(collection(db, `users/${user.uid}/listings`), {
        name,
        address,
        status,
        createdAt: serverTimestamp()
      });
      toast.success("Listing added successfully");
      (e.target as HTMLFormElement).reset();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}/listings`);
    } finally {
      setIsAddingListing(false);
    }
  };

  const handleAgentStatusToggle = async (agentId: string, currentStatus: string) => {
    try {
      const newStatus = currentStatus === 'Active' ? 'Paused' : 'Active';
      const newLabel = currentStatus === 'Active' ? 'Suspended' : 'Operational';
      await setDoc(doc(db, 'agents', agentId), { 
        status: newStatus,
        statusLabel: newLabel
      }, { merge: true });
      toast.success(`Agent ${newStatus.toLowerCase()} successfully`);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `agents/${agentId}`);
    }
  };

  const renderAnalytics = () => (
    <AnalyticsDashboard
      userId={user!.uid}
      onUploadClick={() => setShowUploadModal(true)}
    />
  );

  const renderAgentControl = () => (
    <main className="p-8 pb-24 space-y-10">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Agent Control</h1>
          <p className="text-on-surface-variant text-sm">Direct oversight of synthetic intelligence nodes.</p>
        </div>
        <button onClick={() => setShowLaunchModal(true)} className="px-6 py-3 bg-primary text-white font-bold rounded-xl hover:opacity-90 transition-all flex items-center gap-2">
          <Plus size={18} />
          Deploy New Node
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {agents.map((agent) => (
          <div key={agent.id} className="bg-surface p-6 rounded-2xl border border-outline/10 space-y-6 relative overflow-hidden group">
            <div className={`absolute top-0 right-0 w-24 h-24 -mr-8 -mt-8 opacity-5 group-hover:opacity-10 transition-opacity`}>
              {React.createElement(iconMap[agent.icon] || Cpu, { size: 96 })}
            </div>
            
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${agent.status === 'Active' ? 'bg-secondary/10 text-secondary' : 'bg-on-surface-variant/10 text-on-surface-variant'}`}>
                  {React.createElement(iconMap[agent.icon] || Cpu, { size: 20 })}
                </div>
                <div>
                  <h3 className="font-bold">{agent.role}</h3>
                  <p className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant">{agent.statusLabel}</p>
                </div>
              </div>
              <div className={`w-2 h-2 rounded-full ${agent.status === 'Active' ? 'bg-secondary animate-pulse' : 'bg-on-surface-variant'}`}></div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between text-[10px] font-mono uppercase">
                <span className="text-on-surface-variant">Efficiency</span>
                <span>{agent.efficiency}%</span>
              </div>
              <div className="h-1.5 w-full bg-surface-high rounded-full overflow-hidden">
                <div className={`h-full bg-primary transition-all duration-1000`} style={{ width: `${agent.efficiency}%` }}></div>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button 
                onClick={() => handleAgentStatusToggle(agent.id, agent.status)}
                className="flex-1 py-2 bg-surface-high border border-outline/10 rounded-lg text-xs font-bold hover:bg-outline/5 transition-all"
              >
                {agent.status === 'Active' ? 'Pause Node' : 'Resume Node'}
              </button>
              <button className="p-2 bg-surface-high border border-outline/10 rounded-lg hover:bg-outline/5 transition-all">
                <Settings size={16} className="text-on-surface-variant" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </main>
  );

  const renderListings = () => (
    <main className="p-8 pb-24 space-y-10">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Listings</h1>
          <p className="text-on-surface-variant text-sm">Manage your short-term rental property portfolio.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <section className="bg-surface p-8 rounded-2xl border border-outline/10 space-y-6 sticky top-24">
            <h3 className="text-lg font-bold">Add New Listing</h3>
            <form onSubmit={handleAddListing} className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant">Property Name</label>
                <input required name="name" className="w-full bg-surface-high border border-outline/10 rounded-xl px-4 py-3 text-sm focus:ring-1 ring-primary outline-none" placeholder="e.g. Sunset Villa" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant">Address</label>
                <input required name="address" className="w-full bg-surface-high border border-outline/10 rounded-xl px-4 py-3 text-sm focus:ring-1 ring-primary outline-none" placeholder="123 Ocean Drive..." />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant">Initial Status</label>
                <select name="status" className="w-full bg-surface-high border border-outline/10 rounded-xl px-4 py-3 text-sm focus:ring-1 ring-primary outline-none">
                  <option value="Available">Available</option>
                  <option value="Occupied">Occupied</option>
                  <option value="Cleaning">Cleaning</option>
                  <option value="Maintenance">Maintenance</option>
                </select>
              </div>
              <button disabled={isAddingListing} className="w-full py-3 bg-primary text-white font-bold rounded-xl hover:opacity-90 transition-all flex items-center justify-center gap-2">
                {isAddingListing ? <Loader2 size={18} className="animate-spin" /> : <Plus size={18} />}
                Create Listing
              </button>
            </form>
          </section>
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {listings.map((listing) => (
              <div key={listing.id} className="bg-surface p-6 rounded-2xl border border-outline/10 space-y-4 hover:border-primary/30 transition-all group">
                <div className="flex justify-between items-start">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                    <Building2 size={24} />
                  </div>
                  <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${
                    listing.status === 'Available' ? 'bg-secondary/10 text-secondary' : 
                    listing.status === 'Occupied' ? 'bg-tertiary/10 text-tertiary' : 
                    'bg-on-surface-variant/10 text-on-surface-variant'
                  }`}>
                    {listing.status}
                  </span>
                </div>
                <div>
                  <h4 className="font-bold text-lg">{listing.name}</h4>
                  <p className="text-xs text-on-surface-variant">{listing.address}</p>
                </div>
                <div className="pt-4 border-t border-outline/5 flex justify-between items-center">
                  <span className="text-[10px] font-mono text-on-surface-variant">ID: {listing.id.substring(0, 8)}</span>
                  <button className="text-xs font-bold text-primary hover:underline">View Details</button>
                </div>
              </div>
            ))}
            {listings.length === 0 && (
              <div className="col-span-full p-12 text-center bg-surface-high/30 rounded-2xl border border-dashed border-outline/20">
                <p className="text-on-surface-variant">No listings found. Add your first property to begin tracking.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );

  const renderSettings = () => (
    <main className="p-8 pb-24 space-y-10 max-w-4xl">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-on-surface-variant text-sm">Manage your account and platform preferences.</p>
      </div>

      <div className="grid grid-cols-1 gap-8">
        <section className="bg-surface p-8 rounded-2xl border border-outline/10 space-y-8">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-surface-high border-2 border-primary/20 flex items-center justify-center overflow-hidden">
              {userProfile?.photoURL ? (
                <img src={userProfile.photoURL} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <span className="text-2xl font-bold text-primary">{userProfile?.displayName?.[0] || 'U'}</span>
              )}
            </div>
            <div>
              <h2 className="text-xl font-bold">{userProfile?.displayName || 'User'}</h2>
              <p className="text-sm text-on-surface-variant">{userProfile?.email}</p>
            </div>
          </div>

          <form onSubmit={handleUpdateProfile} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant">Display Name</label>
                <div className="flex gap-2">
                  <input 
                    name="displayName"
                    type="text" 
                    defaultValue={userProfile?.displayName || ''}
                    className="flex-1 bg-surface-high border border-outline/10 rounded-xl px-4 py-3 text-sm focus:ring-1 ring-primary outline-none transition-all"
                    placeholder="Your name"
                  />
                  <button 
                    type="submit"
                    disabled={isSavingSettings}
                    className="px-4 py-3 bg-surface-high border border-outline/10 rounded-xl text-primary hover:bg-primary hover:text-white transition-all disabled:opacity-50"
                    title="Update Name"
                  >
                    {isSavingSettings ? <Loader2 size={18} className="animate-spin" /> : <Check size={18} />}
                  </button>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant">Photo URL</label>
                <input 
                  name="photoURL"
                  type="url" 
                  defaultValue={userProfile?.photoURL || ''}
                  className="w-full bg-surface-high border border-outline/10 rounded-xl px-4 py-3 text-sm focus:ring-1 ring-primary outline-none transition-all"
                  placeholder="https://example.com/photo.jpg"
                />
              </div>
            </div>

            <div className="pt-4">
              <button 
                type="submit"
                disabled={isSavingSettings}
                className="px-6 py-3 bg-primary text-white font-bold rounded-xl hover:opacity-90 transition-all flex items-center gap-2 disabled:opacity-50"
              >
                {isSavingSettings ? <Loader2 size={18} className="animate-spin" /> : <ShieldCheck size={18} />}
                Save Changes
              </button>
            </div>
          </form>
        </section>

        <section className="bg-surface p-8 rounded-2xl border border-outline/10 space-y-6">
          <h3 className="text-lg font-bold">Account Security</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-surface-high rounded-xl border border-outline/10">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-secondary/10 flex items-center justify-center text-secondary">
                  <ShieldCheck size={20} />
                </div>
                <div>
                  <h4 className="text-sm font-bold">Two-Factor Authentication</h4>
                  <p className="text-xs text-on-surface-variant">Add an extra layer of security to your account.</p>
                </div>
              </div>
              <button className="text-xs font-bold text-primary uppercase tracking-widest hover:underline">Enable</button>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-surface-high rounded-xl border border-outline/10">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-tertiary/10 flex items-center justify-center text-tertiary">
                  <AuditIcon size={20} />
                </div>
                <div>
                  <h4 className="text-sm font-bold">Session Management</h4>
                  <p className="text-xs text-on-surface-variant">View and manage your active sessions.</p>
                </div>
              </div>
              <button className="text-xs font-bold text-primary uppercase tracking-widest hover:underline">Manage</button>
            </div>
          </div>

          <div className="pt-6 border-t border-outline/10">
            <h4 className="text-sm font-bold mb-4">Change Password</h4>
            <form onSubmit={handleChangePassword} className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant">Current Password</label>
                <input 
                  type="password"
                  required
                  value={passwordForm.currentPassword}
                  onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })}
                  className="w-full bg-surface-high border border-outline/10 rounded-xl px-4 py-3 text-sm focus:ring-1 ring-primary outline-none transition-all"
                  placeholder="••••••••"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant">New Password</label>
                <input 
                  type="password"
                  required
                  value={passwordForm.newPassword}
                  onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
                  className="w-full bg-surface-high border border-outline/10 rounded-xl px-4 py-3 text-sm focus:ring-1 ring-primary outline-none transition-all"
                  placeholder="••••••••"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant">Confirm New Password</label>
                <div className="flex gap-2">
                  <input 
                    type="password"
                    required
                    value={passwordForm.confirmPassword}
                    onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                    className="flex-1 bg-surface-high border border-outline/10 rounded-xl px-4 py-3 text-sm focus:ring-1 ring-primary outline-none transition-all"
                    placeholder="••••••••"
                  />
                  <button 
                    type="submit"
                    disabled={isChangingPassword}
                    className="px-4 bg-primary text-white rounded-xl hover:opacity-90 transition-all disabled:opacity-50 flex items-center justify-center"
                  >
                    {isChangingPassword ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />}
                  </button>
                </div>
              </div>
            </form>
            <p className="mt-2 text-[10px] text-on-surface-variant italic">
              Note: If you signed in with Google, you must set a password in your account settings first.
            </p>
          </div>
        </section>

        <section className="bg-surface p-8 rounded-2xl border border-destructive/20 space-y-6">
          <h3 className="text-lg font-bold text-destructive">Danger Zone</h3>
          <div className="p-6 bg-destructive/5 rounded-xl border border-destructive/10 flex items-center justify-between">
            <div>
              <h4 className="text-sm font-bold">Delete Account</h4>
              <p className="text-xs text-on-surface-variant">Permanently remove your account and all associated data.</p>
            </div>
            <button 
              onClick={() => setShowDeleteModal(true)}
              className="px-4 py-2 bg-destructive/10 text-destructive text-xs font-bold rounded-lg hover:bg-destructive hover:text-white transition-all"
            >
              Delete Account
            </button>
          </div>
        </section>
      </div>
    </main>
  );

  return (
    <div className="min-h-screen bg-background text-on-surface selection:bg-primary/30">
      <Toaster position="top-right" theme="dark" />
      
      {/* Delete Account Confirmation Modal */}
      <AnimatePresence>
        {showDeleteModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                if (!isDeletingAccount) {
                  setShowDeleteModal(false);
                  setDeleteConfirmationText('');
                }
              }}
              className="absolute inset-0 bg-background/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative bg-surface border border-destructive/30 p-8 rounded-2xl max-w-md w-full shadow-2xl space-y-6"
            >
              <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center text-destructive mx-auto">
                <AlertCircle size={32} />
              </div>
              <div className="text-center space-y-2">
                <h3 className="text-xl font-bold">Delete Account?</h3>
                <p className="text-sm text-on-surface-variant">
                  This action is permanent. All your data, including revenue snapshots, cfo insights, and listings will be permanently removed.
                </p>
              </div>

              <div className="space-y-2">
                <p className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant text-center">
                  Type <span className="text-destructive font-bold">DELETE ACCOUNT</span> to confirm
                </p>
                <input 
                  type="text"
                  value={deleteConfirmationText}
                  onChange={(e) => setDeleteConfirmationText(e.target.value)}
                  placeholder="DELETE ACCOUNT"
                  className="w-full bg-surface-high border border-outline/10 rounded-xl px-4 py-3 text-sm text-center focus:ring-1 ring-destructive outline-none transition-all"
                />
              </div>

              <div className="flex gap-4">
                <button 
                  disabled={isDeletingAccount}
                  onClick={() => {
                    setShowDeleteModal(false);
                    setDeleteConfirmationText('');
                  }}
                  className="flex-1 py-3 bg-surface-high border border-outline/10 rounded-xl font-bold hover:bg-outline/5 transition-all disabled:opacity-50"
                >
                  Cancel
                </button>
                <button 
                  disabled={isDeletingAccount || deleteConfirmationText !== 'DELETE ACCOUNT'}
                  onClick={handleDeleteAccount}
                  className="flex-1 py-3 bg-destructive text-white rounded-xl font-bold hover:opacity-90 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isDeletingAccount ? <Loader2 size={18} className="animate-spin" /> : <X size={18} />}
                  Delete Forever
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className="fixed left-0 top-0 bottom-0 w-64 bg-surface border-r border-outline/10 z-50 flex flex-col">
        <div className="p-6 mb-4">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary status-glow-blue">
              <Cpu size={24} />
            </div>
            <h1 className="text-xl font-bold tracking-tighter">CompliCore</h1>
          </div>
          <p className="text-[10px] font-mono text-on-surface-variant uppercase tracking-widest">Synthetic Intelligence</p>
        </div>

        <nav className="flex-1 overflow-y-auto">
          <SidebarItem icon={LayoutDashboard} label="Dashboard" active={activeSidebar === 'Dashboard'} onClick={() => handleSidebarClick('Dashboard')} />
          <SidebarItem icon={Cpu} label="Agent Control" active={activeSidebar === 'Agent Control'} onClick={() => handleSidebarClick('Agent Control')} />
          <SidebarItem icon={BarChart3} label="Analytics" active={activeSidebar === 'Analytics'} onClick={() => handleSidebarClick('Analytics')} />
          <SidebarItem icon={Database} label="Data Library" active={activeSidebar === 'Data Library'} onClick={() => handleSidebarClick('Data Library')} />
          <SidebarItem icon={ListTodo} label="Listings" active={activeSidebar === 'Listings'} onClick={() => handleSidebarClick('Listings')} />
          <SidebarItem icon={CreditCard} label="Billing" active={activeSidebar === 'Billing'} onClick={() => handleSidebarClick('Billing')} />
          <SidebarItem icon={Settings} label="Settings" active={activeSidebar === 'Settings'} onClick={() => handleSidebarClick('Settings')} />
          <SidebarItem icon={AuditIcon} label="Audit Trail" active={activeSidebar === 'Audit Trail'} onClick={() => handleSidebarClick('Audit Trail')} />
        </nav>

        <div className="p-4 border-t border-outline/10 space-y-2">
          <SidebarItem icon={HelpCircle} label="Help Center" onClick={() => handleAction('Help Center')} />
          <div className="pt-4 mt-4 border-t border-outline/10 flex items-center justify-between px-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-surface-high border border-outline/20 flex items-center justify-center overflow-hidden">
                {userProfile?.photoURL ? (
                  <img src={userProfile.photoURL} alt="P" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <span className="text-xs font-bold">{userProfile?.displayName?.[0] || 'U'}</span>
                )}
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold truncate w-24">{userProfile?.displayName || 'User'}</span>
                <span className="text-[9px] text-on-surface-variant uppercase">{userProfile?.role || 'Viewer'}</span>
              </div>
            </div>
            <button onClick={() => logout()} className="text-on-surface-variant hover:text-tertiary transition-colors">
              <LogOut size={16} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="pl-64 min-h-screen flex flex-col">
        {/* Header */}
        <header className="h-16 border-b border-outline/10 flex items-center justify-between px-8 bg-background/80 backdrop-blur-md sticky top-0 z-40">
          <div className="flex items-center gap-4 flex-1 max-w-xl">
            <div className="relative w-full group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant group-focus-within:text-primary transition-colors" size={16} />
              <input 
                type="text" 
                placeholder="Search agents, nodes, or intelligence logs..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-surface-high border border-outline/10 rounded-lg py-2 pl-10 pr-4 text-sm focus:ring-1 ring-primary outline-none transition-all"
              />
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={() => handleAction('Notifications')} className="p-2 rounded-lg hover:bg-surface-high text-on-surface-variant transition-colors relative">
              <Bell size={20} />
              <span className="absolute top-2 right-2 w-2 h-2 bg-tertiary rounded-full border-2 border-background"></span>
            </button>
            <button
              onClick={() => setShowUploadModal(true)}
              className="flex items-center gap-2 bg-surface-high border border-outline/20 text-on-surface px-4 py-2 rounded-lg text-sm font-bold hover:bg-primary hover:text-white hover:border-primary transition-all"
            >
              <Database size={16} />
              Upload Data
            </button>
            <button onClick={() => setShowLaunchModal(true)} className="flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-lg text-sm font-bold hover:opacity-90 transition-all shadow-lg shadow-primary/20">
              <Plus size={18} />
              Launch Agent
            </button>
          </div>
        </header>

        {/* Dynamic Content Rendering */}
        {activeSidebar === 'Dashboard' && renderDashboard()}
        {activeSidebar === 'Audit Trail' && renderAuditTrail()}
        {activeSidebar === 'Billing' && renderBilling()}
        {activeSidebar === 'Settings' && renderSettings()}
        {activeSidebar === 'Analytics' && renderAnalytics()}
        {activeSidebar === 'Agent Control' && renderAgentControl()}
        {activeSidebar === 'Listings' && renderListings()}
        {activeSidebar === 'Data Library' && (
          <DatasetLibrary
            userId={user.uid}
            onUploadClick={() => setShowUploadModal(true)}
          />
        )}

        {/* Placeholder for other views */}
        {['Agent Control', 'Analytics', 'Listings'].includes(activeSidebar) && (
          <main className="p-8 flex flex-col items-center justify-center flex-1 text-center space-y-4">
            <div className="w-20 h-20 bg-surface-high rounded-3xl flex items-center justify-center text-on-surface-variant/20">
              {activeSidebar === 'Agent Control' ? <Cpu size={48} /> : activeSidebar === 'Analytics' ? <BarChart3 size={48} /> : <ListTodo size={48} />}
            </div>
            <h2 className="text-2xl font-bold">{activeSidebar} Module</h2>
            <p className="text-on-surface-variant max-w-md">This module is currently in synchronization. Check back after the next intelligence epoch.</p>
          </main>
        )}

        {/* Footer */}
        <footer className="fixed bottom-0 right-0 left-64 h-8 flex items-center justify-between px-6 z-40 bg-background border-t border-outline/10 text-[10px] uppercase tracking-widest font-mono">
          <div className="flex items-center gap-6">
            <span className="text-secondary flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-secondary animate-pulse"></span>
              API CONNECTED
            </span>
            <span className="text-on-surface-variant/50">12 AGENTS ACTIVE</span>
            <span className="text-on-surface-variant/50">LAST SYNC: 1M AGO</span>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={() => handleAction('Status Page')} className="text-on-surface-variant/50 hover:text-secondary transition-colors uppercase">Status</button>
            <button onClick={() => handleAction('Documentation')} className="text-on-surface-variant/50 hover:text-secondary transition-colors uppercase">Docs</button>
            <button onClick={() => handleAction('System Logs')} className="text-on-surface-variant/50 hover:text-secondary transition-colors uppercase">Logs</button>
          </div>
        </footer>
        {/* Modals */}
        <AnimatePresence>
          {showLaunchModal && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowLaunchModal(false)}
                className="absolute inset-0 bg-background/80 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative w-full max-w-md bg-surface border border-outline/20 rounded-2xl p-6 shadow-2xl"
              >
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-bold">Launch New Agent</h3>
                  <button onClick={() => setShowLaunchModal(false)} className="text-on-surface-variant hover:text-on-surface">
                    <X size={20} />
                  </button>
                </div>
                <form onSubmit={handleLaunchAgent} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-mono uppercase text-on-surface-variant mb-1">Agent Role</label>
                    <select name="role" className="w-full bg-surface-high border border-outline/20 rounded-lg px-4 py-2 text-sm focus:ring-1 ring-primary outline-none">
                      <option>Support Specialist</option>
                      <option>Financial Analyst</option>
                      <option>Marketing Automation</option>
                      <option>Security Auditor</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono uppercase text-on-surface-variant mb-1">Node Assignment</label>
                    <input name="node" type="text" placeholder="e.g. Node-14" className="w-full bg-surface-high border border-outline/20 rounded-lg px-4 py-2 text-sm focus:ring-1 ring-primary outline-none" required />
                  </div>
                  <button 
                    type="submit"
                    disabled={isLaunching}
                    className="w-full bg-primary text-white font-bold py-3 rounded-xl hover:opacity-90 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isLaunching ? <Loader2 className="animate-spin" size={18} /> : <Plus size={18} />}
                    {isLaunching ? 'Deploying...' : 'Launch Agent'}
                  </button>
                </form>
              </motion.div>
            </div>
          )}

          {selectedAgent && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setSelectedAgent(null)}
                className="absolute inset-0 bg-background/80 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative w-full max-w-2xl bg-surface border border-outline/20 rounded-2xl p-8 shadow-2xl max-h-[90vh] overflow-y-auto"
              >
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl ${selectedAgent.colorClass}/10 flex items-center justify-center ${selectedAgent.colorClass} ${selectedAgent.glowClass}`}>
                      {React.createElement(iconMap[selectedAgent.icon] || Cpu, { size: 24 })}
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold">{selectedAgent.role} Agent</h3>
                      <p className="text-on-surface-variant text-sm">{selectedAgent.statusLabel}</p>
                    </div>
                  </div>
                  <button onClick={() => setSelectedAgent(null)} className="text-on-surface-variant hover:text-on-surface">
                    <X size={24} />
                  </button>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <div className="bg-surface-high p-4 rounded-xl border border-outline/10">
                    <p className="text-[10px] font-mono text-on-surface-variant uppercase mb-1">Uptime</p>
                    <p className="text-lg font-bold">{selectedAgent.uptime || '99.98'}%</p>
                  </div>
                  <div className="bg-surface-high p-4 rounded-xl border border-outline/10">
                    <p className="text-[10px] font-mono text-on-surface-variant uppercase mb-1">Efficiency</p>
                    <p className="text-lg font-bold">{selectedAgent.efficiency || '94.2'}%</p>
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="glass-panel p-6 min-h-[200px] relative">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <ShieldCheck size={16} className="text-secondary" />
                        <span className="text-[10px] font-mono uppercase text-on-surface-variant">Intelligence Report</span>
                      </div>
                      <button 
                        onClick={() => handleGetAgentReport(selectedAgent)}
                        disabled={isGeneratingReport}
                        className="text-[10px] font-mono uppercase text-primary hover:underline disabled:opacity-50"
                      >
                        {isGeneratingReport ? 'Generating...' : 'Refresh Report'}
                      </button>
                    </div>
                    
                    {isGeneratingReport ? (
                      <div className="flex flex-col items-center justify-center py-12 gap-4">
                        <Loader2 className="animate-spin text-primary" size={32} />
                        <p className="text-xs font-mono text-on-surface-variant animate-pulse">Consulting Gemini Neural Network...</p>
                      </div>
                    ) : agentReport ? (
                      <div className="prose prose-invert prose-sm max-w-none">
                        <Markdown>{agentReport}</Markdown>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-12 text-center">
                        <Sparkles size={32} className="text-on-surface-variant/20 mb-4" />
                        <p className="text-sm text-on-surface-variant">No active report. Click refresh to generate a real-time intelligence summary.</p>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <button onClick={() => handleAction('Reboot Agent')} className="py-3 rounded-xl border border-outline/20 hover:bg-surface-high transition-all text-sm font-medium">Reboot Agent</button>
                    <button onClick={() => handleAction('View Logs')} className="py-3 rounded-xl border border-outline/20 hover:bg-surface-high transition-all text-sm font-medium">View Logs</button>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Data Upload Modal */}
        <AnimatePresence>
          {showUploadModal && (
            <DataUpload
              userId={user.uid}
              onClose={() => setShowUploadModal(false)}
              onSaved={() => {
                if (activeSidebar !== 'Data Library') {
                  handleSidebarClick('Data Library');
                }
              }}
            />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
