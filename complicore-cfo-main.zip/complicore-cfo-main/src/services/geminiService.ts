import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function generateAgentReport(agentRole: string, status: string, statusLabel: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a professional, concise intelligence report for the ${agentRole} AI agent. 
      Current Status: ${status} (${statusLabel}).
      Include:
      1. A summary of recent autonomous actions.
      2. Key performance metrics (simulated but realistic).
      3. Strategic recommendations for the next 24 hours.
      Format the output in clean Markdown.`,
      config: {
        temperature: 0.7,
        topP: 0.95,
        topK: 64,
      },
    });

    return response.text || "Failed to generate intelligence report.";
  } catch (error) {
    console.error("Gemini AI Error:", error);
    return "Intelligence report generation failed due to an internal AI error.";
  }
}

export async function analyzeUploadedDataset(columns: string[], sampleRows: object[]): Promise<string> {
  try {
    const columnList = columns.join(', ');
    const sampleJson = JSON.stringify(sampleRows.slice(0, 20), null, 2);
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a CFO intelligence assistant. Analyze this uploaded dataset and provide instant financial insight.

Dataset columns: ${columnList}

Sample rows (up to 20):
${sampleJson}

Provide a concise Markdown response covering:
1. **What financial metrics are present** — identify revenue, cost, profit, churn, MRR, ARR, or any other financial KPIs you detect in the columns/data.
2. **Data quality assessment** — note any missing values, suspicious data, or formatting issues.
3. **CFO Analysis potential** — suggest 3–5 specific analyses that can be performed on this dataset (e.g., "Monthly revenue trend", "Churn cohort analysis", "Customer LTV segmentation").
4. **Key observations** — any immediate insights visible in the sample data.

Keep it sharp and actionable. Use bullet points. Aim for 200–300 words.`,
      config: {
        temperature: 0.4,
        topP: 0.9,
      },
    });
    return response.text || "Unable to analyze dataset.";
  } catch (error) {
    console.error("Gemini AI Error:", error);
    return "Dataset analysis unavailable due to an AI service error.";
  }
}

export async function analyzeCFOReport(
  datasetName: string,
  columns: string[],
  rows: object[],
  onChunk: (chunk: string) => void
): Promise<string> {
  try {
    const rowCount = rows.length;
    const previewRows = rows.slice(0, 50);
    const prompt = `You are a CFO AI analyst. Analyze this revenue dataset and produce a comprehensive CFO report.

Dataset: ${datasetName}
Columns: ${columns.join(', ')}
Data (${rowCount} rows, showing first ${Math.min(50, rowCount)}):
${JSON.stringify(previewRows, null, 2)}

Produce a structured CFO report with these sections:
## Executive Summary
## Revenue Trends
## Key Metrics & KPIs
## Risk Flags
## Strategic Recommendations

Be specific and data-driven. Reference actual numbers from the dataset.`;

    const stream = await ai.models.generateContentStream({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        temperature: 0.4,
        topP: 0.9,
      },
    });

    let fullText = '';
    for await (const chunk of stream) {
      const text = chunk.text ?? '';
      if (text) {
        fullText += text;
        onChunk(text);
      }
    }
    return fullText;
  } catch (error) {
    console.error('Gemini CFO Report Error:', error);
    const errorMsg =
      error instanceof Error
        ? `CFO report generation failed: ${error.message}`
        : 'CFO report generation failed due to an internal AI error.';
    return errorMsg;
  }
}

export async function analyzeRevenueData(mrr: string, churn: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze the following revenue data for a SaaS company:
      MRR: ${mrr}
      Churn: ${churn}
      Provide a brief (2-3 sentence) strategic insight and one actionable recommendation.`,
      config: {
        temperature: 0.5,
      },
    });

    return response.text || "No insights available.";
  } catch (error) {
    console.error("Gemini AI Error:", error);
    return "Revenue analysis unavailable.";
  }
}
