import {
  collection,
  doc,
  addDoc,
  getDocs,
  deleteDoc,
  query,
  orderBy,
  serverTimestamp,
  Timestamp,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import type { RevenueRow } from './dataParserService';

// ─── Types ─────────────────────────────────────────────────────────────────

export interface UploadRecord {
  id: string;
  fileName: string;
  fileType: 'csv' | 'json';
  rowCount: number;
  columns: string[];
  rows: RevenueRow[];
  uploadedAt: Timestamp | null;
}

// ─── Firestore path ─────────────────────────────────────────────────────────
// revenue_uploads/{userId}/uploads/{uploadId}

function uploadsCollection(userId: string) {
  return collection(db, 'revenue_uploads', userId, 'uploads');
}

// ─── Write ──────────────────────────────────────────────────────────────────

/**
 * Save a parsed revenue upload to Firestore.
 * Returns the new document ID.
 */
export async function saveUpload(
  userId: string,
  payload: {
    fileName: string;
    fileType: 'csv' | 'json';
    rowCount: number;
    columns: string[];
    rows: RevenueRow[];
  }
): Promise<string> {
  const path = `revenue_uploads/${userId}/uploads`;
  try {
    const ref = await addDoc(uploadsCollection(userId), {
      fileName: payload.fileName,
      fileType: payload.fileType,
      rowCount: payload.rowCount,
      columns: payload.columns,
      rows: payload.rows,
      uploadedAt: serverTimestamp(),
    });
    return ref.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
    throw error; // handleFirestoreError throws, but TS needs this line
  }
}

// ─── Read ────────────────────────────────────────────────────────────────────

/**
 * Fetch all uploads for a user, newest first.
 */
export async function listUploads(userId: string): Promise<UploadRecord[]> {
  const path = `revenue_uploads/${userId}/uploads`;
  try {
    const q = query(uploadsCollection(userId), orderBy('uploadedAt', 'desc'));
    const snap = await getDocs(q);
    return snap.docs.map(d => ({
      id: d.id,
      ...(d.data() as Omit<UploadRecord, 'id'>),
    }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    throw error;
  }
}

// ─── Delete ──────────────────────────────────────────────────────────────────

/**
 * Delete a single upload document.
 */
export async function deleteUpload(userId: string, uploadId: string): Promise<void> {
  const path = `revenue_uploads/${userId}/uploads/${uploadId}`;
  try {
    await deleteDoc(doc(db, 'revenue_uploads', userId, 'uploads', uploadId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
    throw error;
  }
}
