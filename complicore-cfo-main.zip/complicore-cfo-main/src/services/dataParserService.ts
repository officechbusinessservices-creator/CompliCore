import Papa from 'papaparse';

export interface RevenueRow {
  [key: string]: string | number | null;
}

export interface ParseResult {
  rows: RevenueRow[];
  columns: string[];
  rowCount: number;
  fileType: 'csv' | 'json';
  errors: string[];
}

/**
 * Parse a CSV file using PapaParse.
 * Returns typed RevenueRow[] with inferred numeric values.
 */
export function parseCSV(file: File): Promise<ParseResult> {
  return new Promise((resolve, reject) => {
    Papa.parse<RevenueRow>(file, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: true,
      complete(results) {
        if (results.errors.length > 0 && results.data.length === 0) {
          reject(new Error(results.errors.map(e => e.message).join('; ')));
          return;
        }

        const columns = results.meta.fields ?? [];
        const rows = results.data as RevenueRow[];
        const errors = results.errors.map(e => `Row ${e.row ?? '?'}: ${e.message}`);

        resolve({
          rows,
          columns,
          rowCount: rows.length,
          fileType: 'csv',
          errors,
        });
      },
      error(err) {
        reject(new Error(err.message));
      },
    });
  });
}

/**
 * Parse a JSON revenue export file.
 * Accepts either an array of objects or { data: [...] } envelope.
 */
export async function parseJSON(file: File): Promise<ParseResult> {
  const text = await file.text();
  let parsed: unknown;

  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error('Invalid JSON: could not parse file.');
  }

  let rows: RevenueRow[];

  if (Array.isArray(parsed)) {
    rows = parsed as RevenueRow[];
  } else if (
    typeof parsed === 'object' &&
    parsed !== null &&
    'data' in parsed &&
    Array.isArray((parsed as { data: unknown }).data)
  ) {
    rows = (parsed as { data: RevenueRow[] }).data;
  } else {
    throw new Error('JSON must be an array of objects or { data: [...] } envelope.');
  }

  if (rows.length === 0) {
    throw new Error('JSON file contains no rows.');
  }

  // Validate each row is a plain object
  const invalidRows = rows.filter(r => typeof r !== 'object' || r === null || Array.isArray(r));
  if (invalidRows.length > 0) {
    throw new Error(`JSON rows must be objects. Found ${invalidRows.length} invalid row(s).`);
  }

  const columns = Object.keys(rows[0]);

  return {
    rows,
    columns,
    rowCount: rows.length,
    fileType: 'json',
    errors: [],
  };
}

/**
 * Dispatch to parseCSV or parseJSON based on file extension.
 */
export async function parseRevenueFile(file: File): Promise<ParseResult> {
  const name = file.name.toLowerCase();
  if (name.endsWith('.csv')) {
    return parseCSV(file);
  }
  if (name.endsWith('.json')) {
    return parseJSON(file);
  }
  throw new Error('Unsupported file type. Please upload a .csv or .json file.');
}
