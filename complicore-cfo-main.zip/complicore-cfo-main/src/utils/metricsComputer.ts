// ─── Types ───────────────────────────────────────────────────────────────────

export interface DatasetDoc {
  id: string;
  name: string;
  columns: string[];
  rows: Record<string, unknown>[];
  rowCount: number;
  uploadedAt: { toDate(): Date } | null;
}

export interface PeriodPoint {
  period: string;        // label for X axis
  revenue: number;
  churn: number | null;  // null = not available
  growthRate: number | null;
}

export interface RevenueMetrics {
  series: PeriodPoint[];
  currentMRR: number;
  totalRevenue: number;
  avgGrowthRate: number;    // decimal, e.g. 0.12 = 12%
  currentChurnRate: number; // decimal, e.g. 0.024 = 2.4%
  revenueColumn: string | null;
  dateColumn: string | null;
  churnColumn: string | null;
  rowCount: number;
  datasetName: string;
}

// ─── Column detection ────────────────────────────────────────────────────────

const REVENUE_KEYS = /revenue|mrr|arr|amount|sales|income|total|value|price|proceeds|receipts/i;
const DATE_KEYS = /date|month|period|time|year|day|week|quarter/i;
const CHURN_KEYS = /churn|attrition|cancel|lost|churned/i;

function isNumericColumn(rows: Record<string, unknown>[], col: string): boolean {
  const sample = rows.slice(0, 20).filter(r => r[col] !== null && r[col] !== undefined && r[col] !== '');
  if (sample.length === 0) return false;
  const numericCount = sample.filter(r => !isNaN(Number(r[col]))).length;
  return numericCount / sample.length >= 0.8;
}

function isDateColumn(rows: Record<string, unknown>[], col: string): boolean {
  const sample = rows.slice(0, 20).filter(r => r[col] !== null && r[col] !== undefined && r[col] !== '');
  if (sample.length === 0) return false;
  const dateCount = sample.filter(r => {
    const v = String(r[col]);
    return !isNaN(Date.parse(v)) && isNaN(Number(v));
  }).length;
  return dateCount / sample.length >= 0.7;
}

export function detectColumns(columns: string[], rows: Record<string, unknown>[]): {
  revenueCol: string | null;
  dateCol: string | null;
  churnCol: string | null;
} {
  // Churn
  const churnCol = columns.find(c => CHURN_KEYS.test(c) && isNumericColumn(rows, c)) ?? null;

  // Date
  const dateCol =
    columns.find(c => DATE_KEYS.test(c) && isDateColumn(rows, c)) ??
    columns.find(c => DATE_KEYS.test(c)) ??
    null;

  // Revenue: named match first, then highest-sum numeric column
  const revenueCol =
    columns.find(c => REVENUE_KEYS.test(c) && isNumericColumn(rows, c)) ??
    (() => {
      let bestCol: string | null = null;
      let bestSum = -Infinity;
      for (const col of columns) {
        if (!isNumericColumn(rows, col)) continue;
        const sum = rows.reduce((acc, r) => acc + (Number(r[col]) || 0), 0);
        if (sum > bestSum) { bestSum = sum; bestCol = col; }
      }
      return bestCol;
    })();

  return { revenueCol, dateCol, churnCol };
}

// ─── Series builder ──────────────────────────────────────────────────────────

function formatPeriodLabel(raw: unknown, index: number): string {
  if (raw === null || raw === undefined || raw === '') return `P${index + 1}`;
  const str = String(raw);
  const d = new Date(str);
  if (!isNaN(d.getTime()) && isNaN(Number(str))) {
    return d.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
  }
  return str.length > 10 ? str.slice(0, 10) : str;
}

function buildSeriesFromRows(
  rows: Record<string, unknown>[],
  revenueCol: string,
  dateCol: string | null,
  churnCol: string | null,
): PeriodPoint[] {
  if (dateCol) {
    // Group by period label
    const map = new Map<string, { revenue: number; churnSum: number; count: number; sortKey: number }>();
    rows.forEach((row, i) => {
      const label = formatPeriodLabel(row[dateCol], i);
      const rev = Number(row[revenueCol]) || 0;
      const churn = churnCol ? (Number(row[churnCol]) || 0) : 0;
      const existing = map.get(label);
      // sortKey: try to parse as date epoch, else use insertion order
      const rawVal = row[dateCol];
      const d = rawVal ? new Date(String(rawVal)) : null;
      const sortKey = d && !isNaN(d.getTime()) ? d.getTime() : i;
      if (existing) {
        existing.revenue += rev;
        existing.churnSum += churn;
        existing.count += 1;
      } else {
        map.set(label, { revenue: rev, churnSum: churn, count: 1, sortKey });
      }
    });

    const sorted = [...map.entries()].sort((a, b) => a[1].sortKey - b[1].sortKey);
    return sorted.map(([period, { revenue, churnSum, count }], i, arr) => {
      const prevRevenue = i > 0 ? arr[i - 1][1].revenue : null;
      const growthRate = prevRevenue && prevRevenue !== 0
        ? (revenue - prevRevenue) / prevRevenue
        : null;
      return {
        period,
        revenue,
        churn: churnCol ? churnSum / count : null,
        growthRate,
      };
    });
  } else {
    // No date column: each row is its own period
    return rows.slice(0, 50).map((row, i) => {
      const revenue = Number(row[revenueCol]) || 0;
      const prevRevenue = i > 0 ? (Number(rows[i - 1][revenueCol]) || 0) : null;
      const growthRate = prevRevenue !== null && prevRevenue !== 0
        ? (revenue - prevRevenue) / prevRevenue
        : null;
      return {
        period: `Row ${i + 1}`,
        revenue,
        churn: churnCol ? (Number(row[churnCol]) || 0) : null,
        growthRate,
      };
    });
  }
}

// ─── Main entry ──────────────────────────────────────────────────────────────

export function computeMetrics(dataset: DatasetDoc): RevenueMetrics {
  const { columns, rows, name } = dataset;

  const empty: RevenueMetrics = {
    series: [],
    currentMRR: 0,
    totalRevenue: 0,
    avgGrowthRate: 0,
    currentChurnRate: 0,
    revenueColumn: null,
    dateColumn: null,
    churnColumn: null,
    rowCount: rows.length,
    datasetName: name,
  };

  if (!columns.length || !rows.length) return empty;

  const { revenueCol, dateCol, churnCol } = detectColumns(columns, rows);
  if (!revenueCol) return empty;

  const series = buildSeriesFromRows(rows, revenueCol, dateCol, churnCol);
  if (series.length === 0) return empty;

  const last = series[series.length - 1];
  const totalRevenue = series.reduce((s, p) => s + p.revenue, 0);

  const growthRates = series.map(p => p.growthRate).filter((g): g is number => g !== null);
  const avgGrowthRate = growthRates.length > 0
    ? growthRates.reduce((s, g) => s + g, 0) / growthRates.length
    : 0;

  const churnValues = series.map(p => p.churn).filter((c): c is number => c !== null);
  const currentChurnRate = churnValues.length > 0
    ? churnValues[churnValues.length - 1]
    : 0;

  return {
    series,
    currentMRR: last.revenue,
    totalRevenue,
    avgGrowthRate,
    currentChurnRate,
    revenueColumn: revenueCol,
    dateColumn: dateCol,
    churnColumn: churnCol,
    rowCount: rows.length,
    datasetName: name,
  };
}

// ─── Date range filter ───────────────────────────────────────────────────────

export type DateRange = '30d' | '90d' | '180d' | '1y' | 'all';

export function filterSeriesByRange(series: PeriodPoint[], range: DateRange): PeriodPoint[] {
  if (range === 'all' || series.length === 0) return series;
  const cutoffs: Record<DateRange, number> = {
    '30d': 30, '90d': 90, '180d': 180, '1y': 365, 'all': Infinity,
  };
  const days = cutoffs[range];
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;

  const filtered = series.filter(p => {
    const d = new Date(p.period);
    return !isNaN(d.getTime()) && d.getTime() >= cutoff;
  });

  // If date parsing fails (non-date periods), just take the last N proportional points
  if (filtered.length === 0) {
    const ratio = Math.min(1, days / 365);
    const take = Math.max(1, Math.round(series.length * ratio));
    return series.slice(-take);
  }
  return filtered;
}
