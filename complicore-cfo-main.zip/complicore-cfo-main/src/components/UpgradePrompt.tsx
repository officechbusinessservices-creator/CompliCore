import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import { X, Sparkles, Lock, Check, Loader2 } from 'lucide-react';

interface UpgradePromptProps {
  onClose: () => void;
  feature?: string;
  userId: string;
}

const PRO_FEATURES = [
  'Unlimited CFO Reports',
  'Advanced AI Analysis',
  'Export to PDF',
  'Priority Support',
];

export default function UpgradePrompt({ onClose, feature = 'CFO Report Generation', userId }: UpgradePromptProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleUpgrade = async () => {
    setIsLoading(true);
    try {
      const priceId = import.meta.env.VITE_STRIPE_PRO_PRICE_ID;
      if (!priceId) {
        toast.error('Pro plan price not configured.');
        return;
      }

      const successUrl = `${window.location.origin}/?upgraded=true`;
      const cancelUrl = window.location.href;

      const res = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ priceId, successUrl, cancelUrl, userId }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error ?? 'Failed to create checkout session');
      }

      const { url } = await res.json();
      if (url) {
        window.location.href = url;
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Upgrade failed.';
      toast.error(msg);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-background/80 backdrop-blur-sm"
        />

        {/* Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 16 }}
          transition={{ type: 'spring', stiffness: 320, damping: 28 }}
          className="relative w-full max-w-md bg-white/5 border border-white/10 rounded-2xl shadow-2xl overflow-hidden"
        >
          {/* Close */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-lg text-on-surface-variant hover:bg-surface-high transition-colors z-10"
          >
            <X size={16} />
          </button>

          {/* Gradient accent strip */}
          <div className="h-1 w-full bg-gradient-to-r from-primary via-violet-500 to-primary/60" />

          <div className="p-8">
            {/* Icon + heading */}
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0">
                <Sparkles size={20} />
              </div>
              <h2 className="text-xl font-bold text-on-surface">Unlock Pro</h2>
            </div>

            {/* Feature name */}
            <div className="flex items-center gap-2 mb-5">
              <Lock size={13} className="text-on-surface-variant shrink-0" />
              <p className="text-sm text-on-surface-variant">
                <span className="font-semibold text-on-surface">{feature}</span>
                {' '}is a Pro feature
              </p>
            </div>

            {/* Pricing */}
            <div className="bg-surface-high border border-outline/10 rounded-xl px-5 py-4 mb-5 flex items-baseline gap-1">
              <span className="text-3xl font-bold text-on-surface">$49</span>
              <span className="text-on-surface-variant text-sm">/mo</span>
              <span className="ml-auto text-[10px] font-mono uppercase tracking-widest text-primary font-bold">
                Pro Plan
              </span>
            </div>

            {/* Feature list */}
            <ul className="space-y-2.5 mb-7">
              {PRO_FEATURES.map((f) => (
                <li key={f} className="flex items-center gap-2.5 text-sm text-on-surface">
                  <span className="w-4 h-4 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
                    <Check size={10} strokeWidth={3} />
                  </span>
                  {f}
                </li>
              ))}
            </ul>

            {/* CTA */}
            <button
              onClick={handleUpgrade}
              disabled={isLoading}
              className="w-full py-3 rounded-xl bg-primary text-white font-bold text-sm hover:opacity-90 transition-all shadow-lg shadow-primary/20 flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {isLoading ? (
                <>
                  <Loader2 size={16} className="animate-spin" />
                  Redirecting...
                </>
              ) : (
                <>
                  <Sparkles size={16} />
                  Upgrade to Pro
                </>
              )}
            </button>

            <button
              onClick={onClose}
              className="w-full mt-3 py-2 text-sm text-on-surface-variant hover:text-on-surface transition-colors"
            >
              Maybe later
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
