import React, { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import {
  TrendingUp,
  DollarSign,
  Activity,
  Database,
  Download,
  ChevronDown,
  AlertCircle,
  Loader2,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { useRevenueDatasets } from '../hooks/useRevenueDatasets';
import {
  computeMetrics,
  filterSeriesByRange,
  type DatasetDoc,
  type DateRange,
} from '../utils/metricsComputer';

// ─── Props ────────────────────────────────────────────────────────────────────

interface AnalyticsDashboardProps {
  userId: string;
  onUploadClick?: () => void;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function fmt(n: number): string {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(1)}k`;
  return `$${n.toFixed(0)}`;
}

function fmtPct(n: number): string {
  return `${(n * 100).toFixed(1)}%`;
}

function fmtGrowth(n: number): string {
  const sign = n >= 0 ? '+' : '';
  return `${sign}${(n * 100).toFixed(1)}%`;
}

const DATE_RANGE_OPTIONS: { label: string; value: DateRange }[] = [
  { label: '30 Days', value: '30d' },
  { label: '90 Days', value: '90d' },
  { label: '180 Days', value: '180d' },
  { label: '1 Year', value: '1y' },
  { label: 'All Time', value: 'all' },
];

const TOOLTIP_STYLE = {
  contentStyle: { backgroundColor: '#1A1A1A', border: '1px solid #333', borderRadius: '8px' },
  labelStyle: { color: '#aaa', fontSize: 10 },
};

// ─── Sub-components ───────────────────────────────────────────────────────────

function KPICard({
  title,
  value,
  sub,
  icon: Icon,
  colorClass,
}: {
  title: string;
  value: string;
  sub?: string;
  icon: React.ElementType;
  colorClass: string;
}) {
  return (
    <div className="bg-surface p-6 rounded-xl border border-outline/10 relative overflow-hidden group">
      <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
        <Icon size={48} />
      </div>
      <p className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant mb-1">{title}</p>
      <h3 className={`text-2xl font-bold ${colorClass}`}>{value}</h3>
      {sub && <p className="text-[10px] text-on-surface-variant mt-1">{sub}</p>}
    </div>
  );
}

function DatasetSelector({
  datasets,
  selected,
  onChange,
}: {
  datasets: DatasetDoc[];
  selected: DatasetDoc;
  onChange: (d: DatasetDoc) => void;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-2 px-3 py-2 bg-surface-high border border-outline/20 rounded-xl text-xs font-bold hover:border-outline/40 transition-colors"
      >
        <Database size={14} className="text-primary" />
        <span className="max-w-[160px] truncate">{selected.name}</span>
        <ChevronDown size={14} className="text-on-surface-variant" />
      </button>
      {open && (
        <div className="absolute top-full mt-1 left-0 z-30 w-64 bg-surface border border-outline/20 rounded-xl shadow-2xl overflow-hidden">
          {datasets.map(d => (
            <button
              key={d.id}
              onClick={() => { onChange(d); setOpen(false); }}
              className={`w-full text-left px-4 py-2.5 text-xs hover:bg-surface-high transition-colors truncate ${
                d.id === selected.id ? 'text-primary font-bold' : 'text-on-surface'
              }`}
            >
              {d.name}
              <span className="ml-2 text-on-surface-variant font-normal">
                {d.rowCount.toLocaleString()} rows
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function RangePicker({ value, onChange }: { value: DateRange; onChange: (r: DateRange) => void }) {
  return (
    <div className="flex items-center gap-1 bg-surface-high rounded-xl p-1 border border-outline/10">
      {DATE_RANGE_OPTIONS.map(opt => (
        <button
          key={opt.value}
          onClick={() => onChange(opt.value)}
          className={`px-3 py-1.5 rounded-lg text-[10px] font-mono uppercase tracking-widest transition-all ${
            value === opt.value
              ? 'bg-primary text-white'
              : 'text-on-surface-variant hover:text-on-surface'
          }`}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}

// ─── Export PDF ───────────────────────────────────────────────────────────────

function handleExportPDF(datasetName: string) {
  const title = document.title;
  document.title = `CompliCore+ CFO Report — ${datasetName}`;
  window.print();
  document.title = title;
}

// ─── Empty state ──────────────────────────────────────────────────────────────

function EmptyState({ onUploadClick }: { onUploadClick?: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center py-24 gap-6 border-2 border-dashed border-outline/20 rounded-2xl"
    >
      <div className="w-20 h-20 rounded-3xl bg-surface-high flex items-center justify-center text-on-surface-variant/30">
        <Database size={40} />
      </div>
      <div className="text-center space-y-1">
        <h3 className="font-bold text-on-surface">No revenue data yet</h3>
        <p className="text-sm text-on-surface-variant max-w-xs">
          Upload a CSV or JSON dataset in the Data Library to see live analytics here.
        </p>
      </div>
      {onUploadClick && (
        <button
          onClick={onUploadClick}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-white font-bold text-sm hover:opacity-90 transition-all shadow-lg shadow-primary/20"
        >
          Upload Dataset
        </button>
      )}
    </motion.div>
  );
}

// ─── No numeric data state ────────────────────────────────────────────────────

function NoMetricsState({ datasetName }: { datasetName: string }) {
  return (
    <div className="flex items-center gap-3 p-4 bg-tertiary/5 border border-tertiary/20 rounded-xl">
      <AlertCircle size={18} className="text-tertiary shrink-0" />
      <div>
        <p className="text-sm font-bold text-on-surface">Cannot compute metrics for "{datasetName}"</p>
        <p className="text-xs text-on-surface-variant mt-0.5">
          No numeric revenue column detected. Upload a dataset with at least one numeric column (revenue, mrr, amount, etc.).
        </p>
      </div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function AnalyticsDashboard({ userId, onUploadClick }: AnalyticsDashboardProps) {
  const { datasets, isLoading, error } = useRevenueDatasets(userId);
  const [selectedDatasetId, setSelectedDatasetId] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState<DateRange>('all');

  // Resolve selected dataset — default to latest
  const selectedDataset: DatasetDoc | null = useMemo(() => {
    if (!datasets.length) return null;
    return datasets.find(d => d.id === selectedDatasetId) ?? datasets[0];
  }, [datasets, selectedDatasetId]);

  // Compute metrics from selected dataset
  const metrics = useMemo(() => {
    if (!selectedDataset) return null;
    return computeMetrics(selectedDataset);
  }, [selectedDataset]);

  // Apply date range filter to series
  const filteredSeries = useMemo(() => {
    if (!metrics) return [];
    return filterSeriesByRange(metrics.series, dateRange);
  }, [metrics, dateRange]);

  // ── Loading ────────────────────────────────────────────────────────────────
  if (isLoading) {
    return (
      <main className="p-8 flex items-center justify-center py-32">
        <Loader2 className="animate-spin text-primary" size={32} />
      </main>
    );
  }

  // ── Error ──────────────────────────────────────────────────────────────────
  if (error) {
    return (
      <main className="p-8">
        <div className="flex items-center gap-3 p-4 bg-tertiary/5 border border-tertiary/20 rounded-xl max-w-xl">
          <AlertCircle size={18} className="text-tertiary shrink-0" />
          <p className="text-sm text-on-surface">{error}</p>
        </div>
      </main>
    );
  }

  return (
    <main className="p-8 pb-24 space-y-8 print:p-4" id="analytics-print-area">
      {/* Header */}
      <div className="flex items-end justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Analytics</h1>
          <p className="text-on-surface-variant text-sm">
            {datasets.length > 0
              ? `${datasets.length} dataset${datasets.length > 1 ? 's' : ''} · live from Firestore`
              : 'Strategic intelligence and revenue performance metrics.'}
          </p>
        </div>
        <div className="flex items-center gap-3 flex-wrap print:hidden">
          {selectedDataset && datasets.length > 1 && (
            <DatasetSelector
              datasets={datasets}
              selected={selectedDataset}
              onChange={d => setSelectedDatasetId(d.id)}
            />
          )}
          {metrics && metrics.series.length > 0 && (
            <RangePicker value={dateRange} onChange={setDateRange} />
          )}
          {selectedDataset && (
            <button
              onClick={() => handleExportPDF(selectedDataset.name)}
              className="flex items-center gap-1.5 px-3 py-2 bg-surface-high border border-outline/20 rounded-xl text-xs font-bold hover:border-outline/40 transition-colors"
            >
              <Download size={14} />
              Export PDF
            </button>
          )}
        </div>
      </div>

      {/* Empty state */}
      {datasets.length === 0 && <EmptyState onUploadClick={onUploadClick} />}

      {/* No metrics state */}
      {selectedDataset && metrics && metrics.revenueColumn === null && (
        <NoMetricsState datasetName={selectedDataset.name} />
      )}

      {/* KPI Row */}
      {metrics && metrics.revenueColumn !== null && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4"
        >
          <KPICard
            title="Current Period Revenue"
            value={fmt(metrics.currentMRR)}
            sub={`from ${metrics.revenueColumn}`}
            icon={DollarSign}
            colorClass="text-primary"
          />
          <KPICard
            title="Total Revenue"
            value={fmt(metrics.totalRevenue)}
            sub={`${metrics.rowCount.toLocaleString()} rows`}
            icon={TrendingUp}
            colorClass="text-secondary"
          />
          <KPICard
            title="Avg Growth Rate"
            value={fmtGrowth(metrics.avgGrowthRate)}
            sub="period over period"
            icon={Activity}
            colorClass={metrics.avgGrowthRate >= 0 ? 'text-secondary' : 'text-tertiary'}
          />
          <KPICard
            title={metrics.churnColumn ? 'Churn Rate' : 'Periods'}
            value={metrics.churnColumn ? fmtPct(metrics.currentChurnRate) : `${metrics.series.length}`}
            sub={metrics.churnColumn ? `from ${metrics.churnColumn}` : 'data points'}
            icon={Activity}
            colorClass="text-tertiary"
          />
        </motion.div>
      )}

      {/* Charts */}
      {metrics && metrics.revenueColumn !== null && filteredSeries.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Revenue Trend — Area */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            className="bg-surface p-6 rounded-2xl border border-outline/10 space-y-4"
          >
            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">
                Revenue Trend
              </h3>
              <p className="text-[10px] font-mono text-on-surface-variant/60 mt-0.5">
                {metrics.revenueColumn} · {filteredSeries.length} periods
              </p>
            </div>
            <div className="h-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={filteredSeries}>
                  <defs>
                    <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                  <XAxis dataKey="period" stroke="#666" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis stroke="#666" fontSize={10} tickLine={false} axisLine={false} tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} />
                  <Tooltip
                    {...TOOLTIP_STYLE}
                    formatter={(v: number) => [fmt(v), 'Revenue']}
                    itemStyle={{ color: '#3B82F6' }}
                  />
                  <Area
                    type="monotone"
                    dataKey="revenue"
                    stroke="#3B82F6"
                    fillOpacity={1}
                    fill="url(#revGrad)"
                    strokeWidth={2}
                    dot={filteredSeries.length <= 24}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* Growth Rate — Bar */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-surface p-6 rounded-2xl border border-outline/10 space-y-4"
          >
            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">
                Period-over-Period Growth
              </h3>
              <p className="text-[10px] font-mono text-on-surface-variant/60 mt-0.5">
                % change from previous period
              </p>
            </div>
            <div className="h-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={filteredSeries}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                  <XAxis dataKey="period" stroke="#666" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis
                    stroke="#666"
                    fontSize={10}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={v => `${(v * 100).toFixed(0)}%`}
                  />
                  <Tooltip
                    {...TOOLTIP_STYLE}
                    formatter={(v: number) => [`${(v * 100).toFixed(1)}%`, 'Growth']}
                    itemStyle={{ color: '#10B981' }}
                  />
                  <Bar
                    dataKey="growthRate"
                    fill="#10B981"
                    radius={[4, 4, 0, 0]}
                    maxBarSize={40}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* Churn chart — only if churn column detected */}
          {metrics.churnColumn && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="bg-surface p-6 rounded-2xl border border-outline/10 space-y-4 lg:col-span-2"
            >
              <div>
                <h3 className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">
                  Churn Rate Over Time
                </h3>
                <p className="text-[10px] font-mono text-on-surface-variant/60 mt-0.5">
                  {metrics.churnColumn}
                </p>
              </div>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={filteredSeries}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                    <XAxis dataKey="period" stroke="#666" fontSize={10} tickLine={false} axisLine={false} />
                    <YAxis
                      stroke="#666"
                      fontSize={10}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={v => `${v}%`}
                    />
                    <Tooltip
                      {...TOOLTIP_STYLE}
                      formatter={(v: number) => [`${v}%`, 'Churn']}
                      itemStyle={{ color: '#F59E0B' }}
                    />
                    <Legend wrapperStyle={{ fontSize: 10 }} />
                    <Line
                      type="monotone"
                      dataKey="churn"
                      stroke="#F59E0B"
                      strokeWidth={2}
                      dot={{ fill: '#F59E0B', r: 3 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          )}

          {/* Revenue breakdown — Bar (all periods, not range-filtered) */}
          {metrics.series.length > 1 && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className={`bg-surface p-6 rounded-2xl border border-outline/10 space-y-4 ${
                metrics.churnColumn ? '' : 'lg:col-span-2'
              }`}
            >
              <div>
                <h3 className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">
                  Revenue by Period
                </h3>
                <p className="text-[10px] font-mono text-on-surface-variant/60 mt-0.5">
                  All {metrics.series.length} periods
                </p>
              </div>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={metrics.series}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                    <XAxis dataKey="period" stroke="#666" fontSize={10} tickLine={false} axisLine={false} />
                    <YAxis
                      stroke="#666"
                      fontSize={10}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={v => `$${(v / 1000).toFixed(0)}k`}
                    />
                    <Tooltip
                      {...TOOLTIP_STYLE}
                      formatter={(v: number) => [fmt(v), 'Revenue']}
                      itemStyle={{ color: '#8B5CF6' }}
                    />
                    <Bar dataKey="revenue" fill="#8B5CF6" radius={[4, 4, 0, 0]} maxBarSize={40} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          )}
        </div>
      )}

      {/* Dataset metadata footer */}
      {selectedDataset && (
        <div className="flex items-center gap-4 text-[10px] font-mono text-on-surface-variant/50 print:hidden">
          <span>{selectedDataset.name}</span>
          <span>·</span>
          <span>{selectedDataset.rowCount.toLocaleString()} rows</span>
          <span>·</span>
          <span>{selectedDataset.columns.length} columns</span>
          {metrics?.revenueColumn && (
            <>
              <span>·</span>
              <span>revenue column: {metrics.revenueColumn}</span>
            </>
          )}
        </div>
      )}
    </main>
  );
}
