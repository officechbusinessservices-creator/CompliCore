import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import {
  Database,
  FileText,
  Trash2,
  Eye,
  X,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Plus,
  BarChart2,
  Lock,
  Sparkles,
  ShieldCheck,
  ArrowUpRight,
} from 'lucide-react';
import {
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  deleteDoc,
  doc,
} from 'firebase/firestore';
import { db } from '../firebase';
import CFOReport from './CFOReport';
import { useSubscription } from '../hooks/useSubscription';
import UpgradePrompt from './UpgradePrompt';

interface RevenueDataset {
  id: string;
  userId: string;
  name: string;
  source: 'csv' | 'json';
  columns: string[];
  rowCount: number;
  rows: Record<string, unknown>[];
  uploadedAt: { toDate(): Date } | null;
}

interface Props {
  userId: string;
  onUploadClick: () => void;
}

const ROWS_PER_PAGE = 50;

function SourceBadge({ source }: { source: 'csv' | 'json' }) {
  return (
    <span
      className={`text-[9px] font-mono font-bold uppercase tracking-widest px-2 py-0.5 rounded ${
        source === 'csv'
          ? 'bg-primary/10 text-primary'
          : 'bg-tertiary/10 text-tertiary'
      }`}
    >
      {source}
    </span>
  );
}

function DatasetViewerModal({
  dataset,
  onClose,
}: {
  dataset: RevenueDataset;
  onClose: () => void;
}) {
  const [page, setPage] = useState(0);
  const totalPages = Math.ceil(dataset.rows.length / ROWS_PER_PAGE);
  const pageRows = dataset.rows.slice(page * ROWS_PER_PAGE, (page + 1) * ROWS_PER_PAGE);

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-background/80 backdrop-blur-sm"
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-5xl bg-surface border border-outline/20 rounded-2xl shadow-2xl max-h-[90vh] flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-outline/10 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
              <Database size={18} />
            </div>
            <div>
              <h3 className="font-bold text-on-surface">{dataset.name}</h3>
              <div className="flex items-center gap-2 mt-0.5">
                <SourceBadge source={dataset.source} />
                <span className="text-[10px] font-mono text-on-surface-variant">
                  {dataset.rowCount.toLocaleString()} rows · {dataset.columns.length} columns
                </span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-on-surface-variant hover:bg-surface-high transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Table */}
        <div className="overflow-auto flex-1">
          <table className="w-full text-xs">
            <thead className="sticky top-0 z-10">
              <tr className="border-b border-outline/10 bg-surface-high">
                <th className="text-left px-3 py-2 font-mono text-on-surface-variant uppercase tracking-widest w-12 shrink-0">
                  #
                </th>
                {dataset.columns.map(col => (
                  <th
                    key={col}
                    className="text-left px-3 py-2 font-mono text-on-surface-variant uppercase tracking-widest whitespace-nowrap"
                  >
                    {col}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageRows.map((row, i) => (
                <tr
                  key={i}
                  className="border-b border-outline/5 hover:bg-surface-high/50 transition-colors"
                >
                  <td className="px-3 py-2 text-on-surface-variant font-mono">
                    {page * ROWS_PER_PAGE + i + 1}
                  </td>
                  {dataset.columns.map(col => (
                    <td
                      key={col}
                      className="px-3 py-2 text-on-surface whitespace-nowrap max-w-[200px] truncate"
                    >
                      {String(row[col] ?? '')}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-6 py-3 border-t border-outline/10 shrink-0">
            <p className="text-[10px] font-mono text-on-surface-variant uppercase">
              Page {page + 1} of {totalPages} · rows {page * ROWS_PER_PAGE + 1}–{Math.min((page + 1) * ROWS_PER_PAGE, dataset.rowCount)}
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage(p => Math.max(0, p - 1))}
                disabled={page === 0}
                className="p-1.5 rounded-lg border border-outline/20 hover:bg-surface-high transition-colors disabled:opacity-30"
              >
                <ChevronLeft size={16} />
              </button>
              <button
                onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
                disabled={page === totalPages - 1}
                className="p-1.5 rounded-lg border border-outline/20 hover:bg-surface-high transition-colors disabled:opacity-30"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}

export default function DatasetLibrary({ userId, onUploadClick }: Props) {
  const [datasets, setDatasets] = useState<RevenueDataset[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [viewingDataset, setViewingDataset] = useState<RevenueDataset | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [selectedDataset, setSelectedDataset] = useState<RevenueDataset | null>(null);
  const [showUpgradePrompt, setShowUpgradePrompt] = useState(false);

  const subscription = useSubscription(userId);

  useEffect(() => {
    if (!userId) return;

    const q = query(
      collection(db, 'revenueDatasets'),
      where('userId', '==', userId),
      orderBy('uploadedAt', 'desc'),
    );

    const unsubscribe = onSnapshot(
      q,
      snapshot => {
        const docs = snapshot.docs.map(d => ({
          id: d.id,
          ...d.data(),
        })) as RevenueDataset[];
        setDatasets(docs);
        setIsLoading(false);
      },
      err => {
        console.error('DatasetLibrary snapshot error:', err);
        if (err.message?.includes('permission')) {
          toast.error('Permission denied loading datasets. Please re-login.');
        } else {
          toast.error('Failed to load datasets.');
        }
        setIsLoading(false);
      },
    );

    return () => unsubscribe();
  }, [userId]);

  const handleDelete = async (dataset: RevenueDataset) => {
    if (confirmDeleteId !== dataset.id) {
      setConfirmDeleteId(dataset.id);
      return;
    }

    setDeletingId(dataset.id);
    setConfirmDeleteId(null);
    try {
      await deleteDoc(doc(db, 'revenueDatasets', dataset.id));
      toast.success(`"${dataset.name}" deleted.`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Delete failed.';
      toast.error(msg);
    } finally {
      setDeletingId(null);
    }
  };

  const formatDate = (ts: RevenueDataset['uploadedAt']) => {
    if (!ts) return 'Just now';
    try {
      return ts.toDate().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
    } catch {
      return 'Unknown date';
    }
  };

  // If a dataset is selected for analysis, show the CFOReport view
  if (selectedDataset) {
    return (
      <CFOReport
        dataset={{
          id: selectedDataset.id,
          name: selectedDataset.name,
          columns: selectedDataset.columns,
          rows: selectedDataset.rows,
          rowCount: selectedDataset.rowCount,
        }}
        userId={userId}
        onBack={() => setSelectedDataset(null)}
      />
    );
  }

  return (
    <main className="p-8 pb-24 space-y-8">
      {/* Page Header */}
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Data Library</h1>
          <p className="text-on-surface-variant text-sm mt-1">
            All your uploaded revenue datasets, ready for CFO analysis.
          </p>
        </div>
        <button
          onClick={onUploadClick}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-white font-bold text-xs uppercase tracking-widest hover:opacity-90 transition-all shadow-lg shadow-primary/20"
        >
          <Plus size={14} />
          Upload Dataset
        </button>
      </div>

      {/* Subscription Status Badge */}
      {subscription.isActive ? (
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
          <ShieldCheck size={13} />
          Pro Plan · Active
          {subscription.currentPeriodEnd && (
            <span className="font-normal text-emerald-400/70 ml-0.5">
              until{' '}
              {subscription.currentPeriodEnd.toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                year: 'numeric',
              })}
            </span>
          )}
        </div>
      ) : (
        <button
          onClick={() => setShowUpgradePrompt(true)}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-on-surface-variant text-xs font-semibold hover:border-primary/30 hover:text-primary transition-all group"
        >
          <Sparkles size={13} className="group-hover:text-primary" />
          Free Plan · Upgrade for CFO Analysis
          <ArrowUpRight size={12} />
        </button>
      )}

      {/* Loading State */}
      {isLoading && (
        <div className="flex items-center justify-center py-24">
          <Loader2 className="animate-spin text-primary" size={32} />
        </div>
      )}

      {/* Empty State */}
      {!isLoading && datasets.length === 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center justify-center py-24 space-y-6 border-2 border-dashed border-outline/20 rounded-2xl"
        >
          <div className="w-20 h-20 rounded-3xl bg-surface-high flex items-center justify-center text-on-surface-variant/30">
            <Database size={40} />
          </div>
          <div className="text-center space-y-2">
            <h3 className="font-bold text-on-surface">No datasets yet</h3>
            <p className="text-sm text-on-surface-variant max-w-xs">
              Upload a CSV or JSON file to get started. Gemini will instantly analyze your financial data.
            </p>
          </div>
          <button
            onClick={onUploadClick}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-white font-bold text-sm hover:opacity-90 transition-all shadow-lg shadow-primary/20"
          >
            <Plus size={16} />
            Upload Your First Dataset
          </button>
        </motion.div>
      )}

      {/* Dataset Grid */}
      {!isLoading && datasets.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence>
            {datasets.map((dataset, idx) => (
              <motion.div
                key={dataset.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ delay: idx * 0.05 }}
                className="bg-surface rounded-2xl border border-outline/10 hover:border-primary/20 transition-all duration-300 group flex flex-col"
              >
                {/* Card Header */}
                <div className="p-5 border-b border-outline/5 flex items-start justify-between gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0">
                    <FileText size={20} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-sm text-on-surface truncate">{dataset.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <SourceBadge source={dataset.source} />
                    </div>
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-5 flex-1 space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-surface-high rounded-lg p-3">
                      <p className="text-[9px] font-mono text-on-surface-variant uppercase tracking-widest mb-1">Rows</p>
                      <p className="text-lg font-bold text-on-surface">{dataset.rowCount.toLocaleString()}</p>
                    </div>
                    <div className="bg-surface-high rounded-lg p-3">
                      <p className="text-[9px] font-mono text-on-surface-variant uppercase tracking-widest mb-1">Columns</p>
                      <p className="text-lg font-bold text-on-surface">{dataset.columns.length}</p>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <p className="text-[9px] font-mono text-on-surface-variant uppercase tracking-widest">Columns</p>
                    <div className="flex flex-wrap gap-1">
                      {dataset.columns.slice(0, 5).map(col => (
                        <span
                          key={col}
                          className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-surface-high text-on-surface-variant truncate max-w-[80px]"
                          title={col}
                        >
                          {col}
                        </span>
                      ))}
                      {dataset.columns.length > 5 && (
                        <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-surface-high text-on-surface-variant">
                          +{dataset.columns.length - 5}
                        </span>
                      )}
                    </div>
                  </div>

                  <p className="text-[10px] font-mono text-on-surface-variant/60">
                    Uploaded {formatDate(dataset.uploadedAt)}
                  </p>
                </div>

                {/* Card Footer */}
                <div className="px-5 pb-5 flex items-center gap-2">
                  <button
                    onClick={() => setViewingDataset(dataset)}
                    className="flex-1 py-2 rounded-lg bg-surface-high border border-outline/10 text-xs font-bold hover:bg-primary hover:text-white hover:border-primary transition-all flex items-center justify-center gap-1.5"
                  >
                    <Eye size={14} />
                    View Data
                  </button>
                  {subscription.isActive ? (
                    <button
                      onClick={() => setSelectedDataset(dataset)}
                      className="flex-1 py-2 rounded-lg bg-primary/10 border border-primary/30 text-primary text-xs font-bold hover:bg-primary hover:text-white hover:border-primary transition-all flex items-center justify-center gap-1.5"
                    >
                      <BarChart2 size={14} />
                      Analyze
                    </button>
                  ) : (
                    <button
                      onClick={() => setShowUpgradePrompt(true)}
                      title="Pro feature — upgrade to analyze"
                      className="flex-1 py-2 rounded-lg bg-white/5 border border-white/10 text-on-surface-variant text-xs font-bold hover:bg-primary/10 hover:text-primary hover:border-primary/30 transition-all flex items-center justify-center gap-1.5 group"
                    >
                      <Lock size={13} className="group-hover:text-primary" />
                      Analyze
                    </button>
                  )}
                  <button
                    onClick={() => handleDelete(dataset)}
                    disabled={deletingId === dataset.id}
                    className={`p-2 rounded-lg border transition-all ${
                      confirmDeleteId === dataset.id
                        ? 'bg-destructive/10 border-destructive/30 text-destructive hover:bg-destructive hover:text-white'
                        : 'bg-surface-high border-outline/10 text-on-surface-variant hover:bg-destructive/10 hover:text-destructive hover:border-destructive/30'
                    }`}
                    title={confirmDeleteId === dataset.id ? 'Click again to confirm delete' : 'Delete dataset'}
                  >
                    {deletingId === dataset.id ? (
                      <Loader2 size={16} className="animate-spin" />
                    ) : (
                      <Trash2 size={16} />
                    )}
                  </button>
                </div>

                {/* Confirm Delete Banner */}
                <AnimatePresence>
                  {confirmDeleteId === dataset.id && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="mx-5 mb-5 p-3 rounded-lg bg-destructive/10 border border-destructive/20 flex items-center justify-between gap-2">
                        <p className="text-[10px] text-destructive font-bold">Click delete again to confirm.</p>
                        <button
                          onClick={() => setConfirmDeleteId(null)}
                          className="text-[10px] text-on-surface-variant hover:text-on-surface underline"
                        >
                          Cancel
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* Dataset Viewer Modal */}
      <AnimatePresence>
        {viewingDataset && (
          <DatasetViewerModal
            dataset={viewingDataset}
            onClose={() => setViewingDataset(null)}
          />
        )}
      </AnimatePresence>

      {/* Upgrade Prompt */}
      {showUpgradePrompt && (
        <UpgradePrompt
          onClose={() => setShowUpgradePrompt(false)}
          feature="CFO Report Generation"
          userId={userId}
        />
      )}
    </main>
  );
}
