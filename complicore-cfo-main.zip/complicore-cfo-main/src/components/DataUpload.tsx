import React, { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import {
  Upload,
  X,
  FileText,
  Loader2,
  CheckCircle,
  AlertCircle,
  Sparkles,
  Database,
  RotateCcw,
} from 'lucide-react';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { analyzeUploadedDataset } from '../services/geminiService';
import Markdown from 'react-markdown';

interface ParsedDataset {
  columns: string[];
  rows: Record<string, unknown>[];
  preview: Record<string, unknown>[];
  rowCount: number;
  source: 'csv' | 'json';
}

interface Props {
  userId: string;
  onClose: () => void;
  onSaved?: () => void;
}

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

function parseCsv(text: string): Record<string, unknown>[] {
  const lines = text.split(/\r?\n/).filter(l => l.trim());
  if (lines.length < 2) throw new Error('CSV must have at least a header row and one data row.');
  const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
  return lines.slice(1).map(line => {
    const values = line.split(',').map(v => v.trim().replace(/^"|"$/g, ''));
    const row: Record<string, unknown> = {};
    headers.forEach((h, i) => {
      const raw = values[i] ?? '';
      const num = Number(raw);
      row[h] = raw !== '' && !isNaN(num) ? num : raw;
    });
    return row;
  });
}

function hasNumericColumn(rows: Record<string, unknown>[]): boolean {
  if (rows.length === 0) return false;
  const keys = Object.keys(rows[0]);
  return keys.some(k => typeof rows[0][k] === 'number');
}

export default function DataUpload({ userId, onClose, onSaved }: Props) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [datasetName, setDatasetName] = useState('');
  const [parsed, setParsed] = useState<ParsedDataset | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFile = useCallback(async (file: File) => {
    setError(null);
    setParsed(null);
    setAiAnalysis(null);

    if (file.size > MAX_FILE_SIZE) {
      setError(`File too large (${(file.size / 1024 / 1024).toFixed(1)} MB). Maximum size is 5 MB.`);
      return;
    }

    const ext = file.name.split('.').pop()?.toLowerCase();
    if (ext !== 'csv' && ext !== 'json') {
      setError('Unsupported file type. Please upload a .csv or .json file.');
      return;
    }

    if (!datasetName) {
      // Auto-fill name from filename
      setDatasetName(file.name.replace(/\.(csv|json)$/i, ''));
    }

    setIsParsing(true);
    try {
      const text = await file.text();
      let rows: Record<string, unknown>[];
      let source: 'csv' | 'json';

      if (ext === 'csv') {
        rows = parseCsv(text);
        source = 'csv';
      } else {
        const parsed = JSON.parse(text) as unknown;
        if (!Array.isArray(parsed)) throw new Error('JSON must be an array of objects.');
        if (parsed.length === 0) throw new Error('JSON array is empty.');
        if (typeof parsed[0] !== 'object' || parsed[0] === null) throw new Error('JSON items must be objects.');
        rows = parsed as Record<string, unknown>[];
        source = 'json';
      }

      if (!hasNumericColumn(rows)) {
        throw new Error('No numeric value column detected. Please upload financial data with at least one numeric column.');
      }

      const columns = Object.keys(rows[0]);
      const dataset: ParsedDataset = {
        columns,
        rows,
        preview: rows.slice(0, 10),
        rowCount: rows.length,
        source,
      };
      setParsed(dataset);
      toast.success(`Parsed ${rows.length.toLocaleString()} rows from ${file.name}`);

      // Trigger AI analysis
      setIsAnalyzing(true);
      const analysis = await analyzeUploadedDataset(columns, rows.slice(0, 20));
      setAiAnalysis(analysis);
      setIsAnalyzing(false);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to parse file.';
      setError(msg);
      toast.error(msg);
    } finally {
      setIsParsing(false);
      setIsAnalyzing(false);
    }
  }, [datasetName]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  }, [processFile]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
    e.target.value = '';
  };

  const handleSave = async () => {
    if (!parsed) return;
    const name = datasetName.trim();
    if (!name) {
      toast.error('Please enter a dataset name.');
      return;
    }

    setIsSaving(true);
    try {
      const docRef = await addDoc(collection(db, 'revenueDatasets'), {
        userId,
        name,
        source: parsed.source,
        columns: parsed.columns,
        rowCount: parsed.rowCount,
        rows: parsed.rows,
        uploadedAt: serverTimestamp(),
      });
      toast.success(`"${name}" saved to Data Library.`);
      onSaved?.();
      onClose();
      console.info('Saved dataset:', docRef.id);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to save dataset.';
      if (msg.includes('permission')) {
        toast.error('Permission denied. Please log out and log back in.');
      } else {
        toast.error(`Save failed: ${msg}`);
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = () => {
    setParsed(null);
    setAiAnalysis(null);
    setError(null);
    setDatasetName('');
    setIsParsing(false);
    setIsAnalyzing(false);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-background/80 backdrop-blur-sm"
      />

      {/* Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-3xl bg-surface border border-outline/20 rounded-2xl shadow-2xl max-h-[90vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="sticky top-0 bg-surface border-b border-outline/10 px-6 py-4 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
              <Upload size={18} />
            </div>
            <div>
              <h2 className="text-lg font-bold">Upload Dataset</h2>
              <p className="text-[10px] font-mono text-on-surface-variant uppercase tracking-widest">CSV or JSON — Max 5 MB</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {parsed && (
              <button
                onClick={handleReset}
                className="p-2 rounded-lg text-on-surface-variant hover:bg-surface-high transition-colors"
                title="Reset"
              >
                <RotateCcw size={16} />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-on-surface-variant hover:bg-surface-high transition-colors"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Dataset Name Input */}
          <div className="space-y-2">
            <label className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant">
              Dataset Name
            </label>
            <input
              type="text"
              value={datasetName}
              onChange={e => setDatasetName(e.target.value)}
              placeholder="e.g. Q1 2026 Revenue"
              className="w-full bg-surface-high border border-outline/10 rounded-xl px-4 py-3 text-sm focus:ring-1 ring-primary outline-none transition-all"
            />
          </div>

          {/* Drop Zone (shown when no file parsed) */}
          {!parsed && !isParsing && (
            <div
              onDragOver={e => { e.preventDefault(); setIsDragOver(true); }}
              onDragLeave={() => setIsDragOver(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-12 text-center cursor-pointer transition-all duration-200 ${
                isDragOver
                  ? 'border-primary bg-primary/5 scale-[1.01]'
                  : 'border-outline/20 hover:border-primary/40 hover:bg-surface-high/50'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.json"
                className="hidden"
                onChange={handleFileChange}
              />
              <div className="flex flex-col items-center gap-4">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-colors ${
                  isDragOver ? 'bg-primary/20 text-primary' : 'bg-surface-high text-on-surface-variant'
                }`}>
                  <FileText size={32} />
                </div>
                <div>
                  <p className="font-bold text-on-surface">
                    {isDragOver ? 'Drop file here' : 'Drag & drop your file here'}
                  </p>
                  <p className="text-sm text-on-surface-variant mt-1">or click to browse</p>
                  <p className="text-[10px] font-mono text-on-surface-variant/60 mt-2 uppercase tracking-widest">
                    .csv or .json — max 5 MB
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Parsing State */}
          {isParsing && (
            <div className="border border-outline/10 rounded-xl p-8 text-center space-y-4">
              <Loader2 className="animate-spin text-primary mx-auto" size={32} />
              <p className="text-sm text-on-surface-variant font-mono uppercase tracking-widest animate-pulse">
                Parsing file...
              </p>
            </div>
          )}

          {/* Error State */}
          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="flex items-start gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive"
              >
                <AlertCircle size={18} className="mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-bold">Parse Error</p>
                  <p className="text-xs mt-0.5 opacity-80">{error}</p>
                </div>
                <button onClick={() => setError(null)} className="ml-auto shrink-0 opacity-60 hover:opacity-100">
                  <X size={14} />
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Parsed Success */}
          {parsed && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              {/* Summary Bar */}
              <div className="flex items-center gap-4 p-4 rounded-xl bg-secondary/10 border border-secondary/20">
                <CheckCircle size={20} className="text-secondary shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-on-surface">File parsed successfully</p>
                  <p className="text-xs text-on-surface-variant">
                    {parsed.rowCount.toLocaleString()} rows · {parsed.columns.length} columns · {parsed.source.toUpperCase()}
                  </p>
                </div>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="text-[10px] font-mono uppercase tracking-widest text-primary hover:underline shrink-0"
                >
                  Replace
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv,.json"
                  className="hidden"
                  onChange={handleFileChange}
                />
              </div>

              {/* Preview Table */}
              <div>
                <p className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant mb-3">
                  Preview — First {parsed.preview.length} rows
                </p>
                <div className="overflow-x-auto rounded-xl border border-outline/10">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-outline/10 bg-surface-high">
                        {parsed.columns.map(col => (
                          <th
                            key={col}
                            className="text-left px-3 py-2 font-mono text-on-surface-variant uppercase tracking-widest whitespace-nowrap"
                          >
                            {col}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {parsed.preview.map((row, i) => (
                        <tr
                          key={i}
                          className="border-b border-outline/5 hover:bg-surface-high/50 transition-colors"
                        >
                          {parsed.columns.map(col => (
                            <td key={col} className="px-3 py-2 text-on-surface whitespace-nowrap max-w-[180px] truncate">
                              {String(row[col] ?? '')}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {parsed.rowCount > 10 && (
                  <p className="text-[10px] text-on-surface-variant mt-2 font-mono">
                    + {(parsed.rowCount - 10).toLocaleString()} more rows not shown
                  </p>
                )}
              </div>

              {/* AI Analysis */}
              <div className="rounded-xl border border-outline/10 bg-surface-high/30 overflow-hidden">
                <div className="flex items-center gap-2 px-4 py-3 border-b border-outline/10">
                  <Sparkles size={16} className="text-primary" />
                  <span className="text-[10px] font-mono uppercase tracking-widest text-on-surface-variant">
                    Gemini CFO Analysis
                  </span>
                  {isAnalyzing && <Loader2 size={14} className="animate-spin text-primary ml-auto" />}
                </div>
                <div className="p-4">
                  {isAnalyzing && (
                    <div className="space-y-2 animate-pulse">
                      <div className="h-3 bg-surface-high rounded w-3/4" />
                      <div className="h-3 bg-surface-high rounded w-full" />
                      <div className="h-3 bg-surface-high rounded w-2/3" />
                    </div>
                  )}
                  {!isAnalyzing && aiAnalysis && (
                    <div className="prose prose-invert prose-sm max-w-none prose-p:text-on-surface-variant prose-li:text-on-surface-variant prose-headings:text-on-surface">
                      <Markdown>{aiAnalysis}</Markdown>
                    </div>
                  )}
                  {!isAnalyzing && !aiAnalysis && (
                    <p className="text-sm text-on-surface-variant">AI analysis unavailable.</p>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </div>

        {/* Footer */}
        {parsed && (
          <div className="sticky bottom-0 bg-surface border-t border-outline/10 px-6 py-4 flex items-center justify-between gap-4">
            <p className="text-xs text-on-surface-variant">
              {parsed.rowCount.toLocaleString()} rows will be saved to your Data Library.
            </p>
            <div className="flex gap-3">
              <button
                onClick={onClose}
                className="px-5 py-2 rounded-xl border border-outline/20 text-sm font-bold hover:bg-surface-high transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                disabled={isSaving || !datasetName.trim()}
                className="px-5 py-2 rounded-xl bg-primary text-white text-sm font-bold hover:opacity-90 transition-all flex items-center gap-2 disabled:opacity-50 shadow-lg shadow-primary/20"
              >
                {isSaving ? <Loader2 size={16} className="animate-spin" /> : <Database size={16} />}
                {isSaving ? 'Saving...' : 'Save to Library'}
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}
