import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import {
  ArrowLeft,
  Sparkles,
  Save,
  ChevronDown,
  ChevronUp,
  Loader2,
  FileText,
  Clock,
} from 'lucide-react';
import {
  collection,
  addDoc,
  serverTimestamp,
  query,
  where,
  orderBy,
  onSnapshot,
} from 'firebase/firestore';
import { db } from '../firebase';
import { analyzeCFOReport } from '../services/geminiService';
import Markdown from 'react-markdown';

interface Dataset {
  id: string;
  name: string;
  columns: string[];
  rows: object[];
  rowCount: number;
}

interface CFOReportProps {
  dataset: Dataset;
  userId: string;
  onBack: () => void;
}

interface PastReport {
  id: string;
  datasetId: string;
  datasetName: string;
  content: string;
  createdAt: { toDate(): Date } | null;
}

type StatusType = 'idle' | 'generating' | 'complete' | 'saved';

function StatusBadge({ status }: { status: StatusType }) {
  const config: Record<StatusType, { label: string; classes: string; dot?: string }> = {
    idle: {
      label: 'Not generated',
      classes: 'bg-white/5 border-white/10 text-on-surface-variant',
    },
    generating: {
      label: 'Generating...',
      classes: 'bg-primary/10 border-primary/30 text-primary',
      dot: 'animate-pulse bg-primary',
    },
    complete: {
      label: 'Complete',
      classes: 'bg-secondary/10 border-secondary/30 text-secondary',
      dot: 'bg-secondary',
    },
    saved: {
      label: 'Saved',
      classes: 'bg-secondary/10 border-secondary/30 text-secondary',
      dot: 'bg-secondary',
    },
  };

  const { label, classes, dot } = config[status];

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-widest border ${classes}`}
    >
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${dot}`} />}
      {label}
    </span>
  );
}

function PastReportCard({ report }: { report: PastReport }) {
  const [expanded, setExpanded] = useState(false);

  const formatDate = (ts: PastReport['createdAt']) => {
    if (!ts) return 'Just now';
    try {
      return ts.toDate().toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
      });
    } catch {
      return 'Unknown date';
    }
  };

  const preview = report.content.slice(0, 200).trim();

  return (
    <motion.div
      layout
      className="bg-white/5 border border-white/10 rounded-xl overflow-hidden"
    >
      <button
        onClick={() => setExpanded(e => !e)}
        className="w-full flex items-center justify-between gap-3 px-4 py-3 text-left hover:bg-white/5 transition-colors"
      >
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center text-primary shrink-0">
            <FileText size={14} />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-bold text-on-surface truncate">
              CFO Report
            </p>
            <div className="flex items-center gap-1.5 mt-0.5">
              <Clock size={10} className="text-on-surface-variant" />
              <span className="text-[10px] font-mono text-on-surface-variant">
                {formatDate(report.createdAt)}
              </span>
            </div>
          </div>
        </div>
        <div className="shrink-0 text-on-surface-variant">
          {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </div>
      </button>

      <AnimatePresence>
        {!expanded && (
          <div className="px-4 pb-3">
            <p className="text-[11px] text-on-surface-variant line-clamp-2">
              {preview}
              {report.content.length > 200 ? '…' : ''}
            </p>
          </div>
        )}
        {expanded && (
          <motion.div
            key="expanded"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 border-t border-white/10 pt-3">
              <div className="cfo-markdown-prose">
                <Markdown>{report.content}</Markdown>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function CFOReport({ dataset, userId, onBack }: CFOReportProps) {
  const [streamedText, setStreamedText] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [status, setStatus] = useState<StatusType>('idle');
  const [fullReportText, setFullReportText] = useState('');
  const [pastReports, setPastReports] = useState<PastReport[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Live query for past reports
  useEffect(() => {
    if (!userId || !dataset.id) return;

    const q = query(
      collection(db, 'cfo_reports', userId, 'reports'),
      where('datasetId', '==', dataset.id),
      orderBy('createdAt', 'desc'),
    );

    const unsubscribe = onSnapshot(
      q,
      snap => {
        setPastReports(
          snap.docs.map(d => ({ id: d.id, ...d.data() } as PastReport)),
        );
      },
      err => {
        console.error('CFOReport snapshot error:', err);
      },
    );

    return () => unsubscribe();
  }, [userId, dataset.id]);

  // Auto-scroll while streaming
  useEffect(() => {
    if (isStreaming && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [streamedText, isStreaming]);

  const generateReport = async () => {
    setStreamedText('');
    setFullReportText('');
    setStatus('generating');
    setIsStreaming(true);
    setIsSaved(false);

    const fullText = await analyzeCFOReport(
      dataset.name,
      dataset.columns,
      dataset.rows,
      (chunk) => setStreamedText(prev => prev + chunk),
    );

    setIsStreaming(false);
    setFullReportText(fullText);
    setStatus('complete');
  };

  const saveReport = async () => {
    if (!fullReportText || isSaving) return;
    setIsSaving(true);
    try {
      const reportsRef = collection(db, 'cfo_reports', userId, 'reports');
      await addDoc(reportsRef, {
        datasetId: dataset.id,
        datasetName: dataset.name,
        content: fullReportText,
        createdAt: serverTimestamp(),
      });
      setStatus('saved');
      setIsSaved(true);
      toast.success('Report saved successfully.');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Save failed.';
      toast.error(msg);
    } finally {
      setIsSaving(false);
    }
  };

  const displayText = streamedText || fullReportText;

  return (
    <main className="p-8 pb-24 space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-start justify-between gap-4 flex-wrap"
      >
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-lg bg-white/5 border border-white/10 text-on-surface-variant hover:bg-white/10 hover:text-on-surface transition-colors"
            title="Back to Library"
          >
            <ArrowLeft size={18} />
          </button>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-2xl font-bold tracking-tight">{dataset.name}</h1>
              <StatusBadge status={status} />
            </div>
            <p className="text-xs text-on-surface-variant mt-0.5">
              {dataset.rowCount.toLocaleString()} rows · {dataset.columns.length} columns
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {status === 'complete' && (
            <button
              onClick={saveReport}
              disabled={isSaving || isSaved}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-secondary/10 border border-secondary/30 text-secondary font-bold text-xs uppercase tracking-widest hover:bg-secondary/20 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSaving ? (
                <Loader2 size={14} className="animate-spin" />
              ) : (
                <Save size={14} />
              )}
              Save Report
            </button>
          )}

          <button
            onClick={generateReport}
            disabled={isStreaming}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-white font-bold text-xs uppercase tracking-widest hover:opacity-90 transition-all shadow-lg shadow-primary/20 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isStreaming ? (
              <Loader2 size={14} className="animate-spin" />
            ) : (
              <Sparkles size={14} />
            )}
            {status === 'idle' ? 'Generate Report' : 'Regenerate'}
          </button>
        </div>
      </motion.div>

      {/* Main Report Content */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="bg-white/5 border border-white/10 rounded-xl overflow-hidden"
      >
        <div
          ref={scrollRef}
          className="p-6 min-h-[400px] max-h-[60vh] overflow-y-auto"
        >
          <div className="cfo-markdown-prose">
            <Markdown>
              {displayText || '*Click "Generate Report" to analyze this dataset.*'}
            </Markdown>
          </div>
          {isStreaming && (
            <span className="inline-block w-2 h-4 bg-primary rounded-sm ml-0.5 animate-[blink_0.8s_step-end_infinite] align-middle" />
          )}
        </div>
      </motion.div>

      {/* Past Reports */}
      {pastReports.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-3"
        >
          <h2 className="text-sm font-bold text-on-surface-variant uppercase tracking-widest font-mono">
            Past Reports ({pastReports.length})
          </h2>
          <div className="space-y-2">
            {pastReports.map(report => (
              <PastReportCard key={report.id} report={report} />
            ))}
          </div>
        </motion.div>
      )}
    </main>
  );
}
