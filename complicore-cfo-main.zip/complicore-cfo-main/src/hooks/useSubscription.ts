import { useEffect, useState } from 'react';
import { db } from '../firebase';
import { doc, onSnapshot } from 'firebase/firestore';

export interface SubscriptionData {
  plan: 'pro' | 'free';
  status: 'active' | 'canceled' | 'past_due' | 'trialing' | null;
  currentPeriodEnd: Date | null;
  /** true when plan === 'pro' and status is 'active' or 'trialing' */
  isActive: boolean;
}

const DEFAULT_STATE: SubscriptionData = {
  plan: 'free',
  status: null,
  currentPeriodEnd: null,
  isActive: false,
};

export function useSubscription(userId: string | null): SubscriptionData {
  const [data, setData] = useState<SubscriptionData>(DEFAULT_STATE);

  useEffect(() => {
    if (!userId) {
      setData(DEFAULT_STATE);
      return;
    }

    const ref = doc(db, 'users', userId, 'subscription', 'data');
    const unsubscribe = onSnapshot(
      ref,
      (snap) => {
        if (!snap.exists()) {
          setData(DEFAULT_STATE);
          return;
        }
        const d = snap.data();
        const plan: SubscriptionData['plan'] = d.plan === 'pro' ? 'pro' : 'free';
        const status: SubscriptionData['status'] = d.status ?? null;
        setData({
          plan,
          status,
          currentPeriodEnd: d.currentPeriodEnd?.toDate() ?? null,
          isActive: plan === 'pro' && (status === 'active' || status === 'trialing'),
        });
      },
      (err) => {
        console.error('useSubscription snapshot error:', err);
        setData(DEFAULT_STATE);
      }
    );

    return unsubscribe;
  }, [userId]);

  return data;
}
