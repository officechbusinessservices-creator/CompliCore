import { useState, useEffect } from 'react';
import { collection, query, where, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import type { DatasetDoc } from '../utils/metricsComputer';

interface UseRevenueDatasetsResult {
  datasets: DatasetDoc[];
  latestDataset: DatasetDoc | null;
  isLoading: boolean;
  error: string | null;
}

/**
 * Real-time subscription to the user's revenue datasets in Firestore.
 * Reads from the `revenueDatasets` collection (written by DataUpload.tsx).
 */
export function useRevenueDatasets(userId: string | null): UseRevenueDatasetsResult {
  const [datasets, setDatasets] = useState<DatasetDoc[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!userId) {
      setDatasets([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);

    const q = query(
      collection(db, 'revenueDatasets'),
      where('userId', '==', userId),
      orderBy('uploadedAt', 'desc'),
    );

    const unsubscribe = onSnapshot(
      q,
      snapshot => {
        const docs = snapshot.docs.map(d => ({
          id: d.id,
          ...(d.data() as Omit<DatasetDoc, 'id'>),
        }));
        setDatasets(docs);
        setIsLoading(false);
      },
      err => {
        console.error('useRevenueDatasets error:', err);
        setError(err.message ?? 'Failed to load datasets.');
        setIsLoading(false);
      },
    );

    return () => unsubscribe();
  }, [userId]);

  return {
    datasets,
    latestDataset: datasets[0] ?? null,
    isLoading,
    error,
  };
}
