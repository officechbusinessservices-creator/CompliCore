/**
 * Netlify Function — wraps all Express API routes via serverless-http.
 * Static assets are served from dist/ by Netlify CDN.
 * Stripe webhook uses express.raw() for raw body; serverless-http preserves this.
 */
import express from "express";
import Stripe from "stripe";
import multer from "multer";
import Papa from "papaparse";
import admin from "firebase-admin";
import * as Sentry from "@sentry/node";
import rateLimit from "express-rate-limit";
import serverless from "serverless-http";
import dotenv from "dotenv";

dotenv.config();

Sentry.init({
  dsn: process.env.SENTRY_DSN || "",
  enabled: !!process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV || "development",
  tracesSampleRate: 0.1,
});

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "sk_test_placeholder");

if (!admin.apps.length) {
  if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
    admin.initializeApp({
      credential: admin.credential.cert(
        JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON)
      ),
    });
  } else {
    admin.initializeApp({ credential: admin.credential.applicationDefault() });
  }
}
const adminDb = admin.firestore();

// ── Subscription helpers ──────────────────────────────────────
async function updateSubscriptionInFirestore(
  customerId: string,
  sub: Stripe.Subscription
) {
  const snap = await adminDb
    .collection("users")
    .where("stripeCustomerId", "==", customerId)
    .limit(1)
    .get();
  if (snap.empty) return;
  const userId = snap.docs[0].id;
  const periodEnd = sub.items?.data?.[0]?.current_period_end;
  await adminDb
    .collection("users")
    .doc(userId)
    .collection("subscription")
    .doc("data")
    .set(
      {
        stripeCustomerId: customerId,
        stripeSubscriptionId: sub.id,
        plan: "pro",
        status: sub.status,
        currentPeriodEnd: periodEnd
          ? admin.firestore.Timestamp.fromMillis(periodEnd * 1000)
          : null,
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
}

async function cancelSubscriptionInFirestore(customerId: string) {
  const snap = await adminDb
    .collection("users")
    .where("stripeCustomerId", "==", customerId)
    .limit(1)
    .get();
  if (snap.empty) return;
  const userId = snap.docs[0].id;
  await adminDb
    .collection("users")
    .doc(userId)
    .collection("subscription")
    .doc("data")
    .set(
      {
        plan: "free",
        status: "canceled",
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
}

// ── Express app ───────────────────────────────────────────────
const app = express();

const checkoutLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: "Too many checkout attempts. Please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});

const webhookLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 100,
  message: { error: "Too many webhook requests." },
  standardHeaders: true,
  legacyHeaders: false,
});

// Stripe webhook — raw body required before express.json()
app.post(
  "/api/stripe/webhook",
  webhookLimiter,
  express.raw({ type: "application/json" }),
  async (req, res) => {
    try {
      const sig = req.headers["stripe-signature"] as string;
      const secret = process.env.STRIPE_WEBHOOK_SECRET;
      if (!secret) return res.status(500).json({ error: "Webhook secret not configured" });

      let event: Stripe.Event;
      try {
        event = stripe.webhooks.constructEvent(req.body, sig, secret);
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : "Unknown error";
        console.error("Webhook signature verification failed:", msg);
        return res.status(400).send(`Webhook Error: ${msg}`);
      }

      const sub = event.data.object as Stripe.Subscription;
      const customerId =
        typeof sub.customer === "string" ? sub.customer : sub.customer?.id;

      if (customerId) {
        if (
          event.type === "customer.subscription.created" ||
          event.type === "customer.subscription.updated"
        ) {
          await updateSubscriptionInFirestore(customerId, sub);
        } else if (event.type === "customer.subscription.deleted") {
          await cancelSubscriptionInFirestore(customerId);
        }
      }

      res.json({ received: true });
    } catch (error: unknown) {
      console.error("[stripe/webhook]", error);
      Sentry.captureException(error);
      res.status(500).json({ error: "Internal server error" });
    }
  }
);

app.use(express.json());

// File upload
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype === "text/csv" || file.mimetype === "application/json" ||
        file.originalname.endsWith(".csv") || file.originalname.endsWith(".json")) {
      cb(null, true);
    } else {
      cb(new Error("Only CSV and JSON files are accepted"));
    }
  },
});

app.post("/api/upload-revenue", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    const content = req.file.buffer.toString("utf-8");
    const ext = req.file.originalname.toLowerCase();

    if (ext.endsWith(".csv")) {
      const result = Papa.parse(content, { header: true, skipEmptyLines: true });
      if (result.errors.length > 0 && result.data.length === 0) {
        return res.status(400).json({ error: "Failed to parse CSV file" });
      }
      const rows = result.data as object[];
      const columns = result.meta.fields || [];
      return res.json({ preview: rows.slice(0, 10), columns, rowCount: rows.length, source: "csv", rows });
    }

    if (ext.endsWith(".json")) {
      let data: unknown;
      try { data = JSON.parse(content); } catch {
        return res.status(400).json({ error: "Invalid JSON file" });
      }
      if (!Array.isArray(data)) {
        return res.status(400).json({ error: "JSON must be an array of objects" });
      }
      const rows = data as object[];
      const columns = rows.length > 0 ? Object.keys(rows[0]) : [];
      return res.json({ preview: rows.slice(0, 10), columns, rowCount: rows.length, source: "json", rows });
    }

    res.status(400).json({ error: "Unsupported file type" });
  } catch (error: unknown) {
    console.error("[upload-revenue]", error);
    Sentry.captureException(error);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.post("/api/create-checkout-session", checkoutLimiter, async (req, res) => {
  try {
    const { priceId, successUrl, cancelUrl, userId, mode = "subscription" } = req.body;

    if (!process.env.STRIPE_SECRET_KEY) {
      return res.status(500).json({ error: "Stripe secret key is not configured." });
    }

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [{ price: priceId, quantity: 1 }],
      mode: mode as Stripe.Checkout.SessionCreateParams.Mode,
      success_url: successUrl,
      cancel_url: cancelUrl,
      metadata: { userId: userId || "" },
    });

    if (userId && session.customer) {
      const customerId =
        typeof session.customer === "string" ? session.customer : session.customer.id;
      await adminDb.collection("users").doc(userId).set(
        { stripeCustomerId: customerId },
        { merge: true }
      );
    }

    res.json({ url: session.url });
  } catch (error: unknown) {
    console.error("[create-checkout-session]", error);
    Sentry.captureException(error);
    res.status(500).json({ error: "Internal server error" });
  }
});

export const handler = serverless(app);
