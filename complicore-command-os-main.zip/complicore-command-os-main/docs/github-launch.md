# GitHub Launch

## Goal
A repo people can understand, run, trust, and share in under 5 minutes.

## Required Launch Assets
- README
- quickstart
- one-command demo
- screenshots
- sample report
- evaluation results
- security posture