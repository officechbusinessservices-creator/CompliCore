# Onboarding

## Inputs
- metro
- neighborhoods
- competitors
- target operator profile
- report recipients
- alert thresholds