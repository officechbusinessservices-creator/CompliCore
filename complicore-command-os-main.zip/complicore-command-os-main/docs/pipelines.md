# Pipelines

## v1 Pipeline
discover -> map -> classify -> scrape -> normalize -> rules -> weekly brief