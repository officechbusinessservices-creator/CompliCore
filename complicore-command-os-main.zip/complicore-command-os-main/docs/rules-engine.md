# Rules Engine

## Rule Families
- pricing transparency
- fee visibility
- policy coherence
- privacy presence
- disclosure signals
- contact-path completeness
- schema quality
- trust signals