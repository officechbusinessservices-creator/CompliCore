# Architecture

## Modules
1. Market Intelligence Engine
2. Compliance Intelligence Engine
3. Growth Intelligence Engine
4. Acquisition Engine
5. Workflow and Governance Engine

## App Layout
- apps/web
- apps/worker
- packages/core
- packages/firecrawl
- packages/rules