# Data Model

## Core Entities
- workspace
- objective
- run
- step
- audit_event
- domain
- url
- source_page
- screenshot
- listing
- pricing_observation
- policy_observation
- schema_observation
- content_gap
- compliance_finding
- opportunity_target
- outbound_brief
- report