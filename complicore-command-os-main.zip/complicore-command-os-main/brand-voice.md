# Brand Voice

Tone:
- executive
- precise
- operational
- evidence-backed

Avoid:
- hype
- vague AI language
- filler
- exaggerated certainty

Format:
- short headings
- concise paragraphs
- action-first summaries