# MANIFEST

## Read First
1. CLAUDE.md
2. docs/product-spec.md
3. docs/architecture.md
4. working-style.md

## Load Only When Needed
- docs/data-model.md
- docs/rules-engine.md
- docs/pipelines.md
- docs/onboarding.md
- docs/go-to-market.md
- docs/github-launch.md

## Ignore Unless Explicitly Requested
- node_modules
- dist
- .next
- coverage
- tmp
- archive
- experiments

## Execution Rules
- Show a plan before execution
- Revise, do not redo
- Scope context tightly
- Flag uncertainty instead of guessing
- Every material finding needs evidence
- No destructive actions without approval
- Keep changes scoped to the current phase
- Do not publish low-confidence findings