/**
 * complicore report <run_id>
 *
 * Fetches a completed run from Postgres and prints the brief to stdout.
 * Requires DATABASE_URL in environment.
 */

import { getDb } from "@complicore/core/db/client";
import { findRunById, listFindingsByRun, listTargetsByRun } from "@complicore/core/db";
import { eq } from "drizzle-orm";

const BOLD = "\x1b[1m";
const DIM = "\x1b[2m";
const RED = "\x1b[31m";
const YELLOW = "\x1b[33m";
const GREEN = "\x1b[32m";
const RESET = "\x1b[0m";

const SEV: Record<string, string> = { high: RED, medium: YELLOW, low: DIM };

export async function cmdReport(runId: string): Promise<void> {
  if (!process.env["DATABASE_URL"]) {
    console.error("✖  DATABASE_URL is not set.");
    process.exit(1);
  }

  const db = getDb();
  const run = await findRunById(db, runId);

  if (run == null) {
    console.error(`✖  Run not found: ${runId}`);
    process.exit(1);
  }

  const [findings, targets] = await Promise.all([
    listFindingsByRun(db, runId),
    listTargetsByRun(db, runId),
  ]);

  const high = findings.filter((f) => f.severity === "high");
  const highTargets = targets.filter((t) => t.signal_tier === "HIGH");

  console.log(`\n${BOLD}Weekly Brief — ${run.metro}${RESET}`);
  console.log(`${DIM}Run: ${runId}  Status: ${run.status}${RESET}\n`);

  console.log(`${BOLD}Headline Metrics${RESET}`);
  console.log(`  Findings:        ${findings.length}  (${high.length} high severity)`);
  console.log(`  Targets:         ${targets.length}  (${highTargets.length} HIGH signal)\n`);

  if (findings.length > 0) {
    console.log(`${BOLD}Compliance Findings${RESET}`);
    for (const [i, f] of findings.entries()) {
      const col = SEV[f.severity] ?? "";
      console.log(`  [${i + 1}] ${col}${f.rule_family.replace(/_/g, " ")}${RESET}  ·  ${f.severity}  ·  ${f.reviewer_status}`);
      console.log(`      ${DIM}${f.description.slice(0, 100)}${RESET}`);
    }
    console.log();
  }

  if (targets.length > 0) {
    console.log(`${BOLD}Acquisition Targets${RESET}`);
    console.log(`  ${"Domain".padEnd(35)} ${"Score".padEnd(8)} Tier`);
    console.log(`  ${"-".repeat(55)}`);
    for (const t of [...targets].sort((a, b) => b.score - a.score)) {
      const col = t.signal_tier === "HIGH" ? GREEN : DIM;
      console.log(`  ${t.domain_id.slice(0, 33).padEnd(35)} ${String(t.score).padEnd(8)} ${col}${t.signal_tier}${RESET}`);
    }
    console.log();
  }

  console.log(`${DIM}Draft — pending reviewer approval. Run /compliance in the dashboard to review.${RESET}\n`);
}
