/**
 * complicore run <market>
 *
 * Runs the full pipeline for a metro. Spawns the worker with METRO set.
 * Uses real Firecrawl if FIRECRAWL_API_KEY is set, mock otherwise.
 */

import { spawnSync } from "node:child_process";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "../../../../");

export async function cmdRun(market: string): Promise<void> {
  console.log(`Running pipeline for: ${market}\n`);

  const result = spawnSync(
    "node",
    ["--import", "tsx/esm", "src/run.ts"],
    {
      cwd: resolve(ROOT, "apps/worker"),
      env: { ...process.env, METRO: market },
      stdio: "inherit",
    }
  );

  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status ?? 1);
}
