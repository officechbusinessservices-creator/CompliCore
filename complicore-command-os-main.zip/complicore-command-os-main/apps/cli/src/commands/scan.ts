/**
 * complicore scan <url>
 *
 * Scrapes a single URL, normalizes it, runs all 7 rule families,
 * and prints findings to stdout. No DB writes. No auth required.
 *
 * Uses real Firecrawl if FIRECRAWL_API_KEY is set, mock client otherwise.
 */

import { randomUUID } from "node:crypto";
import { createClient } from "@complicore/firecrawl/client";
import { classifyUrl } from "@complicore/firecrawl/classify";
import { scrapePage } from "@complicore/firecrawl/scrape";
import { normalizeSourcePage } from "@complicore/firecrawl/normalize";
import { evaluateAllRules, collectViolations } from "@complicore/rules";
import { createMockClient } from "../../../worker/src/mock-client.js";

const SEV_COLOR: Record<string, string> = {
  high: "\x1b[31m",
  medium: "\x1b[33m",
  low: "\x1b[2m",
};
const RESET = "\x1b[0m";
const BOLD = "\x1b[1m";
const DIM = "\x1b[2m";

export async function cmdScan(url: string): Promise<void> {
  // Validate URL
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    console.error(`✖  Invalid URL: ${url}`);
    process.exit(1);
  }

  const apiKey = process.env["FIRECRAWL_API_KEY"];
  const client = apiKey ? createClient({ apiKey }) : createMockClient();

  if (!apiKey) {
    console.log(`${DIM}FIRECRAWL_API_KEY not set — using mock client${RESET}\n`);
  }

  console.log(`${BOLD}Scanning${RESET} ${url}\n`);

  const classification = classifyUrl(url);
  const domainId = `dom_${randomUUID().slice(0, 8)}`;
  const runId = `scan_${randomUUID().slice(0, 8)}`;

  let scrapeResult;
  try {
    scrapeResult = await scrapePage(client, {
      urlId: `url_${randomUUID().slice(0, 8)}`,
      domainId,
      url,
      contentType: classification.page_type,
      captureScreenshot: false,
    });
  } catch (err) {
    console.error(`✖  Scrape failed: ${err instanceof Error ? err.message : String(err)}`);
    process.exit(1);
  }

  const { sourcePage } = scrapeResult;
  const normalized = normalizeSourcePage(sourcePage);

  const ruleResults = evaluateAllRules({
    run_id: runId,
    domain_id: domainId,
    page: sourcePage,
    normalized,
    screenshot_ref: null,
  });

  const violations = collectViolations(ruleResults);

  if (violations.length === 0) {
    console.log(`✓  No violations found on ${parsed.hostname}`);
    return;
  }

  console.log(`Found ${BOLD}${violations.length}${RESET} finding(s) on ${parsed.hostname}\n`);

  for (const [i, v] of violations.entries()) {
    const col = SEV_COLOR[v.severity] ?? "";
    console.log(`${col}${BOLD}[${i + 1}] ${v.rule_family.replace(/_/g, " ")}${RESET}`);
    console.log(`    Severity:  ${col}${v.severity}${RESET}`);
    console.log(`    Result:    ${v.result}`);
    console.log(`    Confidence: ${v.confidence}`);
    console.log(`    ${v.description}`);
    if (v.snippet) {
      const snip = v.snippet.length > 120 ? v.snippet.slice(0, 120) + "…" : v.snippet;
      console.log(`    ${DIM}"${snip}"${RESET}`);
    }
    console.log();
  }
}
