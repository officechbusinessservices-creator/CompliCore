/**
 * complicore CLI
 *
 * Usage:
 *   complicore scan <url>          — scrape + rules on a single URL
 *   complicore run <market>        — full pipeline for a metro
 *   complicore report <run_id>     — print brief for a completed run
 */

import { cmdScan } from "./commands/scan.js";
import { cmdRun } from "./commands/run.js";
import { cmdReport } from "./commands/report.js";

const [, , command, arg] = process.argv;

const USAGE = `
Usage:
  complicore scan <url>         Scrape a URL and print compliance findings
  complicore run <market>       Run the full pipeline for a metro
  complicore report <run_id>    Print the brief for a completed run
`.trim();

if (!command || command === "--help" || command === "-h") {
  console.log(USAGE);
  process.exit(0);
}

if (!arg) {
  console.error(`✖  complicore ${command} requires an argument\n`);
  console.error(USAGE);
  process.exit(1);
}

switch (command) {
  case "scan":
    await cmdScan(arg);
    break;
  case "run":
    await cmdRun(arg);
    break;
  case "report":
    await cmdReport(arg);
    break;
  default:
    console.error(`✖  Unknown command: ${command}\n`);
    console.error(USAGE);
    process.exit(1);
}
