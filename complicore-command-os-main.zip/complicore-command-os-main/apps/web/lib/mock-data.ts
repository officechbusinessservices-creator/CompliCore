/**
 * Mock data for CompliCore Command OS v1 dashboard shell.
 * All shapes match the output contracts in packages/core/src/output-contracts.ts.
 * No real scraping has occurred — this is UI scaffolding only.
 */

import type {
  ComplianceFindingRow,
  AcquisitionTargetRow,
  GrowthGapItem,
  EvidenceViewerEntry,
} from "@complicore/core/output-contracts";
import type { Domain, Run, Step } from "@complicore/core/types";

// ---------------------------------------------------------------------------
// Run + pipeline status
// ---------------------------------------------------------------------------

export const MOCK_RUN: Run = {
  id: "run_2026_03_28",
  workspace_id: "ws_001",
  status: "completed",
  metro: "Austin, TX",
  started_at: "2026-03-28T06:00:00.000Z",
  completed_at: "2026-03-28T08:43:21.000Z",
  error: null,
  created_at: "2026-03-28T06:00:00.000Z",
};

export const MOCK_STEPS: Step[] = [
  { id: "step_01", run_id: "run_2026_03_28", name: "discover", status: "completed", input_count: 1, output_count: 14, error: null, started_at: "2026-03-28T06:00:10.000Z", completed_at: "2026-03-28T06:04:45.000Z" },
  { id: "step_02", run_id: "run_2026_03_28", name: "map", status: "completed", input_count: 14, output_count: 312, error: null, started_at: "2026-03-28T06:04:50.000Z", completed_at: "2026-03-28T06:18:12.000Z" },
  { id: "step_03", run_id: "run_2026_03_28", name: "classify", status: "completed", input_count: 312, output_count: 289, error: null, started_at: "2026-03-28T06:18:15.000Z", completed_at: "2026-03-28T06:21:08.000Z" },
  { id: "step_04", run_id: "run_2026_03_28", name: "scrape", status: "completed", input_count: 289, output_count: 274, error: null, started_at: "2026-03-28T06:21:10.000Z", completed_at: "2026-03-28T07:52:33.000Z" },
  { id: "step_05", run_id: "run_2026_03_28", name: "normalize", status: "completed", input_count: 274, output_count: 268, error: null, started_at: "2026-03-28T07:52:40.000Z", completed_at: "2026-03-28T08:11:05.000Z" },
  { id: "step_06", run_id: "run_2026_03_28", name: "rules", status: "completed", input_count: 268, output_count: 47, error: null, started_at: "2026-03-28T08:11:10.000Z", completed_at: "2026-03-28T08:38:22.000Z" },
  { id: "step_07", run_id: "run_2026_03_28", name: "brief", status: "completed", input_count: 47, output_count: 1, error: null, started_at: "2026-03-28T08:38:25.000Z", completed_at: "2026-03-28T08:43:21.000Z" },
];

// ---------------------------------------------------------------------------
// Domains
// ---------------------------------------------------------------------------

export const MOCK_DOMAINS: (Domain & { listing_count: number; finding_count: number })[] = [
  { id: "dom_001", run_id: "run_2026_03_28", domain: "austinstays.com", robots_txt_url: "https://austinstays.com/robots.txt", disallowed_paths: [], sitemap_url: "https://austinstays.com/sitemap.xml", status: "mapped", crawled_at: "2026-03-28T07:10:00.000Z", listing_count: 48, finding_count: 9 },
  { id: "dom_002", run_id: "run_2026_03_28", domain: "capitalcityliving.com", robots_txt_url: null, disallowed_paths: ["/admin"], sitemap_url: null, status: "mapped", crawled_at: "2026-03-28T07:14:22.000Z", listing_count: 31, finding_count: 14 },
  { id: "dom_003", run_id: "run_2026_03_28", domain: "txtemporaryhomes.com", robots_txt_url: "https://txtemporaryhomes.com/robots.txt", disallowed_paths: [], sitemap_url: null, status: "mapped", crawled_at: "2026-03-28T07:22:45.000Z", listing_count: 22, finding_count: 6 },
  { id: "dom_004", run_id: "run_2026_03_28", domain: "sixthstreetsuites.com", robots_txt_url: null, disallowed_paths: [], sitemap_url: null, status: "mapped", crawled_at: "2026-03-28T07:31:10.000Z", listing_count: 17, finding_count: 11 },
  { id: "dom_005", run_id: "run_2026_03_28", domain: "austinextendedstay.net", robots_txt_url: "https://austinextendedstay.net/robots.txt", disallowed_paths: ["/wp-admin"], sitemap_url: "https://austinextendedstay.net/sitemap.xml", status: "mapped", crawled_at: "2026-03-28T07:40:55.000Z", listing_count: 28, finding_count: 4 },
  { id: "dom_006", run_id: "run_2026_03_28", domain: "keepaustinhoused.com", robots_txt_url: null, disallowed_paths: [], sitemap_url: null, status: "blocked", crawled_at: null, listing_count: 0, finding_count: 0 },
  { id: "dom_007", run_id: "run_2026_03_28", domain: "zilkerluxury.com", robots_txt_url: null, disallowed_paths: [], sitemap_url: null, status: "unreachable", crawled_at: null, listing_count: 0, finding_count: 0 },
];

// ---------------------------------------------------------------------------
// Headline metrics
// ---------------------------------------------------------------------------

export const HEADLINE_METRICS = {
  compliance_findings_this_week: 44,
  high_severity_findings: 18,
  acquisition_targets_identified: 5,
  high_signal_targets: 2,
  growth_gaps_identified: 6,
  domains_monitored: 7,
  domains_active: 5,
  run_week_ending: "2026-03-28",
};

// ---------------------------------------------------------------------------
// Compliance findings
// ---------------------------------------------------------------------------

export const MOCK_FINDINGS: ComplianceFindingRow[] = [
  {
    finding_id: "cf_001",
    domain: "capitalcityliving.com",
    rule_family: "pricing_transparency",
    severity: "high",
    rule_result: "FAIL",
    description: "No nightly or monthly rate displayed on listing detail pages. Users cannot determine cost without contacting the operator.",
    source_url: "https://capitalcityliving.com/listings/downtown-studio-4b",
    snippet: "\"Contact us for pricing\" — no rate, no fee schedule, no total cost estimate visible on page.",
    screenshot_ref: "scr_cc_001",
    confidence: "high",
    reviewer_status: "approved",
    created_at: "2026-03-28T08:38:25.000Z",
  },
  {
    finding_id: "cf_002",
    domain: "capitalcityliving.com",
    rule_family: "policy_coherence",
    severity: "high",
    rule_result: "FAIL",
    description: "Cancellation policy referenced in footer link is a 404. No inline cancellation terms present.",
    source_url: "https://capitalcityliving.com/terms",
    snippet: "\"See our cancellation policy\" links to /cancellation-policy which returns HTTP 404.",
    screenshot_ref: "scr_cc_002",
    confidence: "high",
    reviewer_status: "approved",
    created_at: "2026-03-28T08:38:26.000Z",
  },
  {
    finding_id: "cf_003",
    domain: "sixthstreetsuites.com",
    rule_family: "privacy_presence",
    severity: "high",
    rule_result: "FAIL",
    description: "No privacy policy found on any page. Site collects email via contact form without disclosure.",
    source_url: "https://sixthstreetsuites.com/contact",
    snippet: "Contact form requests name, email, and phone. No link to privacy policy present in form or footer.",
    screenshot_ref: "scr_ss_001",
    confidence: "high",
    reviewer_status: "approved",
    created_at: "2026-03-28T08:38:27.000Z",
  },
  {
    finding_id: "cf_004",
    domain: "sixthstreetsuites.com",
    rule_family: "pricing_transparency",
    severity: "high",
    rule_result: "FAIL",
    description: "Prices shown as ranges with no breakdown. Cleaning fee and service fee not itemized.",
    source_url: "https://sixthstreetsuites.com/suites/lady-bird-one-bed",
    snippet: "\"From $3,200–$4,100/mo\" — range shown but no fee breakdown, no total cost, no explanation of variance.",
    screenshot_ref: "scr_ss_002",
    confidence: "high",
    reviewer_status: "needs_review",
    created_at: "2026-03-28T08:38:28.000Z",
  },
  {
    finding_id: "cf_005",
    domain: "austinstays.com",
    rule_family: "disclosure_signals",
    severity: "medium",
    rule_result: "WARN",
    description: "No operator license or registration number disclosed on any listing page.",
    source_url: "https://austinstays.com/listings/south-congress-2br",
    snippet: "Listing page contains unit description and amenities but no STR license number or operator registration.",
    screenshot_ref: null,
    confidence: "medium",
    reviewer_status: "pending",
    created_at: "2026-03-28T08:38:29.000Z",
  },
  {
    finding_id: "cf_006",
    domain: "txtemporaryhomes.com",
    rule_family: "schema_quality",
    severity: "medium",
    rule_result: "FAIL",
    description: "No structured data found on 18 of 22 listing pages. Missing LodgingBusiness schema reduces search engine discoverability.",
    source_url: "https://txtemporaryhomes.com/units/oak-hill-furnished-1br",
    snippet: "Page source contains no JSON-LD, no schema.org types, no OpenGraph tags. Only meta title present.",
    screenshot_ref: "scr_tx_001",
    confidence: "high",
    reviewer_status: "approved",
    created_at: "2026-03-28T08:38:30.000Z",
  },
  {
    finding_id: "cf_007",
    domain: "capitalcityliving.com",
    rule_family: "contact_path_completeness",
    severity: "medium",
    rule_result: "FAIL",
    description: "No phone number or live chat available. Only contact method is an email form with no stated response time.",
    source_url: "https://capitalcityliving.com/contact",
    snippet: "\"Fill out the form below and we'll get back to you.\" No phone, no chat widget, no stated response SLA.",
    screenshot_ref: "scr_cc_003",
    confidence: "high",
    reviewer_status: "approved",
    created_at: "2026-03-28T08:38:31.000Z",
  },
  {
    finding_id: "cf_008",
    domain: "sixthstreetsuites.com",
    rule_family: "trust_signals",
    severity: "medium",
    rule_result: "WARN",
    description: "No reviews, ratings, or third-party trust badges present on any listing or homepage.",
    source_url: "https://sixthstreetsuites.com",
    snippet: "Homepage and all listing pages scraped. No review widget, star rating, or trust badge found.",
    screenshot_ref: null,
    confidence: "medium",
    reviewer_status: "pending",
    created_at: "2026-03-28T08:38:32.000Z",
  },
];

// ---------------------------------------------------------------------------
// Growth intelligence
// ---------------------------------------------------------------------------

export const MOCK_GROWTH_GAPS: GrowthGapItem[] = [
  {
    rule_family: "pricing_transparency",
    competitor_fail_count: 4,
    market_gap_signal: "strong",
    operator_differentiation_opportunity: "Publishing a complete itemized fee schedule and all-inclusive monthly totals on every listing page would differentiate from 4 of 5 active competitors who obscure total cost.",
    contributing_gap_types: ["no_pricing", "no_fee_disclosure"],
  },
  {
    rule_family: "policy_coherence",
    competitor_fail_count: 3,
    market_gap_signal: "strong",
    operator_differentiation_opportunity: "A clearly linked, non-404 cancellation policy with inline terms on listing pages addresses a gap found in 3 competitors, including the market leader by listing volume.",
    contributing_gap_types: ["no_cancellation_policy"],
  },
  {
    rule_family: "privacy_presence",
    competitor_fail_count: 3,
    market_gap_signal: "moderate",
    operator_differentiation_opportunity: "A GDPR/CCPA-compliant privacy policy linked from every form and footer would address a gap found in 3 active competitors, reducing compliance exposure for enterprise clients.",
    contributing_gap_types: ["no_privacy_policy"],
  },
  {
    rule_family: "schema_quality",
    competitor_fail_count: 4,
    market_gap_signal: "strong",
    operator_differentiation_opportunity: "Adding LodgingBusiness JSON-LD to all listing detail pages would give a search engine discoverability edge over 4 competitors with no or partial structured data.",
    contributing_gap_types: [],
  },
  {
    rule_family: "trust_signals",
    competitor_fail_count: 3,
    market_gap_signal: "moderate",
    operator_differentiation_opportunity: "Displaying verified guest reviews and a third-party trust badge on listing pages would stand out against 3 competitors with no visible social proof.",
    contributing_gap_types: ["no_trust_signals"],
  },
  {
    rule_family: "contact_path_completeness",
    competitor_fail_count: 2,
    market_gap_signal: "weak",
    operator_differentiation_opportunity: "Publishing a direct phone number and live chat option would improve enterprise buyer confidence versus 2 competitors that offer only email contact with no stated SLA.",
    contributing_gap_types: ["no_contact_path"],
  },
];

// ---------------------------------------------------------------------------
// Acquisition targets
// ---------------------------------------------------------------------------

export const MOCK_TARGETS: AcquisitionTargetRow[] = [
  {
    target_id: "ot_001",
    domain: "capitalcityliving.com",
    score: 84,
    signal_tier: "HIGH",
    top_signals: ["Pricing hidden on all listing pages (FAIL)", "Cancellation policy returns 404 (FAIL)", "No phone or live chat contact path (FAIL)"],
    recommendation: "Web signals show pricing opacity, broken policy links, and incomplete contact paths across 31 listing pages, consistent with operator infrastructure under-investment.",
    contributing_finding_count: 14,
    contributing_gap_count: 8,
    reviewer_status: "approved",
    created_at: "2026-03-28T08:43:00.000Z",
  },
  {
    target_id: "ot_002",
    domain: "sixthstreetsuites.com",
    score: 76,
    signal_tier: "HIGH",
    top_signals: ["No privacy policy on site collecting personal data (FAIL)", "Pricing range shown with no fee itemization (FAIL)", "No trust signals on any page (WARN)"],
    recommendation: "Web signals show privacy compliance gaps, opaque pricing, and absence of social proof across 17 listing pages.",
    contributing_finding_count: 11,
    contributing_gap_count: 6,
    reviewer_status: "needs_review",
    created_at: "2026-03-28T08:43:01.000Z",
  },
  {
    target_id: "ot_003",
    domain: "txtemporaryhomes.com",
    score: 51,
    signal_tier: "MODERATE",
    top_signals: ["Schema quality FAIL on 82% of listing pages", "No cancellation policy page found", "No fee disclosure on listing detail pages"],
    recommendation: "Web signals show weak structured data and missing policy content on 22 listing pages, suggesting limited SEO investment.",
    contributing_finding_count: 6,
    contributing_gap_count: 5,
    reviewer_status: "pending",
    created_at: "2026-03-28T08:43:02.000Z",
  },
  {
    target_id: "ot_004",
    domain: "austinstays.com",
    score: 38,
    signal_tier: "LOW",
    top_signals: ["Disclosure signals WARN on most listings", "No STR license numbers displayed"],
    recommendation: "Web signals show partial disclosure compliance gaps on 48 listing pages; pricing and policy content is otherwise present.",
    contributing_finding_count: 9,
    contributing_gap_count: 3,
    reviewer_status: "pending",
    created_at: "2026-03-28T08:43:03.000Z",
  },
  {
    target_id: "ot_005",
    domain: "austinextendedstay.net",
    score: 22,
    signal_tier: "LOW",
    top_signals: ["Minor schema gaps on 4 pages"],
    recommendation: "Web signals show minor structured data gaps; pricing, policy, and contact paths appear complete across 28 listing pages.",
    contributing_finding_count: 4,
    contributing_gap_count: 1,
    reviewer_status: "approved",
    created_at: "2026-03-28T08:43:04.000Z",
  },
];

// ---------------------------------------------------------------------------
// Reports
// ---------------------------------------------------------------------------

export const MOCK_REPORTS = [
  { id: "rpt_001", type: "weekly_brief" as const, metro: "Austin, TX", status: "approved" as const, generated_at: "2026-03-28T08:43:21.000Z", approved_at: "2026-03-28T10:15:00.000Z", exported_at: null },
  { id: "rpt_002", type: "compliance_log" as const, metro: "Austin, TX", status: "approved" as const, generated_at: "2026-03-28T08:43:21.000Z", approved_at: "2026-03-28T10:15:00.000Z", exported_at: "2026-03-28T10:20:00.000Z" },
  { id: "rpt_003", type: "growth_brief" as const, metro: "Austin, TX", status: "draft" as const, generated_at: "2026-03-28T08:43:21.000Z", approved_at: null, exported_at: null },
  { id: "rpt_004", type: "acquisition_list" as const, metro: "Austin, TX", status: "draft" as const, generated_at: "2026-03-28T08:43:21.000Z", approved_at: null, exported_at: null },
];

// ---------------------------------------------------------------------------
// Evidence viewer entries (indexed by finding_id)
// ---------------------------------------------------------------------------

export const MOCK_EVIDENCE: Record<string, EvidenceViewerEntry> = {
  cf_001: {
    finding_id: "cf_001",
    finding_type: "compliance_finding",
    source_url: "https://capitalcityliving.com/listings/downtown-studio-4b",
    snippet: "\"Contact us for pricing\" — no rate, no fee schedule, no total cost estimate visible on page.",
    screenshot_ref: "scr_cc_001",
    confidence: "high",
    reviewer_status: "approved",
    rule_family: "pricing_transparency",
    domain: "capitalcityliving.com",
    scraped_at: "2026-03-28T07:14:22.000Z",
  },
  cf_002: {
    finding_id: "cf_002",
    finding_type: "compliance_finding",
    source_url: "https://capitalcityliving.com/terms",
    snippet: "\"See our cancellation policy\" links to /cancellation-policy which returns HTTP 404.",
    screenshot_ref: "scr_cc_002",
    confidence: "high",
    reviewer_status: "approved",
    rule_family: "policy_coherence",
    domain: "capitalcityliving.com",
    scraped_at: "2026-03-28T07:15:10.000Z",
  },
  cf_003: {
    finding_id: "cf_003",
    finding_type: "compliance_finding",
    source_url: "https://sixthstreetsuites.com/contact",
    snippet: "Contact form requests name, email, and phone. No link to privacy policy present in form or footer.",
    screenshot_ref: "scr_ss_001",
    confidence: "high",
    reviewer_status: "approved",
    rule_family: "privacy_presence",
    domain: "sixthstreetsuites.com",
    scraped_at: "2026-03-28T07:31:10.000Z",
  },
  cf_004: {
    finding_id: "cf_004",
    finding_type: "compliance_finding",
    source_url: "https://sixthstreetsuites.com/suites/lady-bird-one-bed",
    snippet: "\"From $3,200–$4,100/mo\" — range shown but no fee breakdown, no total cost, no explanation of variance.",
    screenshot_ref: "scr_ss_002",
    confidence: "high",
    reviewer_status: "needs_review",
    rule_family: "pricing_transparency",
    domain: "sixthstreetsuites.com",
    scraped_at: "2026-03-28T07:32:44.000Z",
  },
  cf_005: {
    finding_id: "cf_005",
    finding_type: "compliance_finding",
    source_url: "https://austinstays.com/listings/south-congress-2br",
    snippet: "Listing page contains unit description and amenities but no STR license number or operator registration.",
    screenshot_ref: null,
    confidence: "medium",
    reviewer_status: "pending",
    rule_family: "disclosure_signals",
    domain: "austinstays.com",
    scraped_at: "2026-03-28T07:10:00.000Z",
  },
  cf_006: {
    finding_id: "cf_006",
    finding_type: "compliance_finding",
    source_url: "https://txtemporaryhomes.com/units/oak-hill-furnished-1br",
    snippet: "Page source contains no JSON-LD, no schema.org types, no OpenGraph tags. Only meta title present.",
    screenshot_ref: "scr_tx_001",
    confidence: "high",
    reviewer_status: "approved",
    rule_family: "schema_quality",
    domain: "txtemporaryhomes.com",
    scraped_at: "2026-03-28T07:22:45.000Z",
  },
  cf_007: {
    finding_id: "cf_007",
    finding_type: "compliance_finding",
    source_url: "https://capitalcityliving.com/contact",
    snippet: "\"Fill out the form below and we'll get back to you.\" No phone, no chat widget, no stated response SLA.",
    screenshot_ref: "scr_cc_003",
    confidence: "high",
    reviewer_status: "approved",
    rule_family: "contact_path_completeness",
    domain: "capitalcityliving.com",
    scraped_at: "2026-03-28T07:16:05.000Z",
  },
  cf_008: {
    finding_id: "cf_008",
    finding_type: "compliance_finding",
    source_url: "https://sixthstreetsuites.com",
    snippet: "Homepage and all listing pages scraped. No review widget, star rating, or trust badge found.",
    screenshot_ref: null,
    confidence: "medium",
    reviewer_status: "pending",
    rule_family: "trust_signals",
    domain: "sixthstreetsuites.com",
    scraped_at: "2026-03-28T07:31:10.000Z",
  },
  ot_001: {
    finding_id: "ot_001",
    finding_type: "opportunity_target",
    source_url: "https://capitalcityliving.com",
    snippet: "14 compliance findings and 8 content gaps across 31 listing pages. Pricing hidden, cancellation policy broken, contact path incomplete.",
    screenshot_ref: "scr_cc_001",
    confidence: "high",
    reviewer_status: "approved",
    rule_family: null,
    domain: "capitalcityliving.com",
    scraped_at: "2026-03-28T07:14:22.000Z",
  },
  ot_002: {
    finding_id: "ot_002",
    finding_type: "opportunity_target",
    source_url: "https://sixthstreetsuites.com",
    snippet: "11 compliance findings and 6 content gaps across 17 listing pages. Privacy policy absent, pricing opaque.",
    screenshot_ref: "scr_ss_001",
    confidence: "high",
    reviewer_status: "needs_review",
    rule_family: null,
    domain: "sixthstreetsuites.com",
    scraped_at: "2026-03-28T07:31:10.000Z",
  },
};
