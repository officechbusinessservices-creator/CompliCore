/**
 * Web app query layer.
 *
 * Wraps @complicore/core repos with a shared DB instance.
 * All exports are server-only async functions. Do not import from client components.
 *
 * Naming conventions:
 *   get*        — single record or null
 *   list.../get...s — multiple records
 *   *Detail     — enriched shape with resolved relations
 *   *Metrics    — aggregate counts for a run
 */

import { asc, desc, eq, inArray } from "drizzle-orm";
import { getDb } from "@complicore/core/db/client";
import {
  runs,
  steps,
  opportunityTargets,
  complianceFindings,
  contentGaps,
  outboundBriefs,
} from "@complicore/core/db/schema";
import {
  findDomainById,
  findFindingById,
  findReportById,
  findSourcePageById,
  findTargetById,
  listAuditEventsByEntity,
  listAuditEventsByRun,
  listDomainsByRun,
  listFindingsByRun,
  listReportsByRun,
  listTargetsByRun,
} from "@complicore/core/db";
import type {
  AuditEvent,
  ComplianceFinding,
  ContentGap,
  Domain,
  ISODatetime,
  OpportunityTarget,
  OpportunityScoreBreakdown,
  OutboundBrief,
  Report,
  Run,
  SourcePage,
  Step,
} from "@complicore/core/types";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function tsNull(d: Date | null | undefined): ISODatetime | null {
  return d != null ? d.toISOString() : null;
}

const STEP_ORDER: Step["name"][] = [
  "discover",
  "map",
  "classify",
  "scrape",
  "normalize",
  "rules",
  "brief",
];

function rowToRun(row: typeof runs.$inferSelect): Run {
  return {
    id: row.id,
    workspace_id: row.workspace_id,
    status: row.status,
    metro: row.metro,
    started_at: tsNull(row.started_at),
    completed_at: tsNull(row.completed_at),
    error: row.error ?? null,
    created_at: row.created_at.toISOString(),
  };
}

// ---------------------------------------------------------------------------
// Return types for enriched queries
// ---------------------------------------------------------------------------

export interface OverviewMetrics {
  run: Run;
  /** Distinct domains that have at least one finding in this run. */
  domain_count: number;
  /** Distinct source pages that have at least one finding in this run. */
  page_count: number;
  finding_count: number;
  findings_high_severity: number;
  findings_pending_review: number;
  target_count: number;
  report_count: number;
}

/**
 * ComplianceFinding enriched with:
 *   rule_name           — human label, currently mirrors rule_family
 *   report_id           — id of the first report for this run, null if no reports yet
 *   source_page         — the page this finding was drawn from (null if purged)
 *   content_gaps_on_page — content gaps co-located on the same source page
 */
export interface FindingDetail extends ComplianceFinding {
  rule_name: string;
  report_id: string | null;
  source_page: SourcePage | null;
  content_gaps_on_page: ContentGap[];
}

/**
 * Everything needed to render a finding's evidence panel:
 *   source_page         — the page the finding was drawn from
 *   content_gaps_on_page — gaps recorded on the same source page
 */
export interface EvidenceBundle {
  finding: ComplianceFinding;
  source_page: SourcePage;
  content_gaps_on_page: ContentGap[];
}

/**
 * OpportunityTarget enriched with resolved relations:
 *   domain               — the domain row the target belongs to
 *   contributing_gaps    — resolved ContentGap rows
 *   contributing_findings — resolved ComplianceFinding rows
 */
export interface TargetDetail extends OpportunityTarget {
  domain: Domain;
  contributing_gaps: ContentGap[];
  contributing_findings: ComplianceFinding[];
}

/**
 * Report with all findings for the same run, a target count,
 * and the outbound briefs generated for this run.
 */
export interface ReportDetail extends Report {
  findings: ComplianceFinding[];
  target_count: number;
  briefs: OutboundBrief[];
}

// ---------------------------------------------------------------------------
// Runs
// ---------------------------------------------------------------------------

/** Returns the single most recent run. v1 has exactly one workspace. */
export async function getLatestRun(): Promise<Run | null> {
  const db = getDb();
  const [row] = await db
    .select()
    .from(runs)
    .orderBy(desc(runs.created_at))
    .limit(1);
  return row != null ? rowToRun(row) : null;
}

/** Returns a single run by ID, or null if not found. */
export async function getRunById(id: string): Promise<Run | null> {
  const db = getDb();
  const [row] = await db.select().from(runs).where(eq(runs.id, id));
  return row != null ? rowToRun(row) : null;
}

/** Returns the most recent N runs, newest first. */
export async function getLatestRuns(limit = 10): Promise<Run[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(runs)
    .orderBy(desc(runs.created_at))
    .limit(limit);
  return rows.map(rowToRun);
}

// ---------------------------------------------------------------------------
// Overview metrics
// ---------------------------------------------------------------------------

/**
 * Aggregate counts for a single run.
 * domain_count and page_count are derived from findings (pages/domains that
 * produced at least one finding). Returns null if the run does not exist.
 */
export async function getOverviewMetrics(runId: string): Promise<OverviewMetrics | null> {
  const db = getDb();

  const [runRow] = await db.select().from(runs).where(eq(runs.id, runId));
  if (runRow == null) return null;

  const [findings, targets, reports] = await Promise.all([
    listFindingsByRun(db, runId),
    listTargetsByRun(db, runId),
    listReportsByRun(db, runId),
  ]);

  const uniqueDomains = new Set(findings.map((f) => f.domain_id));
  const uniquePages = new Set(findings.map((f) => f.source_page_id));

  return {
    run: rowToRun(runRow),
    domain_count: uniqueDomains.size,
    page_count: uniquePages.size,
    finding_count: findings.length,
    findings_high_severity: findings.filter((f) => f.severity === "high").length,
    findings_pending_review: findings.filter((f) => f.reviewer_status === "pending").length,
    target_count: targets.length,
    report_count: reports.length,
  };
}

// ---------------------------------------------------------------------------
// Steps (no dedicated repo — direct query)
// ---------------------------------------------------------------------------

export async function getStepsByRun(runId: string): Promise<Step[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(steps)
    .where(eq(steps.run_id, runId))
    .orderBy(asc(steps.started_at));
  return rows
    .map((r) => ({
      id: r.id,
      run_id: r.run_id,
      name: r.name as Step["name"],
      status: r.status as Step["status"],
      input_count: r.input_count,
      output_count: r.output_count,
      error: r.error ?? null,
      started_at: tsNull(r.started_at),
      completed_at: tsNull(r.completed_at),
    }))
    .sort((a, b) => STEP_ORDER.indexOf(a.name) - STEP_ORDER.indexOf(b.name));
}

// ---------------------------------------------------------------------------
// Findings
// ---------------------------------------------------------------------------

export async function getFindingsByRun(runId: string): Promise<ComplianceFinding[]> {
  return listFindingsByRun(getDb(), runId);
}

export async function getFindingById(id: string): Promise<ComplianceFinding | null> {
  return findFindingById(getDb(), id);
}

/**
 * Enriched finding detail.
 * Adds rule_name (= rule_family), report_id (first report for this run),
 * source_page, and content_gaps_on_page (linked evidence records).
 */
export async function getFindingDetail(id: string): Promise<FindingDetail | null> {
  const db = getDb();
  const finding = await findFindingById(db, id);
  if (finding == null) return null;

  const [reportsForRun, source_page] = await Promise.all([
    listReportsByRun(db, finding.run_id),
    findSourcePageById(db, finding.source_page_id),
  ]);
  const report_id = reportsForRun[0]?.id ?? null;

  const gapRows =
    source_page != null
      ? await db
          .select()
          .from(contentGaps)
          .where(eq(contentGaps.source_page_id, finding.source_page_id))
      : [];

  const content_gaps_on_page: ContentGap[] = gapRows.map((r) => ({
    id: r.id,
    source_page_id: r.source_page_id,
    domain_id: r.domain_id,
    gap_type: r.gap_type as ContentGap["gap_type"],
    description: r.description,
  }));

  return { ...finding, rule_name: finding.rule_family, report_id, source_page, content_gaps_on_page };
}

/** Returns domain_id → finding count for all findings in a run. */
export async function getFindingCountsByDomainId(
  runId: string
): Promise<Map<string, number>> {
  const findings = await listFindingsByRun(getDb(), runId);
  const map = new Map<string, number>();
  for (const f of findings) {
    map.set(f.domain_id, (map.get(f.domain_id) ?? 0) + 1);
  }
  return map;
}

// ---------------------------------------------------------------------------
// Evidence bundle
// ---------------------------------------------------------------------------

/**
 * Returns the finding, its source page, and any content gaps on that page.
 * This is the full evidence context needed for the finding detail panel.
 */
export async function getEvidenceBundleForFinding(
  findingId: string
): Promise<EvidenceBundle | null> {
  const db = getDb();

  const finding = await findFindingById(db, findingId);
  if (finding == null) return null;

  const source_page = await findSourcePageById(db, finding.source_page_id);
  if (source_page == null) return null;

  const gapRows = await db
    .select()
    .from(contentGaps)
    .where(eq(contentGaps.source_page_id, finding.source_page_id));

  const content_gaps_on_page: ContentGap[] = gapRows.map((r) => ({
    id: r.id,
    source_page_id: r.source_page_id,
    domain_id: r.domain_id,
    gap_type: r.gap_type as ContentGap["gap_type"],
    description: r.description,
  }));

  return { finding, source_page, content_gaps_on_page };
}

// ---------------------------------------------------------------------------
// Targets
// ---------------------------------------------------------------------------

export async function getTargetsByRun(runId: string): Promise<OpportunityTarget[]> {
  return listTargetsByRun(getDb(), runId);
}

export async function getTargetById(id: string): Promise<OpportunityTarget | null> {
  const db = getDb();
  const [row] = await db
    .select()
    .from(opportunityTargets)
    .where(eq(opportunityTargets.id, id));
  if (row == null) return null;
  return {
    id: row.id,
    domain_id: row.domain_id,
    run_id: row.run_id,
    score: row.score,
    signal_tier: row.signal_tier as OpportunityTarget["signal_tier"],
    score_breakdown: row.score_breakdown as OpportunityScoreBreakdown,
    contributing_finding_ids: (row.contributing_finding_ids ?? []) as string[],
    contributing_gap_ids: (row.contributing_gap_ids ?? []) as string[],
    top_signals: (row.top_signals ?? []) as string[],
    recommendation: row.recommendation,
    reviewer_status: row.reviewer_status,
    created_at: row.created_at.toISOString(),
  };
}

/**
 * Enriched target detail.
 * Resolves contributing_gap_ids → ContentGap rows
 * and contributing_finding_ids → ComplianceFinding rows.
 * Guards against empty-array inArray calls (Postgres rejects WHERE id IN ()).
 */
export async function getTargetDetail(id: string): Promise<TargetDetail | null> {
  const db = getDb();

  const target = await findTargetById(db, id);
  if (target == null) return null;

  const domain = await findDomainById(db, target.domain_id);
  if (domain == null) return null;

  const [contributing_gaps, contributing_findings] = await Promise.all([
    target.contributing_gap_ids.length > 0
      ? db
          .select()
          .from(contentGaps)
          .where(inArray(contentGaps.id, target.contributing_gap_ids))
          .then((rows) =>
            rows.map((r) => ({
              id: r.id,
              source_page_id: r.source_page_id,
              domain_id: r.domain_id,
              gap_type: r.gap_type as ContentGap["gap_type"],
              description: r.description,
            }))
          )
      : ([] as ContentGap[]),

    target.contributing_finding_ids.length > 0
      ? db
          .select()
          .from(complianceFindings)
          .where(inArray(complianceFindings.id, target.contributing_finding_ids))
          .then((rows) =>
            rows.map(
              (r): ComplianceFinding => ({
                id: r.id,
                source_page_id: r.source_page_id,
                domain_id: r.domain_id,
                run_id: r.run_id,
                rule_family: r.rule_family as ComplianceFinding["rule_family"],
                rule_result: r.rule_result as ComplianceFinding["rule_result"],
                severity: r.severity as ComplianceFinding["severity"],
                description: r.description,
                status: r.status as ComplianceFinding["status"],
                source_url: r.source_url,
                screenshot_ref: r.screenshot_ref ?? null,
                snippet: r.snippet,
                confidence: r.confidence,
                reviewer_status: r.reviewer_status,
                created_at: r.created_at.toISOString(),
              })
            )
          )
      : ([] as ComplianceFinding[]),
  ]);

  return { ...target, domain, contributing_gaps, contributing_findings };
}

// ---------------------------------------------------------------------------
// Domains
// ---------------------------------------------------------------------------

export async function getDomainsByRun(runId: string): Promise<Domain[]> {
  return listDomainsByRun(getDb(), runId);
}

// ---------------------------------------------------------------------------
// Reports
// ---------------------------------------------------------------------------

export async function getReportsByRun(runId: string): Promise<Report[]> {
  return listReportsByRun(getDb(), runId);
}

export async function getReportById(id: string): Promise<Report | null> {
  return findReportById(getDb(), id);
}

/**
 * Enriched report detail.
 * Attaches all findings for the run and the opportunity target count.
 */
export async function getReportDetail(id: string): Promise<ReportDetail | null> {
  const db = getDb();

  const report = await findReportById(db, id);
  if (report == null) return null;

  const [findings, targets, briefRows] = await Promise.all([
    listFindingsByRun(db, report.run_id),
    listTargetsByRun(db, report.run_id),
    db.select().from(outboundBriefs).where(eq(outboundBriefs.run_id, report.run_id)),
  ]);

  const briefs: OutboundBrief[] = briefRows.map((r) => ({
    id: r.id,
    run_id: r.run_id,
    opportunity_target_id: r.opportunity_target_id,
    content: r.content,
    status: r.status as OutboundBrief["status"],
    reviewer_status: r.reviewer_status,
    created_at: r.created_at.toISOString(),
    approved_at: r.approved_at != null ? r.approved_at.toISOString() : null,
  }));

  return { ...report, findings, target_count: targets.length, briefs };
}

// ---------------------------------------------------------------------------
// Audit events
// ---------------------------------------------------------------------------

export async function getAuditEventsByRun(runId: string): Promise<AuditEvent[]> {
  return listAuditEventsByRun(getDb(), runId);
}

/** Returns all audit events for a single entity (finding or target), newest first. */
export async function getAuditEventsByFinding(findingId: string): Promise<AuditEvent[]> {
  return listAuditEventsByEntity(getDb(), findingId);
}

// ---------------------------------------------------------------------------
// Outbound briefs
// ---------------------------------------------------------------------------

/** Returns all outbound briefs for a single opportunity target, newest first. */
export async function getOutboundBriefsByTarget(targetId: string): Promise<OutboundBrief[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(outboundBriefs)
    .where(eq(outboundBriefs.opportunity_target_id, targetId))
    .orderBy(desc(outboundBriefs.created_at));
  return rows.map((r) => ({
    id: r.id,
    run_id: r.run_id,
    opportunity_target_id: r.opportunity_target_id,
    content: r.content,
    status: r.status as OutboundBrief["status"],
    reviewer_status: r.reviewer_status,
    created_at: r.created_at.toISOString(),
    approved_at: r.approved_at != null ? r.approved_at.toISOString() : null,
  }));
}
