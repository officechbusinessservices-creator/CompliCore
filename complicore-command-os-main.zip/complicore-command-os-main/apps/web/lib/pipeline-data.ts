/**
 * Loads pipeline output for the dashboard from the DB.
 *
 * Previously read from apps/worker/output/*.json files.
 * The DB is now the system of record. Same interface is preserved so
 * compliance/acquisition pages continue to work unchanged.
 */

import type { ComplianceFindingRow, AcquisitionTargetRow } from "@complicore/core/output-contracts";
import {
  getLatestRun,
  getFindingsByRun,
  getTargetsByRun,
  getDomainsByRun,
} from "./queries";

/** Shape used by the /api/review route to persist reviewer overrides locally. */
export interface ReviewState {
  findings: Record<string, "pending" | "approved" | "needs_review" | "rejected">;
  targets: Record<string, "pending" | "approved" | "needs_review" | "rejected">;
}

async function buildDomainMap(runId: string): Promise<Map<string, string>> {
  const domains = await getDomainsByRun(runId);
  return new Map(domains.map((d) => [d.id, d.domain]));
}

export async function loadFindings(): Promise<ComplianceFindingRow[]> {
  const run = await getLatestRun();
  if (run == null) return [];
  const [findings, domainMap] = await Promise.all([
    getFindingsByRun(run.id),
    buildDomainMap(run.id),
  ]);
  return findings.map((f) => ({
    finding_id: f.id,
    domain: domainMap.get(f.domain_id) ?? f.domain_id,
    rule_family: f.rule_family,
    severity: f.severity,
    rule_result: f.rule_result,
    description: f.description,
    source_url: f.source_url,
    snippet: f.snippet,
    screenshot_ref: f.screenshot_ref,
    confidence: f.confidence,
    reviewer_status: f.reviewer_status,
    created_at: f.created_at,
  }));
}

export async function loadTargets(): Promise<AcquisitionTargetRow[]> {
  const run = await getLatestRun();
  if (run == null) return [];
  const [targets, domainMap] = await Promise.all([
    getTargetsByRun(run.id),
    buildDomainMap(run.id),
  ]);
  return targets.map((t) => ({
    target_id: t.id,
    domain: domainMap.get(t.domain_id) ?? t.domain_id,
    score: t.score,
    signal_tier: t.signal_tier,
    top_signals: t.top_signals,
    recommendation: t.recommendation,
    contributing_finding_count: t.contributing_finding_ids.length,
    contributing_gap_count: t.contributing_gap_ids.length,
    reviewer_status: t.reviewer_status,
    created_at: t.created_at,
  }));
}
