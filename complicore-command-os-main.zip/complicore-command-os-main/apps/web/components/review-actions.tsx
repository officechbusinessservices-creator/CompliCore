"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";

type ReviewStatus = "pending" | "needs_review" | "approved" | "rejected";
type Collection = "findings" | "targets" | "briefs";

interface ReviewActionsProps {
  id: string;
  collection: Collection;
  currentStatus: ReviewStatus;
}

async function postReview(
  collection: Collection,
  id: string,
  status: ReviewStatus,
  reviewer_note?: string,
): Promise<{ ok: boolean; error?: string }> {
  const res = await fetch("/api/review", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ collection, id, status, reviewer_note }),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({})) as { error?: string };
    return { ok: false, error: data.error ?? "request failed" };
  }
  return { ok: true };
}

export function ReviewActions({ id, collection, currentStatus }: ReviewActionsProps) {
  const router = useRouter();
  const [status, setStatus] = useState<ReviewStatus>(currentStatus);
  const [isPending, startTransition] = useTransition();
  const [mode, setMode] = useState<"idle" | "rejecting">("idle");
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);

  async function transition(next: ReviewStatus, reviewer_note?: string) {
    setError(null);
    const result = await postReview(collection, id, next, reviewer_note);
    if (!result.ok) {
      setError(result.error ?? "failed");
      return;
    }
    setStatus(next);
    setMode("idle");
    setNote("");
    startTransition(() => router.refresh());
  }

  async function submitReject() {
    if (note.trim().length === 0) {
      setError("Rejection requires a note.");
      return;
    }
    await transition("rejected", note.trim());
  }

  // Rejecting — show note input
  if (mode === "rejecting") {
    return (
      <div className="flex flex-col gap-1.5">
        <textarea
          value={note}
          onChange={(e) => { setNote(e.target.value); setError(null); }}
          placeholder="Reason for rejection (required)"
          rows={2}
          className="text-xs font-mono bg-zinc-800 border border-zinc-700 rounded px-2 py-1 text-zinc-300 placeholder:text-zinc-600 resize-none focus:outline-none focus:border-zinc-500 w-48"
        />
        {error && <p className="text-xs font-mono text-red-500">{error}</p>}
        <div className="flex items-center gap-2">
          <button
            onClick={submitReject}
            disabled={isPending}
            className="text-xs font-mono text-red-400 hover:text-red-300 transition-colors disabled:opacity-40"
          >
            confirm reject
          </button>
          <button
            onClick={() => { setMode("idle"); setNote(""); setError(null); }}
            className="text-xs font-mono text-zinc-600 hover:text-zinc-400 transition-colors"
          >
            cancel
          </button>
        </div>
      </div>
    );
  }

  // Settled states — show label + undo
  if (status === "approved") {
    return (
      <div className="flex items-center gap-1.5">
        <span className="text-xs font-mono text-emerald-500">approved</span>
        <button
          onClick={() => transition("pending")}
          disabled={isPending}
          className="text-xs font-mono text-zinc-700 hover:text-zinc-500 transition-colors disabled:opacity-40"
        >
          undo
        </button>
      </div>
    );
  }

  if (status === "rejected") {
    return (
      <div className="flex items-center gap-1.5">
        <span className="text-xs font-mono text-red-500">rejected</span>
        <button
          onClick={() => transition("pending")}
          disabled={isPending}
          className="text-xs font-mono text-zinc-700 hover:text-zinc-500 transition-colors disabled:opacity-40"
        >
          undo
        </button>
      </div>
    );
  }

  // pending or needs_review — show action buttons
  return (
    <div className="flex flex-col gap-1">
      <div className="flex items-center gap-1">
        <button
          onClick={() => transition("approved")}
          disabled={isPending}
          className="text-xs font-mono text-zinc-600 hover:text-emerald-400 transition-colors disabled:opacity-40"
        >
          approve
        </button>
        {status === "pending" && (
          <>
            <span className="text-zinc-800">·</span>
            <button
              onClick={() => transition("needs_review")}
              disabled={isPending}
              className="text-xs font-mono text-zinc-600 hover:text-amber-400 transition-colors disabled:opacity-40"
            >
              flag
            </button>
          </>
        )}
        <span className="text-zinc-800">·</span>
        <button
          onClick={() => setMode("rejecting")}
          disabled={isPending}
          className="text-xs font-mono text-zinc-600 hover:text-red-400 transition-colors disabled:opacity-40"
        >
          reject
        </button>
        {status === "needs_review" && (
          <>
            <span className="text-zinc-800">·</span>
            <button
              onClick={() => transition("pending")}
              disabled={isPending}
              className="text-xs font-mono text-zinc-600 hover:text-zinc-400 transition-colors disabled:opacity-40"
            >
              reset
            </button>
          </>
        )}
      </div>
      {error && <p className="text-xs font-mono text-red-500">{error}</p>}
    </div>
  );
}
