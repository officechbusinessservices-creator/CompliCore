"use client";

import { useState } from "react";

function NoScreenshot({ reason }: { reason: string }) {
  return (
    <div className="h-20 bg-zinc-900 border border-dashed border-zinc-800 rounded flex items-center justify-center">
      <span className="text-xs font-mono text-zinc-600">{reason}</span>
    </div>
  );
}

export function Screenshot({ src }: { src: string | null }) {
  const [failed, setFailed] = useState(false);

  if (src == null || src.length === 0) {
    return <NoScreenshot reason="No screenshot available" />;
  }

  if (failed) {
    return <NoScreenshot reason="Screenshot could not be loaded" />;
  }

  return (
    <img
      src={src}
      alt="Evidence screenshot"
      className="rounded border border-zinc-800 max-w-full"
      onError={() => setFailed(true)}
    />
  );
}
