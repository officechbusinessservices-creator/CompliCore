import type { ReactNode } from "react";

type BadgeVariant = "high" | "medium" | "low" | "approved" | "pending" | "needs_review" | "rejected" | "fail" | "warn" | "strong" | "moderate" | "weak" | "neutral";

const VARIANT_CLASSES: Record<BadgeVariant, string> = {
  high:         "bg-red-950 text-red-400 border border-red-800",
  medium:       "bg-amber-950 text-amber-400 border border-amber-800",
  low:          "bg-zinc-800 text-zinc-400 border border-zinc-700",
  approved:     "bg-emerald-950 text-emerald-400 border border-emerald-800",
  pending:      "bg-zinc-800 text-zinc-400 border border-zinc-700",
  needs_review: "bg-amber-950 text-amber-400 border border-amber-800",
  rejected:     "bg-red-950 text-red-500 border border-red-800",
  fail:         "bg-red-950 text-red-400 border border-red-800",
  warn:         "bg-amber-950 text-amber-400 border border-amber-800",
  strong:       "bg-red-950 text-red-400 border border-red-800",
  moderate:     "bg-amber-950 text-amber-400 border border-amber-800",
  weak:         "bg-zinc-800 text-zinc-400 border border-zinc-700",
  neutral:      "bg-zinc-800 text-zinc-400 border border-zinc-700",
};

export function Badge({ variant, children }: { variant: BadgeVariant; children: ReactNode }) {
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-mono font-medium ${VARIANT_CLASSES[variant]}`}>
      {children}
    </span>
  );
}

export function ReviewerBadge({ status }: { status: string }) {
  const v = status as BadgeVariant;
  const label: Record<string, string> = {
    approved: "approved",
    pending: "pending",
    needs_review: "needs review",
    rejected: "rejected",
  };
  return <Badge variant={v}>{label[status] ?? status}</Badge>;
}

export function SeverityBadge({ severity }: { severity: string }) {
  return <Badge variant={severity as BadgeVariant}>{severity}</Badge>;
}

export function TierBadge({ tier }: { tier: string }) {
  const map: Record<string, BadgeVariant> = { HIGH: "high", MODERATE: "moderate", LOW: "low" };
  return <Badge variant={map[tier] ?? "neutral"}>{tier}</Badge>;
}

export function SignalBadge({ signal }: { signal: string }) {
  const map: Record<string, BadgeVariant> = { strong: "strong", moderate: "moderate", weak: "weak" };
  return <Badge variant={map[signal] ?? "neutral"}>{signal}</Badge>;
}

export function ConfidenceBadge({ confidence }: { confidence: string }) {
  const map: Record<string, BadgeVariant> = { high: "approved", medium: "moderate", low: "warn" };
  return <Badge variant={map[confidence] ?? "neutral"}>{confidence}</Badge>;
}

export function ScoreBar({ score }: { score: number }) {
  const color = score >= 70 ? "bg-red-500" : score >= 40 ? "bg-amber-500" : "bg-zinc-500";
  return (
    <div className="flex items-center gap-2">
      <div className="w-20 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${score}%` }} />
      </div>
      <span className="text-xs font-mono text-zinc-300">{score}</span>
    </div>
  );
}
