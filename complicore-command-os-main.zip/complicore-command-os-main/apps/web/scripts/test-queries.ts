/**
 * Smoke test for apps/web/lib/queries.ts
 *
 * Exercises every exported query against real DB data.
 * Requires a run to exist — seed with:
 *   pnpm --filter @complicore/worker pipeline
 *
 * Usage:
 *   pnpm --filter @complicore/web queries:test
 */

import {
  getLatestRun,
  getLatestRuns,
  getRunById,
  getOverviewMetrics,
  getStepsByRun,
  getFindingsByRun,
  getFindingById,
  getFindingDetail,
  getFindingCountsByDomainId,
  getEvidenceBundleForFinding,
  getTargetsByRun,
  getTargetById,
  getTargetDetail,
  getDomainsByRun,
  getReportsByRun,
  getReportById,
  getReportDetail,
  getAuditEventsByRun,
} from "../lib/queries.js";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function section(label: string) {
  console.log(`\n${"─".repeat(60)}`);
  console.log(`  ${label}`);
  console.log("─".repeat(60));
}

function dump(label: string, value: unknown) {
  const json = JSON.stringify(value, null, 2);
  const out = json.length > 800 ? json.slice(0, 800) + "\n  …[truncated]" : json;
  console.log(`\n[${label}]\n${out}`);
}

function assert(cond: boolean, msg: string) {
  if (!cond) throw new Error(`ASSERTION FAILED: ${msg}`);
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  // ── 1. Latest runs ──────────────────────────────────────────────────────────
  section("1  getLatestRun / getLatestRuns");

  const latest = await getLatestRun();
  dump("getLatestRun()", latest != null ? { id: latest.id, status: latest.status, metro: latest.metro } : null);

  const latestN = await getLatestRuns(3);
  dump("getLatestRuns(3)", latestN.map((r) => ({ id: r.id, status: r.status, created_at: r.created_at })));

  if (latest == null) {
    console.log("\nNo runs in DB. Run `pnpm --filter @complicore/worker pipeline` first.");
    process.exit(0);
  }
  const runId = latest.id;

  // ── 2. getRunById ───────────────────────────────────────────────────────────
  section("2  getRunById");

  const byId = await getRunById(runId);
  assert(byId?.id === runId, "getRunById should return the same run");
  dump(`getRunById(${runId.slice(0, 8)}…)`, byId);

  // ── 3. Overview metrics ─────────────────────────────────────────────────────
  section("3  getOverviewMetrics");

  const metrics = await getOverviewMetrics(runId);
  assert(metrics != null, "getOverviewMetrics should return a result");
  dump("getOverviewMetrics(runId)", metrics);

  // ── 4. Steps ────────────────────────────────────────────────────────────────
  section("4  getStepsByRun");

  const stepsResult = await getStepsByRun(runId);
  dump(`getStepsByRun → ${stepsResult.length} steps`, stepsResult.map((s) => ({ name: s.name, status: s.status, input_count: s.input_count, output_count: s.output_count })));

  // ── 5. Domains ──────────────────────────────────────────────────────────────
  section("5  getDomainsByRun");

  const domains = await getDomainsByRun(runId);
  dump(`getDomainsByRun → ${domains.length} domains`, domains.map((d) => ({ id: d.id, domain: d.domain, status: d.status })));

  // ── 6. Findings list ────────────────────────────────────────────────────────
  section("6  getFindingsByRun / getFindingCountsByDomainId");

  const findings = await getFindingsByRun(runId);
  dump(
    `getFindingsByRun → ${findings.length} findings (first 2)`,
    findings.slice(0, 2).map((f) => ({
      id: f.id,
      rule_family: f.rule_family,
      severity: f.severity,
      reviewer_status: f.reviewer_status,
      confidence: f.confidence,
      source_url: f.source_url,
    }))
  );

  const countsByDomain = await getFindingCountsByDomainId(runId);
  dump("getFindingCountsByDomainId", Object.fromEntries(countsByDomain));

  // ── 7. Finding detail ───────────────────────────────────────────────────────
  const firstFinding = findings[0];
  if (firstFinding != null) {
    section("7  getFindingById / getFindingDetail");

    const findingById = await getFindingById(firstFinding.id);
    assert(findingById?.id === firstFinding.id, "getFindingById id match");
    dump(`getFindingById(${firstFinding.id.slice(0, 8)}…)`, findingById);

    const detail = await getFindingDetail(firstFinding.id);
    assert(detail != null, "getFindingDetail should return a result");
    if (detail != null) {
      dump("getFindingDetail — core fields", {
        id: detail.id,
        rule_name: detail.rule_name,
        severity: detail.severity,
        reviewer_status: detail.reviewer_status,
        confidence: detail.confidence,
        source_url: detail.source_url,
        snippet: detail.snippet.slice(0, 100),
        screenshot_ref: detail.screenshot_ref,
        run_id: detail.run_id,
        report_id: detail.report_id,
      });
      dump("getFindingDetail — source_page", detail.source_page != null
        ? { id: detail.source_page.id, url: detail.source_page.url, word_count: detail.source_page.word_count }
        : null);
      dump(`getFindingDetail — content_gaps_on_page (${detail.content_gaps_on_page.length})`,
        detail.content_gaps_on_page);
    }

    // ── 8. Evidence bundle ──────────────────────────────────────────────────
    section("8  getEvidenceBundleForFinding");

    const bundle = await getEvidenceBundleForFinding(firstFinding.id);
    assert(bundle != null, "getEvidenceBundleForFinding should return a result");
    if (bundle != null) {
      dump("bundle.finding.id", bundle.finding.id);
      dump("bundle.source_page", { id: bundle.source_page.id, url: bundle.source_page.url, word_count: bundle.source_page.word_count });
      dump(`bundle.content_gaps_on_page (${bundle.content_gaps_on_page.length})`, bundle.content_gaps_on_page);
    }
  } else {
    console.log("\n  [skip] No findings in this run.");
  }

  // ── 9. Reports ──────────────────────────────────────────────────────────────
  section("9  getReportsByRun / getReportById / getReportDetail");

  const reports = await getReportsByRun(runId);
  dump(`getReportsByRun → ${reports.length} reports`, reports.map((r) => ({ id: r.id, type: r.type, status: r.status })));

  const firstReport = reports[0];
  if (firstReport != null) {
    const reportById = await getReportById(firstReport.id);
    assert(reportById?.id === firstReport.id, "getReportById id match");
    dump(`getReportById(${firstReport.id.slice(0, 8)}…)`, reportById);

    const reportDetail = await getReportDetail(firstReport.id);
    assert(reportDetail != null, "getReportDetail should return a result");
    dump("getReportDetail — summary", reportDetail != null ? {
      id: reportDetail.id,
      type: reportDetail.type,
      status: reportDetail.status,
      metro: reportDetail.metro,
      finding_count: reportDetail.findings.length,
      target_count: reportDetail.target_count,
      brief_count: reportDetail.briefs.length,
    } : null);
    dump(`getReportDetail — briefs (${reportDetail?.briefs.length ?? 0})`,
      reportDetail?.briefs.map((b) => ({
        id: b.id,
        opportunity_target_id: b.opportunity_target_id,
        status: b.status,
        reviewer_status: b.reviewer_status,
        content_preview: b.content.slice(0, 120),
      })) ?? []);
  } else {
    console.log("\n  [skip] No reports in this run.");
  }

  // ── 10. Targets ─────────────────────────────────────────────────────────────
  section("10  getTargetsByRun / getTargetById / getTargetDetail");

  const targets = await getTargetsByRun(runId);
  dump(`getTargetsByRun → ${targets.length} targets`, targets.map((t) => ({ id: t.id, score: t.score, signal_tier: t.signal_tier })));

  const firstTarget = targets[0];
  if (firstTarget != null) {
    const targetById = await getTargetById(firstTarget.id);
    assert(targetById?.id === firstTarget.id, "getTargetById id match");
    dump(`getTargetById(${firstTarget.id.slice(0, 8)}…)`, targetById != null ? {
      id: targetById.id,
      score: targetById.score,
      signal_tier: targetById.signal_tier,
      contributing_gap_ids: targetById.contributing_gap_ids,
    } : null);

    const targetDetail = await getTargetDetail(firstTarget.id);
    assert(targetDetail != null, "getTargetDetail should return a result");
    if (targetDetail != null) {
      dump("getTargetDetail — summary", {
        id: targetDetail.id,
        score: targetDetail.score,
        signal_tier: targetDetail.signal_tier,
        domain: targetDetail.domain.domain,
        contributing_gap_ids: targetDetail.contributing_gap_ids,
        contributing_gaps_resolved: targetDetail.contributing_gaps.length,
        contributing_findings_resolved: targetDetail.contributing_findings.length,
        top_signals: targetDetail.top_signals,
        recommendation: targetDetail.recommendation.slice(0, 120),
      });
      dump("getTargetDetail — contributing_gaps", targetDetail.contributing_gaps);
    }
  } else {
    console.log("\n  [skip] No targets in this run.");
  }

  // ── 11. Audit events ─────────────────────────────────────────────────────────
  section("11  getAuditEventsByRun");

  const events = await getAuditEventsByRun(runId);
  dump(`getAuditEventsByRun → ${events.length} events (first 4)`,
    events.slice(0, 4).map((e) => ({ action: e.action, entity_type: e.entity_type, entity_id: e.entity_id.slice(0, 8), created_at: e.created_at })));

  console.log("\n✓  All 18 query paths exercised.\n");
}

main().catch((err) => {
  console.error("\n✗  test-queries failed:", err);
  process.exit(1);
});
