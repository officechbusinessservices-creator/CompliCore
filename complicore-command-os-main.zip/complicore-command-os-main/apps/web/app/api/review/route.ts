/**
 * POST /api/review
 *
 * Persists a reviewer status change to the DB and appends an audit event.
 * No auth layer yet — actor_id is fixed to "reviewer-dev" until auth is wired.
 *
 * Body: { collection, id, status, reviewer_note? }
 * Rules:
 *   - allowed statuses: pending | needs_review | approved | rejected
 *   - rejection requires a non-empty reviewer_note
 *   - state transitions enforced server-side (see ALLOWED_TRANSITIONS)
 */

import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@complicore/core/db/client";
import {
  findFindingById,
  setFindingReviewerStatus,
  findRunById,
  insertAuditEvent,
} from "@complicore/core/db";
import {
  findTargetById,
  setTargetReviewerStatus,
} from "@complicore/core/db/repos/opportunity-targets";
import { findOutboundBriefById } from "@complicore/core/db";
import { eq } from "drizzle-orm";
import { outboundBriefs } from "@complicore/core/db/schema";

type ReviewStatus = "pending" | "needs_review" | "approved" | "rejected";
type Collection = "findings" | "targets" | "briefs";

const VALID_STATUSES = new Set<ReviewStatus>(["pending", "needs_review", "approved", "rejected"]);

const ALLOWED_TRANSITIONS: Record<ReviewStatus, ReviewStatus[]> = {
  pending:      ["approved", "needs_review", "rejected"],
  needs_review: ["approved", "rejected", "pending"],
  approved:     ["pending"],
  rejected:     ["pending"],
};

function actionName(collection: Collection, status: ReviewStatus): string {
  const entity = collection === "findings" ? "finding" : collection === "targets" ? "target" : "brief";
  if (status === "pending") return `${entity}.reset`;
  return `${entity}.${status}`;
}

export async function POST(req: NextRequest) {
  const body = await req.json() as {
    collection?: unknown;
    id?: unknown;
    status?: unknown;
    reviewer_note?: unknown;
  };

  const { collection, id, status, reviewer_note } = body;

  if (
    (collection !== "findings" && collection !== "targets" && collection !== "briefs") ||
    typeof id !== "string" || id.length === 0 ||
    typeof status !== "string" || !VALID_STATUSES.has(status as ReviewStatus)
  ) {
    return NextResponse.json({ error: "invalid request body" }, { status: 400 });
  }

  const nextStatus = status as ReviewStatus;
  const note = typeof reviewer_note === "string" ? reviewer_note.trim() : "";

  if (nextStatus === "rejected" && note.length === 0) {
    return NextResponse.json({ error: "reviewer_note is required when rejecting" }, { status: 422 });
  }

  const db = getDb();

  // Load entity to get current status + run_id
  const entity =
    collection === "findings"
      ? await findFindingById(db, id)
      : collection === "targets"
        ? await findTargetById(db, id)
        : await findOutboundBriefById(db, id);

  if (entity == null) {
    return NextResponse.json({ error: "not found" }, { status: 404 });
  }

  const currentStatus = entity.reviewer_status as ReviewStatus;

  if (!ALLOWED_TRANSITIONS[currentStatus].includes(nextStatus)) {
    return NextResponse.json(
      { error: `transition ${currentStatus} → ${nextStatus} is not allowed` },
      { status: 422 },
    );
  }

  // Look up run for workspace_id
  const run = await findRunById(db, entity.run_id);
  if (run == null) {
    return NextResponse.json({ error: "run not found" }, { status: 500 });
  }

  // Persist status change
  if (collection === "findings") {
    await setFindingReviewerStatus(db, id, nextStatus);
  } else if (collection === "targets") {
    await setTargetReviewerStatus(db, id, nextStatus);
  } else {
    await db
      .update(outboundBriefs)
      .set({
        reviewer_status: nextStatus,
        ...(nextStatus === "approved" ? { approved_at: new Date(), status: "approved" } : {}),
        ...(nextStatus === "pending" ? { approved_at: null, status: "draft" } : {}),
      })
      .where(eq(outboundBriefs.id, id));
  }

  // Append audit event
  const payload: Record<string, unknown> = { from: currentStatus, to: nextStatus };
  if (note.length > 0) payload.note = note;

  const entityType =
    collection === "findings" ? "compliance_finding" :
    collection === "targets"  ? "opportunity_target" : "outbound_brief";

  await insertAuditEvent(db, {
    workspace_id: run.workspace_id,
    run_id: run.id,
    actor: "reviewer",
    actor_id: "reviewer-dev",
    action: actionName(collection as Collection, nextStatus),
    entity_type: entityType,
    entity_id: id,
    payload,
  });

  return NextResponse.json({ ok: true, reviewer_status: nextStatus });
}
