/**
 * GET /api/findings
 *
 * Returns compliance findings for a run.
 *
 * Query params:
 *   run_id      — specific run (omit to use the latest run)
 *   severity    — filter: high | medium | low
 *   reviewer_status — filter: pending | needs_review | approved | rejected
 *
 * Response:
 *   200 { run_id, findings: ComplianceFinding[] }
 *   404 { error: "no runs found" }
 */

import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@complicore/core/db/client";
import { getLatestRun, getRunById } from "@/lib/queries";
import { listFindingsByRun } from "@complicore/core/db";
import type { ComplianceFinding } from "@complicore/core/types";

type ReviewerStatus = ComplianceFinding["reviewer_status"];
type Severity = ComplianceFinding["severity"];

const VALID_SEVERITIES = new Set(["high", "medium", "low"]);
const VALID_STATUSES = new Set(["pending", "needs_review", "approved", "rejected"]);

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl;
  const runIdParam = searchParams.get("run_id");
  const severityParam = searchParams.get("severity");
  const statusParam = searchParams.get("reviewer_status");

  // Resolve run
  const run = runIdParam
    ? await getRunById(runIdParam)
    : await getLatestRun();

  if (run == null) {
    return NextResponse.json(
      { error: runIdParam ? "run not found" : "no runs found" },
      { status: 404 }
    );
  }

  const filter: { severity?: Severity; reviewer_status?: ReviewerStatus } = {};
  if (severityParam != null && VALID_SEVERITIES.has(severityParam)) {
    filter.severity = severityParam as Severity;
  }
  if (statusParam != null && VALID_STATUSES.has(statusParam)) {
    filter.reviewer_status = statusParam as ReviewerStatus;
  }

  const findings = await listFindingsByRun(getDb(), run.id, filter);

  return NextResponse.json({ run_id: run.id, findings });
}
