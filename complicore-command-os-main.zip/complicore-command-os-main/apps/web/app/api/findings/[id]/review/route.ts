/**
 * PATCH /api/findings/:id/review
 *
 * Updates the reviewer_status of a single finding and appends an audit event.
 * Enforces allowed state transitions. Rejection requires a note.
 *
 * Body:
 *   status        — pending | needs_review | approved | rejected
 *   note          — required when status is "rejected"
 *
 * Response:
 *   200 { ok: true, id, reviewer_status }
 *   400 invalid body
 *   404 finding not found
 *   422 invalid transition | rejection missing note
 */

import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@complicore/core/db/client";
import {
  findFindingById,
  setFindingReviewerStatus,
  findRunById,
  insertAuditEvent,
} from "@complicore/core/db";

type ReviewerStatus = "pending" | "needs_review" | "approved" | "rejected";

const VALID = new Set<ReviewerStatus>(["pending", "needs_review", "approved", "rejected"]);

const TRANSITIONS: Record<ReviewerStatus, ReviewerStatus[]> = {
  pending:      ["approved", "needs_review", "rejected"],
  needs_review: ["approved", "rejected", "pending"],
  approved:     ["pending"],
  rejected:     ["pending"],
};

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json().catch(() => null) as {
    status?: unknown;
    note?: unknown;
  } | null;

  if (body == null || typeof body.status !== "string" || !VALID.has(body.status as ReviewerStatus)) {
    return NextResponse.json({ error: "invalid body — status required" }, { status: 400 });
  }

  const next = body.status as ReviewerStatus;
  const note = typeof body.note === "string" ? body.note.trim() : "";

  if (next === "rejected" && note.length === 0) {
    return NextResponse.json({ error: "note is required when rejecting" }, { status: 422 });
  }

  const db = getDb();
  const finding = await findFindingById(db, id);
  if (finding == null) {
    return NextResponse.json({ error: "finding not found" }, { status: 404 });
  }

  const current = finding.reviewer_status as ReviewerStatus;
  if (!TRANSITIONS[current].includes(next)) {
    return NextResponse.json(
      { error: `transition ${current} → ${next} is not allowed` },
      { status: 422 }
    );
  }

  const run = await findRunById(db, finding.run_id);
  if (run == null) {
    return NextResponse.json({ error: "run not found" }, { status: 500 });
  }

  await setFindingReviewerStatus(db, id, next);

  const payload: Record<string, unknown> = { from: current, to: next };
  if (note.length > 0) payload.note = note;

  await insertAuditEvent(db, {
    workspace_id: run.workspace_id,
    run_id: run.id,
    actor: "reviewer",
    actor_id: "reviewer-dev",
    action: next === "pending" ? "finding.reset" : `finding.${next}`,
    entity_type: "compliance_finding",
    entity_id: id,
    payload,
  });

  return NextResponse.json({ ok: true, id, reviewer_status: next });
}
