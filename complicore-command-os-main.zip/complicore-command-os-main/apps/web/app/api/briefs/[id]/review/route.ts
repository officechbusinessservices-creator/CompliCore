/**
 * PATCH /api/briefs/:id/review
 *
 * Updates the reviewer_status of a single outbound brief.
 * Rejection requires a note. Approved briefs are eligible for send.
 *
 * Body:
 *   status  — pending | needs_review | approved | rejected
 *   note    — required when status is "rejected"
 *
 * Response:
 *   200 { ok: true, id, reviewer_status }
 *   400 invalid body
 *   404 brief not found
 *   422 invalid transition | rejection missing note
 */

import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@complicore/core/db/client";
import { eq } from "drizzle-orm";
import { outboundBriefs } from "@complicore/core/db/schema";
import { findOutboundBriefById, insertAuditEvent, findRunById } from "@complicore/core/db";

type ReviewerStatus = "pending" | "needs_review" | "approved" | "rejected";

const VALID = new Set<ReviewerStatus>(["pending", "needs_review", "approved", "rejected"]);

const TRANSITIONS: Record<ReviewerStatus, ReviewerStatus[]> = {
  pending:      ["approved", "needs_review", "rejected"],
  needs_review: ["approved", "rejected", "pending"],
  approved:     ["pending"],
  rejected:     ["pending"],
};

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json().catch(() => null) as {
    status?: unknown;
    note?: unknown;
  } | null;

  if (body == null || typeof body.status !== "string" || !VALID.has(body.status as ReviewerStatus)) {
    return NextResponse.json({ error: "invalid body — status required" }, { status: 400 });
  }

  const next = body.status as ReviewerStatus;
  const note = typeof body.note === "string" ? body.note.trim() : "";

  if (next === "rejected" && note.length === 0) {
    return NextResponse.json({ error: "note is required when rejecting" }, { status: 422 });
  }

  const db = getDb();
  const brief = await findOutboundBriefById(db, id);
  if (brief == null) {
    return NextResponse.json({ error: "brief not found" }, { status: 404 });
  }

  const current = brief.reviewer_status as ReviewerStatus;
  if (!TRANSITIONS[current].includes(next)) {
    return NextResponse.json(
      { error: `transition ${current} → ${next} is not allowed` },
      { status: 422 }
    );
  }

  const approved_at = next === "approved" ? new Date() : null;

  await db
    .update(outboundBriefs)
    .set({
      reviewer_status: next,
      ...(approved_at != null ? { approved_at, status: "approved" } : {}),
      ...(next === "pending" ? { approved_at: null, status: "draft" } : {}),
    })
    .where(eq(outboundBriefs.id, id));

  const run = await findRunById(db, brief.run_id);
  if (run != null) {
    const payload: Record<string, unknown> = { from: current, to: next };
    if (note.length > 0) payload.note = note;

    await insertAuditEvent(db, {
      workspace_id: run.workspace_id,
      run_id: run.id,
      actor: "reviewer",
      actor_id: "reviewer-dev",
      action: next === "pending" ? "brief.reset" : `brief.${next}`,
      entity_type: "outbound_brief",
      entity_id: id,
      payload,
    });
  }

  return NextResponse.json({ ok: true, id, reviewer_status: next });
}
