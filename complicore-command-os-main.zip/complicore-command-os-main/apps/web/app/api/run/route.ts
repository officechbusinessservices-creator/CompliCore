/**
 * POST /api/run
 *
 * Triggers a pipeline run for a metro. Fire-and-forget — the worker
 * runs as a background process. Returns immediately with the run slug
 * so the caller can poll /api/reports or watch the dashboard.
 *
 * Body (all optional):
 *   metro           — defaults to "Austin, TX"
 *   operator_domain — defaults to "mycompany.com"
 *
 * Response:
 *   202 { ok: true, message, metro, operator_domain }
 *
 * The worker process inherits DATABASE_URL and FIRECRAWL_API_KEY from env.
 * If FIRECRAWL_API_KEY is absent, the mock client is used automatically.
 */

import { NextRequest, NextResponse } from "next/server";
import { spawn } from "node:child_process";
import { resolve } from "node:path";

const WORKER_DIR = resolve(process.cwd(), "../../apps/worker");

export async function POST(req: NextRequest) {
  let body: { metro?: unknown; operator_domain?: unknown } = {};
  try {
    body = await req.json();
  } catch {
    // empty body is fine — all fields have defaults
  }

  const metro =
    typeof body.metro === "string" && body.metro.trim().length > 0
      ? body.metro.trim()
      : "Austin, TX";

  const operatorDomain =
    typeof body.operator_domain === "string" && body.operator_domain.trim().length > 0
      ? body.operator_domain.trim()
      : "mycompany.com";

  // Spawn worker — inherits DB + API key env vars from the web process.
  // stdio: "ignore" so the HTTP response is not blocked.
  const child = spawn(
    "node",
    ["--import", "tsx/esm", "src/run.ts"],
    {
      cwd: WORKER_DIR,
      env: {
        ...process.env,
        METRO: metro,
        OPERATOR_DOMAIN: operatorDomain,
      },
      detached: true,
      stdio: "ignore",
    }
  );
  child.unref();

  return NextResponse.json(
    {
      ok: true,
      message: "Pipeline started. Poll /api/reports for results.",
      metro,
      operator_domain: operatorDomain,
    },
    { status: 202 }
  );
}
