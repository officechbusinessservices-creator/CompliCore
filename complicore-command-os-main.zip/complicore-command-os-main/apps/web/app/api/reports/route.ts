/**
 * GET /api/reports
 *
 * Returns reports for a run.
 *
 * Query params:
 *   run_id — specific run (omit to use the latest run)
 *
 * Response:
 *   200 { run_id, reports: Report[] }
 *   404 { error: "no runs found" | "run not found" }
 */

import { NextRequest, NextResponse } from "next/server";
import { getLatestRun, getRunById, getReportsByRun } from "@/lib/queries";

export async function GET(req: NextRequest) {
  const runIdParam = req.nextUrl.searchParams.get("run_id");

  const run = runIdParam
    ? await getRunById(runIdParam)
    : await getLatestRun();

  if (run == null) {
    return NextResponse.json(
      { error: runIdParam ? "run not found" : "no runs found" },
      { status: 404 }
    );
  }

  const reports = await getReportsByRun(run.id);

  return NextResponse.json({ run_id: run.id, reports });
}
