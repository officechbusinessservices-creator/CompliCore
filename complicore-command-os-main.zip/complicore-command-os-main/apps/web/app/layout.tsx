import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";
import { getLatestRun } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "CompliCore Command OS",
  description: "Compliance-first market intelligence for corporate housing operators.",
};

const NAV = [
  { href: "/",            label: "Overview",          icon: "◈" },
  { href: "/market",      label: "Market Monitor",    icon: "◉" },
  { href: "/compliance",  label: "Compliance",        icon: "⚑" },
  { href: "/growth",      label: "Growth Intel",      icon: "↗" },
  { href: "/acquisition", label: "Acquisition",       icon: "◎" },
  { href: "/reports",     label: "Reports",           icon: "▤" },
  { href: "/evidence",    label: "Evidence Viewer",   icon: "◧" },
  { href: "/audit",       label: "Audit Log",          icon: "◌" },
];

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const run = await getLatestRun();
  const runDate = run?.created_at
    ? new Date(run.created_at).toLocaleDateString("en-US", { month: "short", day: "numeric" })
    : null;

  const statusDot =
    run?.status === "completed" ? "bg-emerald-400" :
    run?.status === "running" ? "bg-amber-400 animate-pulse" :
    "bg-zinc-600";

  return (
    <html lang="en" className="dark">
      <body className="flex h-screen overflow-hidden font-sans antialiased">
        {/* Sidebar */}
        <aside className="w-56 flex-shrink-0 flex flex-col bg-zinc-950 border-r border-zinc-800">
          {/* Wordmark */}
          <div className="px-4 pt-5 pb-4 border-b border-zinc-800">
            <div className="text-xs font-mono font-semibold text-zinc-400 uppercase tracking-widest">CompliCore</div>
            <div className="text-xs font-mono text-zinc-600 mt-0.5">Command OS · v1</div>
          </div>

          {/* Run status pill */}
          <div className="px-4 py-3 border-b border-zinc-800">
            {run ? (
              <>
                <div className="flex items-center gap-2">
                  <span className={`w-1.5 h-1.5 rounded-full ${statusDot}`} />
                  <span className="text-xs font-mono text-zinc-400">Last run: {runDate}</span>
                </div>
                <div className="text-xs font-mono text-zinc-600 mt-0.5 pl-3.5">{run.metro} · {run.status}</div>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-zinc-700" />
                <span className="text-xs font-mono text-zinc-600">No runs yet</span>
              </div>
            )}
          </div>

          {/* Nav */}
          <nav className="flex-1 py-3 overflow-y-auto">
            {NAV.map(({ href, label, icon }) => (
              <Link
                key={href}
                href={href}
                className="flex items-center gap-3 px-4 py-2 text-sm text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900 transition-colors"
              >
                <span className="font-mono text-zinc-600 w-4 text-center">{icon}</span>
                {label}
              </Link>
            ))}
          </nav>

          {/* Footer */}
          <div className="px-4 py-3 border-t border-zinc-800">
            <div className="text-xs font-mono text-zinc-700">
              {run ? `run ${run.id.slice(0, 8)}` : "no pipeline run"}
            </div>
          </div>
        </aside>

        {/* Main content */}
        <main className="flex-1 overflow-y-auto bg-zinc-950">
          {children}
        </main>
      </body>
    </html>
  );
}
