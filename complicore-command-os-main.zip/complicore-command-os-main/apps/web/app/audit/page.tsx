import { getLatestRun, getAuditEventsByRun } from "@/lib/queries";

function fmt(iso: string) {
  return new Date(iso).toLocaleString("en-US", {
    month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit",
  });
}

const ACTION_COLOR: Record<string, string> = {
  "finding.approved":     "text-emerald-400",
  "finding.rejected":     "text-red-400",
  "finding.needs_review": "text-amber-400",
  "finding.reset":        "text-zinc-400",
  "target.approved":      "text-emerald-400",
  "target.rejected":      "text-red-400",
  "target.needs_review":  "text-amber-400",
  "target.reset":         "text-zinc-400",
};

export default async function AuditLogPage() {
  const run = await getLatestRun();
  if (!run) {
    return (
      <div className="p-8 max-w-4xl">
        <h1 className="text-lg font-mono font-semibold text-zinc-100 mb-3">Audit Log</h1>
        <p className="text-sm font-mono text-zinc-600">No runs found.</p>
      </div>
    );
  }

  const events = await getAuditEventsByRun(run.id);

  return (
    <div className="p-8 max-w-4xl">
      <div className="mb-6">
        <h1 className="text-lg font-mono font-semibold text-zinc-100">Audit Log</h1>
        <p className="text-sm font-mono text-zinc-500 mt-1">
          {events.length} events · Run {run.id} · most recent first
        </p>
      </div>

      {events.length === 0 ? (
        <p className="text-sm font-mono text-zinc-600">No audit events for this run yet.</p>
      ) : (
        <div className="bg-zinc-900 border border-zinc-800 rounded overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-zinc-800">
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Time</th>
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Action</th>
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Entity</th>
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Actor</th>
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">From → To</th>
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Note</th>
              </tr>
            </thead>
            <tbody>
              {events.map((e) => {
                const p = e.payload as Record<string, string>;
                return (
                  <tr key={e.id} className="border-b border-zinc-800/50 last:border-0 hover:bg-zinc-800/30">
                    <td className="px-4 py-2.5 font-mono text-xs text-zinc-500 whitespace-nowrap">{fmt(e.created_at)}</td>
                    <td className="px-4 py-2.5">
                      <span className={`font-mono text-xs ${ACTION_COLOR[e.action] ?? "text-zinc-400"}`}>{e.action}</span>
                    </td>
                    <td className="px-4 py-2.5 font-mono text-xs text-zinc-500 max-w-[140px] truncate" title={e.entity_id}>
                      <span className="text-zinc-600">{e.entity_type.replace("compliance_", "").replace("opportunity_", "")} </span>
                      {e.entity_id.slice(0, 8)}
                    </td>
                    <td className="px-4 py-2.5 font-mono text-xs text-zinc-500">{e.actor_id ?? e.actor}</td>
                    <td className="px-4 py-2.5 font-mono text-xs text-zinc-500">
                      {p.from && p.to ? <span>{p.from} → {p.to}</span> : "—"}
                    </td>
                    <td className="px-4 py-2.5 font-mono text-xs text-zinc-400 max-w-[200px] truncate">
                      {p.note ?? "—"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <p className="mt-3 text-xs font-mono text-zinc-700">
        Append-only · all reviewer decisions are logged here with before/after state
      </p>
    </div>
  );
}
