import Link from "next/link";
import { notFound } from "next/navigation";
import { getReportDetail, getDomainsByRun } from "@/lib/queries";
import { SeverityBadge, ReviewerBadge, ConfidenceBadge, Badge } from "@/components/badges";

const TYPE_LABEL: Record<string, string> = {
  weekly_brief: "Weekly Executive Brief",
  compliance_log: "Compliance Findings Log",
  growth_brief: "Growth Intelligence Brief",
  acquisition_list: "Acquisition Target List",
};

function fmt(iso: string | null) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("en-US", {
    month: "short", day: "numeric", hour: "2-digit", minute: "2-digit",
  });
}

export default async function ReportDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const report = await getReportDetail(id);
  if (!report) notFound();

  const domains = await getDomainsByRun(report.run_id);
  const domainMap = new Map(domains.map((d) => [d.id, d.domain]));

  const high = report.findings.filter((f) => f.severity === "high").length;
  const approved = report.findings.filter((f) => f.reviewer_status === "approved").length;
  const needsReview = report.findings.filter((f) => f.reviewer_status === "needs_review").length;

  return (
    <div className="p-8 max-w-4xl">
      <div className="flex items-center gap-2 text-xs font-mono text-zinc-600 mb-6">
        <Link href="/reports" className="hover:text-zinc-400">Reports</Link>
        <span>/</span>
        <span className="text-zinc-500 truncate max-w-xs">{id}</span>
      </div>

      <div className="mb-6">
        <h1 className="text-lg font-mono font-semibold text-zinc-100">{TYPE_LABEL[report.type] ?? report.type}</h1>
        <p className="text-xs font-mono text-zinc-600 mt-1">{id}</p>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Metro</div>
          <span className="text-sm font-mono text-zinc-200">{report.metro}</span>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Status</div>
          <Badge variant={report.status === "approved" || report.status === "exported" ? "approved" : "pending"}>
            {report.status}
          </Badge>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Generated</div>
          <span className="text-xs font-mono text-zinc-400">{fmt(report.generated_at)}</span>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Approved</div>
          <span className="text-xs font-mono text-zinc-400">{fmt(report.approved_at)}</span>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Exported</div>
          <span className="text-xs font-mono text-zinc-400">{fmt(report.exported_at)}</span>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Run</div>
          <span className="text-xs font-mono text-zinc-500">{report.run_id}</span>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-3 mb-6">
        {[
          { label: "Total Findings", value: report.findings.length },
          { label: "High Severity", value: high },
          { label: "Approved", value: approved },
          { label: "Needs Review", value: needsReview },
        ].map(({ label, value }) => (
          <div key={label} className="bg-zinc-900 border border-zinc-800 rounded p-3">
            <div className="text-xs font-mono text-zinc-600">{label}</div>
            <div className="text-xl font-mono font-bold text-zinc-200 mt-0.5">{value}</div>
          </div>
        ))}
      </div>

      {/* Outbound briefs */}
      {report.briefs.length > 0 && (
        <div className="mb-6">
          <div className="text-xs font-mono text-zinc-600 uppercase tracking-wider mb-3">
            Outbound Briefs ({report.briefs.length})
          </div>
          <div className="space-y-2">
            {report.briefs.map((b) => (
              <div key={b.id} className="bg-zinc-900 border border-zinc-800 rounded p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-mono text-zinc-600">{b.id}</span>
                  <div className="flex items-center gap-2">
                    <Badge variant={
                      b.reviewer_status === "approved" ? "approved" :
                      b.reviewer_status === "rejected" ? "rejected" : "pending"
                    }>
                      {b.reviewer_status}
                    </Badge>
                    <Badge variant="neutral">{b.status}</Badge>
                  </div>
                </div>
                <p className="text-xs text-zinc-400 line-clamp-3 leading-relaxed">{b.content}</p>
                <p className="mt-2 text-xs font-mono text-zinc-700">
                  target: {b.opportunity_target_id.slice(0, 8)}…
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Compliance findings for this run */}
      {report.findings.length === 0 ? (
        <p className="text-xs font-mono text-zinc-700">No findings for this run.</p>
      ) : (
        <div className="bg-zinc-900 border border-zinc-800 rounded overflow-hidden">
          <div className="px-4 py-2.5 border-b border-zinc-800 text-xs font-mono text-zinc-600">
            Compliance Findings
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-zinc-800">
                <th className="text-left px-4 py-2 text-xs font-mono text-zinc-600 font-normal">Domain</th>
                <th className="text-left px-4 py-2 text-xs font-mono text-zinc-600 font-normal">Rule Family</th>
                <th className="text-left px-4 py-2 text-xs font-mono text-zinc-600 font-normal">Sev</th>
                <th className="text-left px-4 py-2 text-xs font-mono text-zinc-600 font-normal">Result</th>
                <th className="text-left px-4 py-2 text-xs font-mono text-zinc-600 font-normal">Confidence</th>
                <th className="text-left px-4 py-2 text-xs font-mono text-zinc-600 font-normal">Status</th>
                <th className="px-4 py-2" />
              </tr>
            </thead>
            <tbody>
              {report.findings.map((f) => (
                <tr key={f.id} className="border-b border-zinc-800/50 last:border-0 hover:bg-zinc-800/30">
                  <td className="px-4 py-2.5 font-mono text-xs text-zinc-300">
                    {domainMap.get(f.domain_id) ?? f.domain_id}
                  </td>
                  <td className="px-4 py-2.5 font-mono text-xs text-zinc-500">
                    {f.rule_family.replace(/_/g, " ")}
                  </td>
                  <td className="px-4 py-2.5"><SeverityBadge severity={f.severity} /></td>
                  <td className="px-4 py-2.5">
                    <Badge variant={f.rule_result === "FAIL" ? "fail" : "warn"}>{f.rule_result}</Badge>
                  </td>
                  <td className="px-4 py-2.5"><ConfidenceBadge confidence={f.confidence} /></td>
                  <td className="px-4 py-2.5"><ReviewerBadge status={f.reviewer_status} /></td>
                  <td className="px-4 py-2.5">
                    <Link href={`/compliance/${f.id}`} className="text-xs font-mono text-zinc-600 hover:text-zinc-400">
                      detail →
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="mt-4">
        <Link href="/reports" className="text-xs font-mono text-zinc-600 hover:text-zinc-400">← Reports</Link>
      </div>
    </div>
  );
}
