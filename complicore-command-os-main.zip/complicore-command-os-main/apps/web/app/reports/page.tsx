import Link from "next/link";
import { getLatestRun, getReportsByRun } from "@/lib/queries";
import { Badge } from "@/components/badges";

const TYPE_LABEL: Record<string, string> = {
  weekly_brief: "Weekly Executive Brief",
  compliance_log: "Compliance Findings Log",
  growth_brief: "Growth Intelligence Brief",
  acquisition_list: "Acquisition Target List",
};

function fmt(iso: string | null) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export default async function ReportsPage() {
  const run = await getLatestRun();
  if (!run) {
    return (
      <div className="p-8 max-w-4xl">
        <h1 className="text-lg font-mono font-semibold text-zinc-100 mb-3">Reports</h1>
        <p className="text-sm font-mono text-zinc-600">No runs found. Start a pipeline run to see data here.</p>
      </div>
    );
  }

  const reports = await getReportsByRun(run.id);
  const approved = reports.filter((r) => r.status === "approved").length;
  const exported = reports.filter((r) => r.exported_at !== null).length;

  return (
    <div className="p-8 max-w-4xl">
      <div className="mb-6">
        <h1 className="text-lg font-mono font-semibold text-zinc-100">Reports</h1>
        <p className="text-sm font-mono text-zinc-500 mt-1">
          Run {run.id} · {run.metro} · {approved} approved · {exported} exported
        </p>
      </div>

      <div className="bg-zinc-900 border border-amber-900/50 rounded p-3 mb-6">
        <p className="text-xs font-mono text-amber-600">
          ▲ Approval required before export · no report may be exported with status "draft"
        </p>
      </div>

      {reports.length === 0 ? (
        <p className="text-sm font-mono text-zinc-600">No reports generated for this run.</p>
      ) : (
        <div className="bg-zinc-900 border border-zinc-800 rounded overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-zinc-800">
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Report</th>
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Metro</th>
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Status</th>
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Generated</th>
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Approved</th>
                <th className="px-4 py-2.5" />
              </tr>
            </thead>
            <tbody>
              {reports.map((r) => (
                <tr key={r.id} className="border-b border-zinc-800/50 last:border-0 hover:bg-zinc-800/30">
                  <td className="px-4 py-3 font-mono text-xs text-zinc-200">
                    <div>{TYPE_LABEL[r.type] ?? r.type}</div>
                    <div className="text-zinc-600 mt-0.5">{r.id}</div>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-zinc-400">{r.metro}</td>
                  <td className="px-4 py-3">
                    <Badge variant={r.status === "approved" ? "approved" : r.status === "exported" ? "approved" : "pending"}>
                      {r.status}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-zinc-500">{fmt(r.generated_at)}</td>
                  <td className="px-4 py-3 font-mono text-xs text-zinc-500">{fmt(r.approved_at)}</td>
                  <td className="px-4 py-3">
                    <Link href={`/reports/${r.id}`} className="text-xs font-mono text-zinc-600 hover:text-zinc-400 transition-colors">
                      view →
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <p className="mt-3 text-xs font-mono text-zinc-700">
        Export is disabled in v1 shell · approval gate enforced at the report record level
      </p>
    </div>
  );
}
