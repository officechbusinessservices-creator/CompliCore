import { getLatestRun, getFindingsByRun } from "@/lib/queries";
import { SignalBadge } from "@/components/badges";
import type { ComplianceFinding } from "@complicore/core/types";

type Gap = {
  rule_family: string;
  domain_count: number;
  finding_count: number;
  signal: "strong" | "moderate" | "weak";
};

function deriveGaps(findings: ComplianceFinding[]): Gap[] {
  const ruleDomains = new Map<string, Set<string>>();
  const ruleCounts = new Map<string, number>();
  for (const f of findings) {
    if (!ruleDomains.has(f.rule_family)) ruleDomains.set(f.rule_family, new Set());
    ruleDomains.get(f.rule_family)!.add(f.domain_id);
    ruleCounts.set(f.rule_family, (ruleCounts.get(f.rule_family) ?? 0) + 1);
  }
  return [...ruleDomains.entries()]
    .map(([rule_family, domains]) => ({
      rule_family,
      domain_count: domains.size,
      finding_count: ruleCounts.get(rule_family) ?? 0,
      signal: (domains.size >= 3 ? "strong" : domains.size >= 2 ? "moderate" : "weak") as Gap["signal"],
    }))
    .sort((a, b) => b.finding_count - a.finding_count);
}

export default async function GrowthIntelligencePage() {
  const run = await getLatestRun();
  if (!run) {
    return (
      <div className="p-8 max-w-5xl">
        <h1 className="text-lg font-mono font-semibold text-zinc-100 mb-3">Growth Intelligence</h1>
        <p className="text-sm font-mono text-zinc-600">No runs found. Start a pipeline run to see data here.</p>
      </div>
    );
  }

  const findings = await getFindingsByRun(run.id);
  const gaps = deriveGaps(findings);
  const strong = gaps.filter((g) => g.signal === "strong").length;
  const moderate = gaps.filter((g) => g.signal === "moderate").length;

  return (
    <div className="p-8 max-w-5xl">
      <div className="mb-6">
        <h1 className="text-lg font-mono font-semibold text-zinc-100">Growth Intelligence</h1>
        <p className="text-sm font-mono text-zinc-500 mt-1">
          {gaps.length} market gaps · {strong} strong signal · {run.metro}
        </p>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-6">
        {[
          { label: "Gaps Identified", value: gaps.length },
          { label: "Strong Signal", value: strong },
          { label: "Moderate Signal", value: moderate },
        ].map(({ label, value }) => (
          <div key={label} className="bg-zinc-900 border border-zinc-800 rounded p-3">
            <div className="text-xs font-mono text-zinc-600">{label}</div>
            <div className="text-xl font-mono font-bold text-zinc-200 mt-0.5">{value}</div>
          </div>
        ))}
      </div>

      {gaps.length === 0 ? (
        <p className="text-xs font-mono text-zinc-700">No growth gaps derived from this run.</p>
      ) : (
        <div className="space-y-3">
          {gaps.map((gap, i) => (
            <div key={gap.rule_family} className="bg-zinc-900 border border-zinc-800 rounded p-4">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-xs text-zinc-600">{String(i + 1).padStart(2, "0")}</span>
                  <span className="font-mono text-sm text-zinc-200">{gap.rule_family.replace(/_/g, " ")}</span>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <SignalBadge signal={gap.signal} />
                  <span className="text-xs font-mono text-zinc-500">
                    {gap.finding_count} findings · {gap.domain_count} domains
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <p className="mt-4 text-xs font-mono text-zinc-700">
        Derived from compliance findings only · ≥3 domains = strong · 2 = moderate · 1 = weak · no speculation
      </p>
    </div>
  );
}
