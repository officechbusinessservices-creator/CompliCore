import Link from "next/link";
import { notFound } from "next/navigation";
import { getFindingById, getTargetDetail, getDomainsByRun } from "@/lib/queries";
import { ConfidenceBadge, ReviewerBadge, Badge, SeverityBadge, TierBadge } from "@/components/badges";
import { Screenshot } from "@/components/screenshot";

function fmt(iso: string) {
  return new Date(iso).toLocaleString("en-US", {
    weekday: "short", month: "short", day: "numeric",
    hour: "2-digit", minute: "2-digit", timeZoneName: "short",
  });
}

export default async function EvidencePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const finding = await getFindingById(id);
  const target = finding == null ? await getTargetDetail(id) : null;
  if (!finding && !target) notFound();

  let domainName: string;
  if (finding) {
    const domains = await getDomainsByRun(finding.run_id);
    const domainMap = new Map(domains.map((d) => [d.id, d.domain]));
    domainName = domainMap.get(finding.domain_id) ?? finding.domain_id;
  } else {
    domainName = target!.domain.domain;
  }

  return (
    <div className="p-8 max-w-3xl">
      <div className="flex items-center gap-2 text-xs font-mono text-zinc-600 mb-6">
        <Link href="/evidence" className="hover:text-zinc-400">Evidence Viewer</Link>
        <span>/</span>
        <span className="text-zinc-500 truncate max-w-xs">{id}</span>
      </div>

      <div className="mb-6">
        <h1 className="text-lg font-mono font-semibold text-zinc-100">Evidence Record</h1>
        <p className="text-xs font-mono text-zinc-600 mt-1">{id}</p>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Type</div>
          <Badge variant="neutral">{finding ? "compliance finding" : "opportunity target"}</Badge>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Domain</div>
          <span className="text-sm font-mono text-zinc-200">{domainName}</span>
        </div>
        {finding && (
          <>
            <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
              <div className="text-xs font-mono text-zinc-600 mb-1">Confidence</div>
              <ConfidenceBadge confidence={finding.confidence} />
            </div>
            <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
              <div className="text-xs font-mono text-zinc-600 mb-1">Reviewer Status</div>
              <ReviewerBadge status={finding.reviewer_status} />
            </div>
            <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
              <div className="text-xs font-mono text-zinc-600 mb-1">Rule Family</div>
              <span className="text-sm font-mono text-zinc-400">{finding.rule_family.replace(/_/g, " ")}</span>
            </div>
            <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
              <div className="text-xs font-mono text-zinc-600 mb-1">Created</div>
              <span className="text-xs font-mono text-zinc-400">{fmt(finding.created_at)}</span>
            </div>
          </>
        )}
        {target && (
          <>
            <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
              <div className="text-xs font-mono text-zinc-600 mb-1">Reviewer Status</div>
              <ReviewerBadge status={target.reviewer_status} />
            </div>
            <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
              <div className="text-xs font-mono text-zinc-600 mb-1">Created</div>
              <span className="text-xs font-mono text-zinc-400">{fmt(target.created_at)}</span>
            </div>
          </>
        )}
      </div>

      {finding && (
        <>
          <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
            <div className="text-xs font-mono text-zinc-600 mb-2">Source URL</div>
            <a href={finding.source_url} target="_blank" rel="noopener noreferrer"
              className="text-sm font-mono text-blue-400 hover:text-blue-300 break-all">
              {finding.source_url}
            </a>
          </div>
          <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
            <div className="text-xs font-mono text-zinc-600 mb-2">Verbatim Snippet</div>
            <blockquote className="border-l-2 border-zinc-700 pl-3 text-sm text-zinc-300 font-mono leading-relaxed">
              {finding.snippet}
            </blockquote>
            <p className="mt-2 text-xs font-mono text-zinc-700">Direct quote — not paraphrased, not AI-generated</p>
          </div>
          <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
            <div className="text-xs font-mono text-zinc-600 mb-3">Screenshot</div>
            <Screenshot src={finding.screenshot_ref} />
          </div>
          <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
            <div className="text-xs font-mono text-zinc-600 mb-3">Finding Detail</div>
            <div className="flex items-center gap-2 mb-2">
              <SeverityBadge severity={finding.severity} />
              <Badge variant={finding.rule_result === "FAIL" ? "fail" : "warn"}>{finding.rule_result}</Badge>
            </div>
            <p className="text-sm text-zinc-300 leading-relaxed">{finding.description}</p>
          </div>
        </>
      )}

      {target && (
        <>
          <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
            <div className="text-xs font-mono text-zinc-600 mb-3">Target Summary</div>
            <div className="flex items-center gap-3 mb-3">
              <span className="text-2xl font-mono font-bold text-zinc-100">{target.score}</span>
              <span className="text-xs font-mono text-zinc-600">/ 100</span>
              <TierBadge tier={target.signal_tier} />
            </div>
            <p className="text-sm text-zinc-300 leading-relaxed mb-3">{target.recommendation}</p>
            <ul className="space-y-1">
              {target.top_signals.map((s, i) => (
                <li key={i} className="text-xs font-mono text-zinc-500">· {s}</li>
              ))}
            </ul>
          </div>

          {target.contributing_gaps.length > 0 && (
            <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
              <div className="text-xs font-mono text-zinc-600 mb-3">
                Contributing Content Gaps ({target.contributing_gaps.length})
              </div>
              <div className="space-y-2">
                {target.contributing_gaps.map((gap) => (
                  <div key={gap.id} className="flex items-start gap-2 pl-1">
                    <span className="text-zinc-700 font-mono text-xs mt-0.5">·</span>
                    <div>
                      <span className="text-xs font-mono text-zinc-400">
                        {gap.gap_type.replace(/_/g, " ")}
                      </span>
                      <p className="text-xs text-zinc-600 mt-0.5">{gap.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {target.contributing_findings.length > 0 && (
            <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
              <div className="text-xs font-mono text-zinc-600 mb-3">
                Contributing Findings ({target.contributing_findings.length})
              </div>
              <div className="space-y-3">
                {target.contributing_findings.map((f) => (
                  <div key={f.id} className="border-b border-zinc-800/50 last:border-0 pb-3 last:pb-0">
                    <div className="flex items-center justify-between gap-3 mb-1">
                      <span className="text-xs font-mono text-zinc-400">{f.rule_family.replace(/_/g, " ")}</span>
                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        <SeverityBadge severity={f.severity} />
                        <Link href={`/compliance/${f.id}`}
                          className="text-xs font-mono text-zinc-700 hover:text-zinc-400">→</Link>
                      </div>
                    </div>
                    <p className="text-xs text-zinc-600 line-clamp-2">{f.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      <div className="flex items-center gap-4 mt-4">
        <Link href="/evidence" className="text-xs font-mono text-zinc-600 hover:text-zinc-400">← All evidence</Link>
        {finding && (
          <Link href={`/compliance/${finding.id}`} className="text-xs font-mono text-zinc-600 hover:text-zinc-400">
            ← Finding detail
          </Link>
        )}
        {target && (
          <Link href={`/acquisition/${target.id}`} className="text-xs font-mono text-zinc-600 hover:text-zinc-400">
            ← Target detail
          </Link>
        )}
      </div>
    </div>
  );
}
