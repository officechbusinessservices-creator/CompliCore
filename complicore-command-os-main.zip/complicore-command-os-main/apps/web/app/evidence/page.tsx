import Link from "next/link";
import { getLatestRun, getFindingsByRun, getTargetsByRun, getDomainsByRun } from "@/lib/queries";
import { ConfidenceBadge, ReviewerBadge, Badge } from "@/components/badges";

export default async function EvidenceIndexPage() {
  const run = await getLatestRun();
  if (!run) {
    return (
      <div className="p-8 max-w-5xl">
        <h1 className="text-lg font-mono font-semibold text-zinc-100 mb-3">Evidence Viewer</h1>
        <p className="text-sm font-mono text-zinc-600">No runs found. Start a pipeline run to see data here.</p>
      </div>
    );
  }

  const [findings, targets, domains] = await Promise.all([
    getFindingsByRun(run.id),
    getTargetsByRun(run.id),
    getDomainsByRun(run.id),
  ]);

  const domainMap = new Map(domains.map((d) => [d.id, d.domain]));

  type Entry = {
    id: string; type: "compliance_finding" | "opportunity_target";
    domain: string; rule_family: string | null;
    confidence: string | null; reviewer_status: string; screenshot_ref: string | null;
  };

  const entries: Entry[] = [
    ...findings.map((f) => ({
      id: f.id, type: "compliance_finding" as const,
      domain: domainMap.get(f.domain_id) ?? f.domain_id,
      rule_family: f.rule_family, confidence: f.confidence,
      reviewer_status: f.reviewer_status, screenshot_ref: f.screenshot_ref,
    })),
    ...targets.map((t) => ({
      id: t.id, type: "opportunity_target" as const,
      domain: domainMap.get(t.domain_id) ?? t.domain_id,
      rule_family: null, confidence: null,
      reviewer_status: t.reviewer_status, screenshot_ref: null,
    })),
  ];

  return (
    <div className="p-8 max-w-5xl">
      <div className="mb-6">
        <h1 className="text-lg font-mono font-semibold text-zinc-100">Evidence Viewer</h1>
        <p className="text-sm font-mono text-zinc-500 mt-1">
          {entries.length} evidence records · click any row to inspect
        </p>
      </div>

      {entries.length === 0 ? (
        <p className="text-sm font-mono text-zinc-600">No evidence records for this run.</p>
      ) : (
        <div className="bg-zinc-900 border border-zinc-800 rounded overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-zinc-800">
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">ID</th>
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Type</th>
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Domain</th>
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Rule</th>
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Confidence</th>
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Status</th>
                <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Screenshot</th>
                <th className="px-4 py-2.5" />
              </tr>
            </thead>
            <tbody>
              {entries.map((e) => (
                <tr key={e.id} className="border-b border-zinc-800/50 last:border-0 hover:bg-zinc-800/30 group">
                  <td className="px-4 py-2.5 font-mono text-xs text-zinc-500 max-w-[120px] truncate">{e.id}</td>
                  <td className="px-4 py-2.5">
                    <Badge variant="neutral">{e.type === "compliance_finding" ? "finding" : "target"}</Badge>
                  </td>
                  <td className="px-4 py-2.5 font-mono text-xs text-zinc-300">{e.domain}</td>
                  <td className="px-4 py-2.5 font-mono text-xs text-zinc-500">
                    {e.rule_family ? e.rule_family.replace(/_/g, " ") : "—"}
                  </td>
                  <td className="px-4 py-2.5">
                    {e.confidence ? <ConfidenceBadge confidence={e.confidence} /> : <span className="text-xs font-mono text-zinc-600">—</span>}
                  </td>
                  <td className="px-4 py-2.5"><ReviewerBadge status={e.reviewer_status} /></td>
                  <td className="px-4 py-2.5">
                    {e.screenshot_ref
                      ? <span className="text-xs font-mono text-emerald-700">● {e.screenshot_ref}</span>
                      : <span className="text-xs font-mono text-zinc-700">—</span>}
                  </td>
                  <td className="px-4 py-2.5">
                    <Link href={`/evidence/${e.id}`}
                      className="text-xs font-mono text-zinc-600 hover:text-blue-400 group-hover:text-zinc-400 whitespace-nowrap">
                      inspect →
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
