import Link from "next/link";
import { notFound } from "next/navigation";
import { getFindingDetail, getDomainsByRun, getAuditEventsByFinding } from "@/lib/queries";
import { SeverityBadge, ReviewerBadge, ConfidenceBadge, Badge } from "@/components/badges";
import { ReviewActions } from "@/components/review-actions";
import { Screenshot } from "@/components/screenshot";

function fmt(iso: string) {
  return new Date(iso).toLocaleString("en-US", {
    weekday: "short", month: "short", day: "numeric",
    hour: "2-digit", minute: "2-digit", timeZoneName: "short",
  });
}

export default async function ComplianceFindingPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const detail = await getFindingDetail(id);
  if (!detail) notFound();

  const [domains, auditEvents] = await Promise.all([
    getDomainsByRun(detail.run_id),
    getAuditEventsByFinding(detail.id),
  ]);
  const domainMap = new Map(domains.map((d) => [d.id, d.domain]));
  const domainName = domainMap.get(detail.domain_id) ?? detail.domain_id;

  return (
    <div className="p-8 max-w-3xl">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs font-mono text-zinc-600 mb-6">
        <Link href="/compliance" className="hover:text-zinc-400">Compliance Findings</Link>
        <span>/</span>
        <span className="text-zinc-500 truncate max-w-xs">{id}</span>
      </div>

      {/* Header */}
      <div className="mb-6">
        <h1 className="text-lg font-mono font-semibold text-zinc-100">Compliance Finding</h1>
        <p className="text-xs font-mono text-zinc-600 mt-1">{id}</p>
      </div>

      {/* Metadata grid */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Rule Name</div>
          <span className="text-sm font-mono text-zinc-300">{detail.rule_name.replace(/_/g, " ")}</span>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Domain</div>
          <span className="text-sm font-mono text-zinc-200">{domainName}</span>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Severity</div>
          <SeverityBadge severity={detail.severity} />
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Result</div>
          <Badge variant={detail.rule_result === "FAIL" ? "fail" : "warn"}>{detail.rule_result}</Badge>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Confidence</div>
          <ConfidenceBadge confidence={detail.confidence} />
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Reviewer Status</div>
          <ReviewerBadge status={detail.reviewer_status} />
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Run</div>
          <span className="text-xs font-mono text-zinc-500">{detail.run_id}</span>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Created</div>
          <span className="text-xs font-mono text-zinc-400">{fmt(detail.created_at)}</span>
        </div>
      </div>

      {/* Description */}
      <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
        <div className="text-xs font-mono text-zinc-600 mb-2">Description</div>
        <p className="text-sm text-zinc-300 leading-relaxed">{detail.description}</p>
      </div>

      {/* Source URL */}
      <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
        <div className="text-xs font-mono text-zinc-600 mb-2">Source URL</div>
        <a
          href={detail.source_url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-sm font-mono text-blue-400 hover:text-blue-300 break-all"
        >
          {detail.source_url}
        </a>
      </div>

      {/* Verbatim snippet */}
      <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
        <div className="text-xs font-mono text-zinc-600 mb-2">Verbatim Snippet</div>
        <blockquote className="border-l-2 border-zinc-700 pl-3 text-sm text-zinc-300 font-mono leading-relaxed">
          {detail.snippet}
        </blockquote>
        <p className="mt-2 text-xs font-mono text-zinc-700">
          Direct quote from source page — not paraphrased, not AI-generated
        </p>
      </div>

      {/* Screenshot */}
      <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
        <div className="text-xs font-mono text-zinc-600 mb-3">Screenshot</div>
        <Screenshot src={detail.screenshot_ref} />
      </div>

      {/* Evidence block — source page + co-located content gaps */}
      {detail.source_page && (
        <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
          <div className="text-xs font-mono text-zinc-600 mb-3">Source Page</div>
          <a
            href={detail.source_page.url}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs font-mono text-blue-400 hover:text-blue-300 break-all"
          >
            {detail.source_page.url}
          </a>
          <p className="text-xs font-mono text-zinc-600 mt-1 mb-3">
            {detail.source_page.word_count} words indexed
          </p>

          {detail.content_gaps_on_page.length > 0 && (
            <>
              <div className="text-xs font-mono text-zinc-600 mb-2">
                Co-located content gaps ({detail.content_gaps_on_page.length})
              </div>
              <div className="space-y-2">
                {detail.content_gaps_on_page.map((gap) => (
                  <div key={gap.id} className="flex items-start gap-2 pl-1">
                    <span className="text-zinc-700 font-mono text-xs mt-0.5">·</span>
                    <div>
                      <span className="text-xs font-mono text-zinc-400">
                        {gap.gap_type.replace(/_/g, " ")}
                      </span>
                      <p className="text-xs text-zinc-600 mt-0.5">{gap.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}

      {/* Report linkage */}
      {detail.report_id && (
        <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
          <div className="text-xs font-mono text-zinc-600 mb-2">Report</div>
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-zinc-500">{detail.report_id}</span>
            <Link
              href={`/reports/${detail.report_id}`}
              className="text-xs font-mono text-zinc-600 hover:text-zinc-400"
            >
              view report →
            </Link>
          </div>
        </div>
      )}

      {/* Reviewer panel */}
      <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
        <div className="text-xs font-mono text-zinc-600 mb-3">Reviewer Decision</div>
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="text-xs font-mono text-zinc-600 mb-1.5">Current status</div>
            <ReviewerBadge status={detail.reviewer_status} />
          </div>
          <div>
            <div className="text-xs font-mono text-zinc-600 mb-1.5">Actions</div>
            <ReviewActions
              id={detail.id}
              collection="findings"
              currentStatus={detail.reviewer_status as "pending" | "approved" | "needs_review" | "rejected"}
            />
          </div>
        </div>
        <p className="mt-3 text-xs font-mono text-zinc-700">
          Rejection requires a note · all decisions logged to audit trail · approved findings only in published reports
        </p>
      </div>

      {/* Audit trail */}
      <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
        <div className="text-xs font-mono text-zinc-600 mb-3">
          Audit Trail ({auditEvents.length})
        </div>
        {auditEvents.length === 0 ? (
          <p className="text-xs font-mono text-zinc-700">No decisions recorded yet.</p>
        ) : (
          <div className="space-y-3">
            {auditEvents.map((event) => (
              <div key={event.id} className="flex items-start gap-3 border-b border-zinc-800/50 last:border-0 pb-3 last:pb-0">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-mono text-zinc-300">{event.action}</span>
                    <span className="text-xs font-mono text-zinc-700">·</span>
                    <span className="text-xs font-mono text-zinc-600">{event.actor_id ?? event.actor}</span>
                    <span className="text-xs font-mono text-zinc-700">·</span>
                    <span className="text-xs font-mono text-zinc-700">{fmt(event.created_at)}</span>
                  </div>
                  {"note" in event.payload && typeof event.payload.note === "string" && (
                    <p className="mt-1 text-xs font-mono text-zinc-500 pl-0">
                      &ldquo;{event.payload.note}&rdquo;
                    </p>
                  )}
                  {"from" in event.payload && "to" in event.payload && (
                    <p className="mt-0.5 text-xs font-mono text-zinc-700">
                      {String(event.payload.from)} → {String(event.payload.to)}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Back links */}
      <div className="flex items-center gap-4 mt-4">
        <Link href="/compliance" className="text-xs font-mono text-zinc-600 hover:text-zinc-400">
          ← Compliance findings
        </Link>
        <Link href={`/evidence/${detail.id}`} className="text-xs font-mono text-zinc-600 hover:text-zinc-400">
          view evidence →
        </Link>
      </div>
    </div>
  );
}
