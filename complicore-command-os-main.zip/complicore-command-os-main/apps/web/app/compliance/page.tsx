import Link from "next/link";
import { loadFindings } from "@/lib/pipeline-data";
import { SeverityBadge, ReviewerBadge, ConfidenceBadge, Badge } from "@/components/badges";
import { ReviewActions } from "@/components/review-actions";

function fmt(iso: string) {
  return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export default async function CompliancePage() {
  const findings = await loadFindings();

  const high = findings.filter((f) => f.severity === "high").length;
  const approved = findings.filter((f) => f.reviewer_status === "approved").length;
  const pending = findings.filter((f) => f.reviewer_status === "pending").length;

  return (
    <div className="p-8 max-w-6xl">
      <div className="mb-6">
        <h1 className="text-lg font-mono font-semibold text-zinc-100">Compliance Findings</h1>
        <p className="text-sm font-mono text-zinc-500 mt-1">
          {findings.length} findings · {high} high severity · {approved} approved · {pending} pending review
        </p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        {[
          { label: "Total", value: findings.length },
          { label: "High Severity", value: high },
          { label: "Approved", value: approved },
          { label: "Needs Review", value: findings.filter((f) => f.reviewer_status === "needs_review").length },
        ].map(({ label, value }) => (
          <div key={label} className="bg-zinc-900 border border-zinc-800 rounded p-3">
            <div className="text-xs font-mono text-zinc-600">{label}</div>
            <div className="text-xl font-mono font-bold text-zinc-200 mt-0.5">{value}</div>
          </div>
        ))}
      </div>

      {/* Findings table */}
      <div className="bg-zinc-900 border border-zinc-800 rounded overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-zinc-800">
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Domain</th>
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Rule Family</th>
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Sev</th>
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Result</th>
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal w-1/3">Description</th>
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Confidence</th>
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Status</th>
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Date</th>
              <th className="px-4 py-2.5" />
            </tr>
          </thead>
          <tbody>
            {findings.map((f) => (
              <tr key={f.finding_id} className="border-b border-zinc-800/50 last:border-0 hover:bg-zinc-800/30 group">
                <td className="px-4 py-3 font-mono text-xs text-zinc-300 whitespace-nowrap">{f.domain}</td>
                <td className="px-4 py-3 font-mono text-xs text-zinc-400 whitespace-nowrap">{f.rule_family.replace(/_/g, " ")}</td>
                <td className="px-4 py-3"><SeverityBadge severity={f.severity} /></td>
                <td className="px-4 py-3">
                  <Badge variant={f.rule_result === "FAIL" ? "fail" : "warn"}>{f.rule_result}</Badge>
                </td>
                <td className="px-4 py-3 text-xs text-zinc-400 max-w-xs">
                  <p className="line-clamp-2">{f.description}</p>
                  <p className="mt-1 font-mono text-zinc-600 line-clamp-1 text-xs">{f.snippet}</p>
                </td>
                <td className="px-4 py-3"><ConfidenceBadge confidence={f.confidence} /></td>
                <td className="px-4 py-3">
                  <ReviewerBadge status={f.reviewer_status} />
                </td>
                <td className="px-4 py-3 font-mono text-xs text-zinc-600 whitespace-nowrap">{fmt(f.created_at)}</td>
                <td className="px-4 py-3">
                  <div className="flex flex-col gap-1.5 items-end">
                    <ReviewActions
                      id={f.finding_id}
                      collection="findings"
                      currentStatus={f.reviewer_status as "pending" | "approved" | "needs_review" | "rejected"}
                    />
                    <Link
                      href={`/compliance/${f.finding_id}`}
                      className="text-xs font-mono text-zinc-700 hover:text-zinc-400 transition-colors"
                    >
                      detail →
                    </Link>
                    <Link
                      href={`/evidence/${f.finding_id}`}
                      className="text-xs font-mono text-zinc-700 hover:text-blue-400 transition-colors"
                    >
                      evidence →
                    </Link>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="mt-3 text-xs font-mono text-zinc-700">
        All findings require evidence · approved findings only are included in published reports
      </p>
    </div>
  );
}
