import Link from "next/link";
import { getLatestRun, getDomainsByRun, getFindingCountsByDomainId } from "@/lib/queries";

const STATUS_COLOR: Record<string, string> = {
  mapped: "text-emerald-400",
  blocked: "text-amber-400",
  unreachable: "text-zinc-600",
};

function fmt(iso: string | null) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export default async function MarketMonitorPage() {
  const run = await getLatestRun();
  if (!run) {
    return (
      <div className="p-8 max-w-5xl">
        <h1 className="text-lg font-mono font-semibold text-zinc-100 mb-3">Market Monitor</h1>
        <p className="text-sm font-mono text-zinc-600">No runs found. Start a pipeline run to see data here.</p>
      </div>
    );
  }

  const [domains, findingCounts] = await Promise.all([
    getDomainsByRun(run.id),
    getFindingCountsByDomainId(run.id),
  ]);

  const active = domains.filter((d) => d.status === "mapped");
  const totalFindings = [...findingCounts.values()].reduce((s, c) => s + c, 0);

  return (
    <div className="p-8 max-w-5xl">
      <div className="mb-6">
        <h1 className="text-lg font-mono font-semibold text-zinc-100">Market Monitor</h1>
        <p className="text-sm font-mono text-zinc-500 mt-1">
          {run.metro} · {domains.length} domains · Run {run.id}
        </p>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-6">
        {[
          { label: "Domains", value: domains.length },
          { label: "Active", value: active.length },
          { label: "Findings", value: totalFindings },
        ].map(({ label, value }) => (
          <div key={label} className="bg-zinc-900 border border-zinc-800 rounded p-3">
            <div className="text-xs font-mono text-zinc-600">{label}</div>
            <div className="text-xl font-mono font-bold text-zinc-200 mt-0.5">{value}</div>
          </div>
        ))}
      </div>

      <div className="bg-zinc-900 border border-zinc-800 rounded overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-zinc-800">
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Domain</th>
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Status</th>
              <th className="text-right px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Findings</th>
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Sitemap</th>
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Last Crawled</th>
              <th className="px-4 py-2.5" />
            </tr>
          </thead>
          <tbody>
            {domains.map((d) => {
              const count = findingCounts.get(d.id) ?? 0;
              return (
                <tr key={d.id} className="border-b border-zinc-800/50 last:border-0 hover:bg-zinc-900/60">
                  <td className="px-4 py-2.5 font-mono text-xs text-zinc-200">{d.domain}</td>
                  <td className="px-4 py-2.5">
                    <span className={`text-xs font-mono ${STATUS_COLOR[d.status] ?? "text-zinc-500"}`}>
                      {d.status === "mapped" ? "●" : d.status === "blocked" ? "◌" : "✗"} {d.status}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-right">
                    {count > 0 ? (
                      <Link href={`/compliance?domain=${d.domain}`} className="font-mono text-xs text-red-400 hover:text-red-300">{count}</Link>
                    ) : (
                      <span className="font-mono text-xs text-zinc-600">—</span>
                    )}
                  </td>
                  <td className="px-4 py-2.5 font-mono text-xs text-zinc-600">
                    {d.sitemap_url ? <span className="text-emerald-700">yes</span> : "—"}
                  </td>
                  <td className="px-4 py-2.5 font-mono text-xs text-zinc-500">{fmt(d.crawled_at)}</td>
                  <td className="px-4 py-2.5">
                    {count > 0 && (
                      <Link href={`/compliance?domain=${d.domain}`} className="text-xs font-mono text-zinc-600 hover:text-zinc-400">
                        findings →
                      </Link>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <p className="mt-3 text-xs font-mono text-zinc-700">
        blocked = robots.txt disallowed · unreachable = HTTP timeout or DNS failure
      </p>
    </div>
  );
}
