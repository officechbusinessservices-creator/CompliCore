import Link from "next/link";
import { notFound } from "next/navigation";
import { getTargetDetail, getOutboundBriefsByTarget } from "@/lib/queries";
import { TierBadge, ReviewerBadge, SeverityBadge, ScoreBar, Badge } from "@/components/badges";
import { ReviewActions } from "@/components/review-actions";

function fmt(iso: string) {
  return new Date(iso).toLocaleString("en-US", {
    weekday: "short", month: "short", day: "numeric",
    hour: "2-digit", minute: "2-digit", timeZoneName: "short",
  });
}

export default async function AcquisitionTargetPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [target, briefs] = await Promise.all([
    getTargetDetail(id),
    getOutboundBriefsByTarget(id),
  ]);
  if (!target) notFound();

  return (
    <div className="p-8 max-w-3xl">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs font-mono text-zinc-600 mb-6">
        <Link href="/acquisition" className="hover:text-zinc-400">Acquisition Targets</Link>
        <span>/</span>
        <span className="text-zinc-500 truncate max-w-xs">{id}</span>
      </div>

      {/* Header */}
      <div className="mb-6">
        <h1 className="text-lg font-mono font-semibold text-zinc-100">Acquisition Target</h1>
        <p className="text-xs font-mono text-zinc-600 mt-1">{target.domain.domain}</p>
      </div>

      {/* Score + metadata grid */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-2">Opportunity Score</div>
          <div className="flex items-center gap-3">
            <span className="text-2xl font-mono font-bold text-zinc-100">{target.score}</span>
            <span className="text-xs font-mono text-zinc-600">/ 100</span>
            <ScoreBar score={target.score} />
          </div>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-2">Signal Tier</div>
          <TierBadge tier={target.signal_tier} />
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Domain</div>
          <span className="text-sm font-mono text-zinc-200">{target.domain.domain}</span>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Reviewer Status</div>
          <ReviewerBadge status={target.reviewer_status} />
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Run</div>
          <span className="text-xs font-mono text-zinc-500">{target.run_id}</span>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded p-3">
          <div className="text-xs font-mono text-zinc-600 mb-1">Created</div>
          <span className="text-xs font-mono text-zinc-400">{fmt(target.created_at)}</span>
        </div>
      </div>

      {/* Recommendation */}
      <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
        <div className="text-xs font-mono text-zinc-600 mb-2">Recommendation</div>
        <p className="text-sm text-zinc-300 leading-relaxed">{target.recommendation}</p>
      </div>

      {/* Top signals */}
      {target.top_signals.length > 0 && (
        <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
          <div className="text-xs font-mono text-zinc-600 mb-3">
            Top Signals ({target.top_signals.length})
          </div>
          <ul className="space-y-1.5">
            {target.top_signals.map((s, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-zinc-700 font-mono text-xs mt-0.5">·</span>
                <span className="text-xs font-mono text-zinc-400">{s}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Contributing content gaps */}
      <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
        <div className="text-xs font-mono text-zinc-600 mb-3">
          Contributing Content Gaps ({target.contributing_gaps.length})
        </div>
        {target.contributing_gaps.length === 0 ? (
          <p className="text-xs font-mono text-zinc-700">No content gaps recorded.</p>
        ) : (
          <div className="space-y-2">
            {target.contributing_gaps.map((gap) => (
              <div key={gap.id} className="flex items-start gap-2 pl-1">
                <span className="text-zinc-700 font-mono text-xs mt-0.5">·</span>
                <div>
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-xs font-mono text-zinc-400">
                      {gap.gap_type.replace(/_/g, " ")}
                    </span>
                    <span className="text-xs font-mono text-zinc-700">{gap.id.slice(0, 8)}</span>
                  </div>
                  <p className="text-xs text-zinc-600">{gap.description}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Contributing compliance findings */}
      <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
        <div className="text-xs font-mono text-zinc-600 mb-3">
          Contributing Compliance Findings ({target.contributing_findings.length})
        </div>
        {target.contributing_findings.length === 0 ? (
          <p className="text-xs font-mono text-zinc-700">No compliance findings linked.</p>
        ) : (
          <div className="space-y-3">
            {target.contributing_findings.map((f) => (
              <div key={f.id} className="border-b border-zinc-800/50 last:border-0 pb-3 last:pb-0">
                <div className="flex items-center justify-between gap-3 mb-1">
                  <span className="text-xs font-mono text-zinc-400">{f.rule_family.replace(/_/g, " ")}</span>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <SeverityBadge severity={f.severity} />
                    <Badge variant={f.rule_result === "FAIL" ? "fail" : "warn"}>{f.rule_result}</Badge>
                    <Link href={`/compliance/${f.id}`}
                      className="text-xs font-mono text-zinc-700 hover:text-zinc-400">
                      detail →
                    </Link>
                  </div>
                </div>
                <p className="text-xs text-zinc-600 line-clamp-2">{f.description}</p>
                <p className="text-xs font-mono text-zinc-700 mt-0.5">{f.source_url}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Reviewer panel */}
      <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
        <div className="text-xs font-mono text-zinc-600 mb-3">Reviewer Decision</div>
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="text-xs font-mono text-zinc-600 mb-1.5">Current status</div>
            <ReviewerBadge status={target.reviewer_status} />
          </div>
          <div>
            <div className="text-xs font-mono text-zinc-600 mb-1.5">Actions</div>
            <ReviewActions
              id={target.id}
              collection="targets"
              currentStatus={target.reviewer_status as "pending" | "approved" | "needs_review" | "rejected"}
            />
          </div>
        </div>
        <p className="mt-3 text-xs font-mono text-zinc-700">
          Rejection requires a note · all decisions logged to audit trail
        </p>
      </div>

      {/* Outbound briefs */}
      <div className="bg-zinc-900 border border-zinc-800 rounded p-4 mb-4">
        <div className="text-xs font-mono text-zinc-600 mb-3">
          Outbound Briefs ({briefs.length})
        </div>
        {briefs.length === 0 ? (
          <p className="text-xs font-mono text-zinc-700">
            No brief generated — only HIGH and MODERATE targets receive outbound briefs.
          </p>
        ) : (
          <div className="space-y-4">
            {briefs.map((brief) => (
              <div key={brief.id} className="border border-zinc-800 rounded p-3">
                <div className="flex items-center justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2">
                    <ReviewerBadge status={brief.reviewer_status} />
                    <span className="text-xs font-mono text-zinc-700">{brief.id.slice(0, 8)}</span>
                  </div>
                  <ReviewActions
                    id={brief.id}
                    collection="briefs"
                    currentStatus={brief.reviewer_status as "pending" | "approved" | "needs_review" | "rejected"}
                  />
                </div>
                {brief.approved_at && (
                  <p className="text-xs font-mono text-zinc-600 mb-2">
                    Approved {fmt(brief.approved_at)}
                  </p>
                )}
                <pre className="text-xs font-mono text-zinc-400 whitespace-pre-wrap leading-relaxed bg-zinc-950 rounded p-3 overflow-x-auto">
                  {brief.content}
                </pre>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Back links */}
      <div className="flex items-center gap-4 mt-4">
        <Link href="/acquisition" className="text-xs font-mono text-zinc-600 hover:text-zinc-400">
          ← Acquisition targets
        </Link>
        <Link href={`/evidence/${target.id}`} className="text-xs font-mono text-zinc-600 hover:text-zinc-400">
          view evidence →
        </Link>
      </div>
    </div>
  );
}
