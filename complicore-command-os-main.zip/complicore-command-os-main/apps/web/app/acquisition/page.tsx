import Link from "next/link";
import { loadTargets } from "@/lib/pipeline-data";
import { TierBadge, ReviewerBadge, ScoreBar } from "@/components/badges";
import { ReviewActions } from "@/components/review-actions";

function fmt(iso: string) {
  return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export default async function AcquisitionPage() {
  const targets = await loadTargets();

  const high = targets.filter((t) => t.signal_tier === "HIGH").length;
  const moderate = targets.filter((t) => t.signal_tier === "MODERATE").length;
  const approved = targets.filter((t) => t.reviewer_status === "approved").length;

  return (
    <div className="p-8 max-w-6xl">
      <div className="mb-6">
        <h1 className="text-lg font-mono font-semibold text-zinc-100">Acquisition Targets</h1>
        <p className="text-sm font-mono text-zinc-500 mt-1">
          {targets.length} targets · {high} HIGH signal · {approved} approved
        </p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        {[
          { label: "Total Targets", value: targets.length },
          { label: "HIGH Signal", value: high },
          { label: "MODERATE Signal", value: moderate },
          { label: "Approved", value: approved },
        ].map(({ label, value }) => (
          <div key={label} className="bg-zinc-900 border border-zinc-800 rounded p-3">
            <div className="text-xs font-mono text-zinc-600">{label}</div>
            <div className="text-xl font-mono font-bold text-zinc-200 mt-0.5">{value}</div>
          </div>
        ))}
      </div>

      {/* Target table */}
      <div className="bg-zinc-900 border border-zinc-800 rounded overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-zinc-800">
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Domain</th>
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Score</th>
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Tier</th>
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal w-1/3">Top Signals</th>
              <th className="text-right px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Findings</th>
              <th className="text-right px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Gaps</th>
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Status</th>
              <th className="text-left px-4 py-2.5 text-xs font-mono text-zinc-600 font-normal">Date</th>
              <th className="px-4 py-2.5" />
            </tr>
          </thead>
          <tbody>
            {targets.map((t) => (
              <tr key={t.target_id} className="border-b border-zinc-800/50 last:border-0 hover:bg-zinc-800/30 group">
                <td className="px-4 py-3 font-mono text-xs text-zinc-200 whitespace-nowrap align-top">{t.domain}</td>
                <td className="px-4 py-3 align-top"><ScoreBar score={t.score} /></td>
                <td className="px-4 py-3 align-top"><TierBadge tier={t.signal_tier} /></td>
                <td className="px-4 py-3 align-top">
                  <ul className="space-y-0.5">
                    {t.top_signals.slice(0, 2).map((s: string, i: number) => (
                      <li key={i} className="text-xs text-zinc-500 font-mono line-clamp-1">{s}</li>
                    ))}
                    {t.top_signals.length > 2 && (
                      <li className="text-xs text-zinc-700 font-mono">+{t.top_signals.length - 2} more</li>
                    )}
                  </ul>
                  <p className="mt-1.5 text-xs text-zinc-600 line-clamp-2">{t.recommendation}</p>
                </td>
                <td className="px-4 py-3 text-right font-mono text-xs text-zinc-400 align-top">{t.contributing_finding_count}</td>
                <td className="px-4 py-3 text-right font-mono text-xs text-zinc-400 align-top">{t.contributing_gap_count}</td>
                <td className="px-4 py-3 align-top"><ReviewerBadge status={t.reviewer_status} /></td>
                <td className="px-4 py-3 font-mono text-xs text-zinc-600 whitespace-nowrap align-top">{fmt(t.created_at)}</td>
                <td className="px-4 py-3 align-top">
                  <div className="flex flex-col gap-1.5 items-end">
                    <ReviewActions
                      id={t.target_id}
                      collection="targets"
                      currentStatus={t.reviewer_status as "pending" | "approved" | "needs_review" | "rejected"}
                    />
                    <Link
                      href={`/acquisition/${t.target_id}`}
                      className="text-xs font-mono text-zinc-700 hover:text-zinc-400 transition-colors"
                    >
                      detail →
                    </Link>
                    <Link
                      href={`/evidence/${t.target_id}`}
                      className="text-xs font-mono text-zinc-700 hover:text-blue-400 transition-colors"
                    >
                      evidence →
                    </Link>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="mt-3 text-xs font-mono text-zinc-700">
        Score 0–100 · HIGH ≥70 · MODERATE 40–69 · LOW &lt;40 · scores trace to finding and gap records
      </p>
    </div>
  );
}
