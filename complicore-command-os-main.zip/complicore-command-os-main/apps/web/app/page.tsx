import Link from "next/link";
import {
  getLatestRun,
  getStepsByRun,
  getFindingsByRun,
  getTargetsByRun,
  getDomainsByRun,
  getReportsByRun,
} from "@/lib/queries";

function MetricCard({ label, value, sub, accent }: {
  label: string; value: number | string; sub?: string;
  accent?: "red" | "amber" | "emerald";
}) {
  const color =
    accent === "red" ? "text-red-400" :
    accent === "amber" ? "text-amber-400" :
    accent === "emerald" ? "text-emerald-400" : "text-zinc-100";
  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded p-4">
      <div className="text-xs font-mono text-zinc-500 uppercase tracking-wider mb-1">{label}</div>
      <div className={`text-2xl font-mono font-bold ${color}`}>{value}</div>
      {sub && <div className="text-xs font-mono text-zinc-600 mt-1">{sub}</div>}
    </div>
  );
}

export default async function OverviewPage() {
  const run = await getLatestRun();

  if (!run) {
    return (
      <div className="p-8 max-w-5xl">
        <h1 className="text-lg font-mono font-semibold text-zinc-100 mb-3">Overview</h1>
        <p className="text-sm font-mono text-zinc-600">No runs found. Start a pipeline run to see data here.</p>
      </div>
    );
  }

  const [steps, findings, targets, domains, reports] = await Promise.all([
    getStepsByRun(run.id),
    getFindingsByRun(run.id),
    getTargetsByRun(run.id),
    getDomainsByRun(run.id),
    getReportsByRun(run.id),
  ]);

  const highSeverity = findings.filter((f) => f.severity === "high").length;
  const highSignal = targets.filter((t) => t.signal_tier === "HIGH").length;
  const domainsActive = domains.filter((d) => d.status === "mapped").length;
  const approvedReports = reports.filter((r) => r.status === "approved").length;

  // growth gaps = rule families failing across 2+ domains
  const ruleToDomainsMap = new Map<string, Set<string>>();
  for (const f of findings) {
    if (!ruleToDomainsMap.has(f.rule_family)) ruleToDomainsMap.set(f.rule_family, new Set());
    ruleToDomainsMap.get(f.rule_family)!.add(f.domain_id);
  }
  const growthGaps = [...ruleToDomainsMap.values()].filter((s) => s.size >= 2).length;

  const weekEnding = new Date(run.created_at).toLocaleDateString("en-US", {
    month: "short", day: "numeric", year: "numeric",
  });

  const stepColor = (s: string) =>
    s === "completed" ? "text-emerald-400" : s === "failed" ? "text-red-400" :
    s === "running" ? "text-amber-400" : "text-zinc-500";

  return (
    <div className="p-8 max-w-5xl">
      <div className="mb-8">
        <h1 className="text-lg font-mono font-semibold text-zinc-100">Overview</h1>
        <p className="text-sm font-mono text-zinc-500 mt-1">
          {run.metro} · Week ending {weekEnding} · <span className="text-zinc-600">Run {run.id}</span>
        </p>
      </div>

      <section className="mb-8">
        <div className="text-xs font-mono text-zinc-600 uppercase tracking-wider mb-3">This Week</div>
        <div className="grid grid-cols-3 gap-3">
          <MetricCard label="Compliance Findings" value={findings.length} sub={`${highSeverity} high severity`} accent="red" />
          <MetricCard label="Acquisition Targets" value={targets.length} sub={`${highSignal} HIGH signal`} accent="amber" />
          <MetricCard label="Growth Gaps" value={growthGaps} sub="rule families across 2+ domains" />
          <MetricCard label="Domains Monitored" value={domains.length} sub={`${domainsActive} active`} />
          <MetricCard label="Run Status" value={run.status} accent="emerald" />
          <MetricCard label="Metro" value={run.metro} sub="v1 scope · 1 metro" />
        </div>
      </section>

      <section className="mb-8">
        <div className="text-xs font-mono text-zinc-600 uppercase tracking-wider mb-3">Pipeline · {run.id}</div>
        {steps.length === 0 ? (
          <p className="text-xs font-mono text-zinc-700">No step records for this run.</p>
        ) : (
          <div className="bg-zinc-900 border border-zinc-800 rounded overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-zinc-800">
                  <th className="text-left px-4 py-2 text-xs font-mono text-zinc-600 font-normal">Step</th>
                  <th className="text-left px-4 py-2 text-xs font-mono text-zinc-600 font-normal">Status</th>
                  <th className="text-right px-4 py-2 text-xs font-mono text-zinc-600 font-normal">In</th>
                  <th className="text-right px-4 py-2 text-xs font-mono text-zinc-600 font-normal">Out</th>
                </tr>
              </thead>
              <tbody>
                {steps.map((s) => (
                  <tr key={s.id} className="border-b border-zinc-800/50 last:border-0">
                    <td className="px-4 py-2 font-mono text-xs text-zinc-300">{s.name}</td>
                    <td className="px-4 py-2">
                      <span className={`text-xs font-mono ${stepColor(s.status)}`}>● {s.status}</span>
                    </td>
                    <td className="px-4 py-2 text-right font-mono text-xs text-zinc-500">{s.input_count ?? "—"}</td>
                    <td className="px-4 py-2 text-right font-mono text-xs text-zinc-300">{s.output_count ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section>
        <div className="text-xs font-mono text-zinc-600 uppercase tracking-wider mb-3">Outputs</div>
        <div className="grid grid-cols-2 gap-2">
          {[
            { href: "/compliance", label: "Compliance Findings", count: findings.length, note: `${highSeverity} high severity` },
            { href: "/growth", label: "Growth Intelligence", count: growthGaps, note: "market gaps" },
            { href: "/acquisition", label: "Acquisition Targets", count: targets.length, note: `${highSignal} HIGH tier` },
            { href: "/reports", label: "Reports", count: reports.length, note: `${approvedReports} approved` },
          ].map(({ href, label, count, note }) => (
            <Link key={href} href={href}
              className="flex items-center justify-between bg-zinc-900 border border-zinc-800 rounded px-4 py-3 hover:border-zinc-700 transition-colors group">
              <div>
                <div className="text-sm font-mono text-zinc-300 group-hover:text-zinc-100">{label}</div>
                <div className="text-xs font-mono text-zinc-600 mt-0.5">{note}</div>
              </div>
              <div className="text-lg font-mono font-bold text-zinc-400 group-hover:text-zinc-200">{count}</div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
