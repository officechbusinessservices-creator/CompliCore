import type { NextConfig } from "next";
import path from "path";

const config: NextConfig = {
  outputFileTracingRoot: path.join(__dirname, "../../"),
  reactStrictMode: true,
  transpilePackages: ["@complicore/core"],
  webpack(webpackConfig) {
    webpackConfig.resolve = {
      ...webpackConfig.resolve,
      extensionAlias: {
        ".js": [".ts", ".tsx", ".js"],
        ".mjs": [".mts", ".mjs"],
        ".cjs": [".cts", ".cjs"],
      },
    };
    return webpackConfig;
  },
};

export default config;
