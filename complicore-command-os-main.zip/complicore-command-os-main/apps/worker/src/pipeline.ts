/**
 * CompliCore v1 pipeline:
 *   discover → map → classify → scrape → normalize → rules → brief
 *
 * In-memory by default. Pass `db` + `workspaceId` in config to additionally
 * persist every entity to Postgres. JSON exports are written regardless —
 * they are secondary artifacts, not the source of truth when DB is active.
 *
 * DB write order (sequential, no transactions — neon-http limitation):
 *   insertRun → setRunStatus(running)
 *   └─ per domain: insertDomain
 *      └─ per url: insertSourceUrl
 *         └─ per page: insertSourcePage
 *            └─ per violation: insertFinding
 *      setDomainStatus(crawled)
 *   insertOpportunityTarget (per scored domain)
 *   insertReport
 *   setRunStatus(completed | failed)
 *   insertAuditEvent at each milestone
 */

import { writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { randomUUID } from "node:crypto";

import type { FirecrawlClient } from "@complicore/firecrawl/client";
import { FirecrawlError } from "@complicore/firecrawl/client";
import { discoverDomains } from "@complicore/firecrawl/search";
import { mapDomain } from "@complicore/firecrawl/map";
import { classifyPage } from "@complicore/firecrawl/classify";
import { scrapePage } from "@complicore/firecrawl/scrape";
import { normalizeSourcePage } from "@complicore/firecrawl/normalize";
import { evaluateAllRules, collectViolations } from "@complicore/rules";
import { generateOutboundBriefContent } from "./outbound-brief-generator.js";
import type { SourcePage, FindingResult } from "@complicore/core/types";
import type { RuleViolation, RuleResult } from "@complicore/rules";
import type { Db } from "@complicore/core/db/client";
import {
  insertRun,
  setRunStatus,
} from "@complicore/core/db/repos/runs";
import {
  insertStep,
  setStepStatus,
} from "@complicore/core/db/repos/steps";
import {
  insertDomain,
  setDomainStatus,
} from "@complicore/core/db/repos/domains";
import { insertSourceUrl } from "@complicore/core/db/repos/source-urls";
import { insertSourcePage } from "@complicore/core/db/repos/source-pages";
import { insertListing } from "@complicore/core/db/repos/listings";
import { insertPricingObservation } from "@complicore/core/db/repos/pricing-observations";
import { insertPolicyObservation } from "@complicore/core/db/repos/policy-observations";
import { insertSchemaObservation } from "@complicore/core/db/repos/schema-observations";
import { insertContentGap } from "@complicore/core/db/repos/content-gaps";
import { insertFinding } from "@complicore/core/db/repos/findings";
import { insertOpportunityTarget } from "@complicore/core/db/repos/opportunity-targets";
import { insertOutboundBrief } from "@complicore/core/db/repos/outbound-briefs";
import { insertReport } from "@complicore/core/db/repos/reports";
import { insertAuditEvent } from "@complicore/core/db/repos/audit-events";

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

export interface PipelineConfig {
  metro: string;
  operatorDomain: string;
  outputDir: string;
  /** Write per-page fixture JSON snapshots here for golden-set eval replay */
  fixturesDir?: string;
  /** Limit URLs scraped per domain (keeps mock runs fast) */
  maxUrlsPerDomain?: number;
  /**
   * Neon DB client. When provided alongside workspaceId, every entity is
   * persisted to Postgres. Omit for in-memory-only runs.
   */
  db?: Db;
  /**
   * Workspace UUID. Required when db is provided.
   * Runs are associated with this workspace in the DB.
   */
  workspaceId?: string;
}

// ---------------------------------------------------------------------------
// Internal state types
// ---------------------------------------------------------------------------

interface DomainState {
  /** In-memory random id — used for JSON output and brief display only. */
  id: string;
  /** DB-assigned UUID. Null when db is not configured. Used for all FK refs. */
  dbId: string | null;
  domain: string;
  pageCount: number;
  findingCount: number;
  gapCount: number;
  /** DB UUIDs of compliance_findings rows — used for opportunity_targets FK. */
  dbFindingIds: string[];
  /** DB UUIDs of content_gaps rows — used for opportunity_targets FK. */
  dbGapIds: string[];
}

// ---------------------------------------------------------------------------
// DB context — stable for the lifetime of one run
// ---------------------------------------------------------------------------

interface DbContext {
  db: Db;
  workspaceId: string;
  /** UUID from insertRun — used as FK in all child inserts. */
  runId: string;
}

// ---------------------------------------------------------------------------
// Result mapping: RuleViolation.result → ComplianceFinding.rule_result
//
// RuleResult uses lowercase/snake_case; FindingResult uses SCREAMING_CASE.
//   "fail"                   → "FAIL"
//   "uncertain_needs_review" → "WARN"
// ---------------------------------------------------------------------------

function toFindingResult(result: Exclude<RuleResult, "pass">): FindingResult {
  return result === "fail" ? "FAIL" : "WARN";
}

// ---------------------------------------------------------------------------
// Retry helper — retries retryable FirecrawlErrors with exponential backoff
// ---------------------------------------------------------------------------

async function withRetry<T>(
  fn: () => Promise<T>,
  label: string,
  maxAttempts = 3,
  baseDelayMs = 5_000,
): Promise<T> {
  let lastErr: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (err) {
      const isRetryable = err instanceof FirecrawlError && err.retryable;
      if (isRetryable && attempt < maxAttempts) {
        const delay = baseDelayMs * attempt;
        console.log(`    ↻ ${label} rate-limited — retry ${attempt}/${maxAttempts - 1} in ${delay / 1000}s`);
        await new Promise((res) => setTimeout(res, delay));
        lastErr = err;
        continue;
      }
      throw err;
    }
  }
  throw lastErr;
}

// ---------------------------------------------------------------------------
// Scoring (matches lead-scoring skill model exactly)
// ---------------------------------------------------------------------------

interface TargetScore {
  domain: string;
  domainId: string;
  score: number;
  tier: "HIGH" | "MODERATE" | "LOW";
  breakdown: {
    compliance_failure_density: number;
    content_gap_density: number;
    pricing_opacity_flag: number;
    policy_absence_flag: number;
    schema_quality_fail: number;
  };
  topSignals: string[];
  recommendation: string;
  findingIds: string[];
  gapIds: string[];
}

function scoreTarget(
  domainState: DomainState,
  findings: Array<RuleViolation & { id: string; domain: string }>,
  gapCount: number,
): TargetScore {
  const domainFindings = findings.filter((f) => f.domain === domainState.domain);
  const pages = domainState.pageCount || 1;

  const highFindings = domainFindings.filter((f) => f.severity === "high").length;
  const complianceDensity = Math.min(30, (highFindings / pages) * 30);
  const gapDensity = Math.min(20, (gapCount / pages) * 20);
  const pricingOpacity = domainFindings.some((f) => f.rule_family === "pricing_transparency") ? 20 : 0;
  const policyAbsence = domainFindings.some((f) => f.rule_family === "policy_coherence" || f.rule_family === "privacy_presence") ? 15 : 0;
  const schemaFail = domainFindings.some((f) => f.rule_family === "schema_quality") ? 15 : 0;

  const total = Math.min(100, Math.round(complianceDensity + gapDensity + pricingOpacity + policyAbsence + schemaFail));
  const tier: "HIGH" | "MODERATE" | "LOW" = total >= 70 ? "HIGH" : total >= 40 ? "MODERATE" : "LOW";

  const topSignals = domainFindings
    .filter((f) => f.severity === "high")
    .slice(0, 3)
    .map((f) => `${f.rule_family} — ${f.description.slice(0, 80)}`);

  return {
    domain: domainState.domain,
    domainId: domainState.id,
    score: total,
    tier,
    breakdown: {
      compliance_failure_density: Math.round(complianceDensity),
      content_gap_density: Math.round(gapDensity),
      pricing_opacity_flag: pricingOpacity,
      policy_absence_flag: policyAbsence,
      schema_quality_fail: schemaFail,
    },
    topSignals,
    recommendation: `Web signals show ${domainFindings.length} findings across ${pages} pages for ${domainState.domain}.`,
    findingIds: domainFindings.map((f) => f.id),
    gapIds: [],
  };
}

// ---------------------------------------------------------------------------
// Brief generator
// ---------------------------------------------------------------------------

function generateBrief(
  config: PipelineConfig,
  runId: string,
  domains: DomainState[],
  findings: Array<RuleViolation & { id: string; domain: string }>,
  targets: TargetScore[],
): string {
  const now = new Date().toISOString().slice(0, 10);
  const high = findings.filter((f) => f.severity === "high");
  const highTargets = targets.filter((t) => t.tier === "HIGH");

  const lines: string[] = [
    `# Weekly Executive Brief`,
    ``,
    `**Metro:** ${config.metro}  `,
    `**Week ending:** ${now}  `,
    `**Run:** ${runId}  `,
    `**Status:** draft — pending reviewer approval`,
    ``,
    `---`,
    ``,
    `## Headline Metrics`,
    ``,
    `| Metric | Value |`,
    `|--------|-------|`,
    `| Domains monitored | ${domains.length} |`,
    `| Compliance findings | ${findings.length} |`,
    `| High severity | ${high.length} |`,
    `| Acquisition targets | ${targets.length} |`,
    `| HIGH signal targets | ${highTargets.length} |`,
    ``,
    `---`,
    ``,
    `## Market Intelligence`,
    ``,
    `${domains.length} competitor domains were active in ${config.metro} this week. ` +
    `${domains.filter((d) => d.findingCount > 0).length} domains produced compliance findings.`,
    ``,
    `| Domain | Pages | Findings |`,
    `|--------|-------|----------|`,
    ...domains.map((d) => `| ${d.domain} | ${d.pageCount} | ${d.findingCount} |`),
    ``,
    `---`,
    ``,
    `## Compliance Findings`,
    ``,
    `${findings.length} findings produced this week. ${high.length} are high severity and require priority review.`,
    ``,
    ...findings.map((f, i) =>
      `### Finding ${String(i + 1).padStart(3, "0")} · ${f.id}\n\n` +
      `- **Domain:** ${f.domain}\n` +
      `- **Rule family:** ${f.rule_family}\n` +
      `- **Severity:** ${f.severity}\n` +
      `- **Result:** ${f.result}\n` +
      `- **Confidence:** ${f.confidence}\n` +
      `- **Status:** ${f.reviewer_status}\n` +
      `- **Description:** ${f.description}\n` +
      `- **Snippet:** \`${f.snippet.slice(0, 150)}\`\n` +
      `- **Source:** ${f.source_url}\n`
    ),
    `---`,
    ``,
    `## Acquisition Targets`,
    ``,
    `${targets.length} domains scored. ${highTargets.length} are HIGH signal.`,
    ``,
    `| Domain | Score | Tier | Findings |`,
    `|--------|-------|------|----------|`,
    ...targets
      .sort((a, b) => b.score - a.score)
      .map((t) => `| ${t.domain} | ${t.score}/100 | ${t.tier} | ${t.findingIds.length} |`),
    ``,
    ...targets
      .filter((t) => t.tier === "HIGH")
      .map((t) =>
        `### ${t.domain} — Score ${t.score}/100 (${t.tier})\n\n` +
        `${t.recommendation}\n\n` +
        (t.topSignals.length ? t.topSignals.map((s) => `- ${s}`).join("\n") + "\n" : "")
      ),
    `---`,
    ``,
    `*This brief is a draft. All findings require reviewer approval before publication.*`,
    `*No finding may be published without evidence. No paragraph may be exported without citation.*`,
  ];

  return lines.join("\n");
}

// ---------------------------------------------------------------------------
// Fixture capture (per-page snapshots for golden-set eval replay)
// ---------------------------------------------------------------------------

interface PageFixture {
  fixture_id: string;
  run_id: string;
  domain: string;
  domain_id: string;
  page_id: string;
  url: string;
  content_type: string;
  text_content: string | null;
  normalized: ReturnType<typeof normalizeSourcePage>;
  findings: Array<RuleViolation & { id: string; domain: string }>;
  scraped_at: string;
}

function captureFixture(fixturesDir: string, fixture: PageFixture): void {
  const filename = `${fixture.run_id}__${fixture.domain_id}__${fixture.page_id}.json`;
  writeFileSync(join(fixturesDir, filename), JSON.stringify(fixture, null, 2));
}

// ---------------------------------------------------------------------------
// Main pipeline runner
// ---------------------------------------------------------------------------

export async function runPipeline(
  client: FirecrawlClient,
  config: PipelineConfig,
): Promise<void> {
  // Human-readable run ID for file paths and display. The DB run gets a UUID.
  const runId = `run_${new Date().toISOString().slice(0, 10).replace(/-/g, "_")}_${randomUUID().slice(0, 8)}`;
  const maxUrls = config.maxUrlsPerDomain ?? 5;

  if (config.fixturesDir) {
    mkdirSync(config.fixturesDir, { recursive: true });
  }

  console.log(`\n═══════════════════════════════════════════════`);
  console.log(`  CompliCore Pipeline  ·  ${config.metro}`);
  console.log(`  Run: ${runId}`);
  console.log(`═══════════════════════════════════════════════\n`);

  // ── DB: insert run row ────────────────────────────────────────────────────
  let dbCtx: DbContext | null = null;
  if (config.db != null && config.workspaceId != null) {
    const runRow = await insertRun(config.db, {
      workspace_id: config.workspaceId,
      metro: config.metro,
    });
    await setRunStatus(config.db, runRow.id, {
      status: "running",
      started_at: new Date().toISOString(),
    });
    await insertAuditEvent(config.db, {
      workspace_id: config.workspaceId,
      run_id: runRow.id,
      actor: "system",
      action: "run.started",
      entity_type: "run",
      entity_id: runRow.id,
      payload: { metro: config.metro, human_run_id: runId },
    });
    dbCtx = { db: config.db, workspaceId: config.workspaceId, runId: runRow.id };
    console.log(`  DB run: ${runRow.id}\n`);
  }

  try {
    // ── STEP 1: discover ────────────────────────────────────────────────────
    console.log(`[1/7] discover — searching for competitors in ${config.metro}`);
    let discoverStepId: string | null = null;
    if (dbCtx != null) {
      const stepRow = await insertStep(dbCtx.db, {
        run_id: dbCtx.runId,
        name: "discover",
        input_count: 0,
      });
      discoverStepId = stepRow.id;
    }
    const discovered = await discoverDomains(client, {
      metro: config.metro,
      operatorDomain: config.operatorDomain,
      limit: 20,
    });
    if (dbCtx != null && discoverStepId != null) {
      await setStepStatus(dbCtx.db, discoverStepId, {
        status: "completed",
        output_count: discovered.domains.length,
      });
    }
    console.log(`      → ${discovered.domains.length} domains found\n`);

    // Accumulated state
    const domainStates: DomainState[] = [];
    const allFindings: Array<RuleViolation & { id: string; domain: string }> = [];
    const allGapsByDomain: Record<string, number> = {};

    for (const discovered_domain of discovered.domains) {
      const memDomainId = `dom_${randomUUID().slice(0, 8)}`;
      const { domain } = discovered_domain;

      console.log(`  ┌─ ${domain}`);

      let dbDomainId: string | null = null;
      try {

      // ── DB: insert domain ─────────────────────────────────────────────────
      if (dbCtx != null) {
        const domainRow = await insertDomain(dbCtx.db, {
          run_id: dbCtx.runId,
          domain,
          status: "mapped",
        });
        dbDomainId = domainRow.id;
        await insertAuditEvent(dbCtx.db, {
          workspace_id: dbCtx.workspaceId,
          run_id: dbCtx.runId,
          actor: "system",
          action: "domain.discovered",
          entity_type: "domain",
          entity_id: dbDomainId,
          payload: { domain },
        });
      }
      const effectiveDomainId = dbDomainId ?? memDomainId;

      // ── STEP 2: map ───────────────────────────────────────────────────────
      process.stdout.write(`  │  [2/7] map `);
      const mapped = await withRetry(
        () => mapDomain(client, { domain, domainId: effectiveDomainId, limit: 100 }),
        "map",
      );
      console.log(`→ ${mapped.urls.length} URLs`);

      const urlsToProcess = mapped.urls.slice(0, maxUrls);

      // ── STEP 3: classify ──────────────────────────────────────────────────
      process.stdout.write(`  │  [3/7] classify `);
      const classified = urlsToProcess.map((u) => ({
        ...u,
        classification: classifyPage(u.url),
      }));
      const scrapeable = classified.filter(
        (u) => !["gated_dynamic", "blog_content", "other"].includes(u.classification.page_type)
      );
      console.log(`→ ${scrapeable.length}/${classified.length} scrapeable`);

      let pageCount = 0;
      let domainFindingCount = 0;
      let domainGapCount = 0;
      const domainDbFindingIds: string[] = [];
      const domainDbGapIds: string[] = [];

      for (const urlRecord of scrapeable) {
        // ── DB: insert source_url ───────────────────────────────────────────
        let dbUrlId: string | null = null;
        if (dbCtx != null && dbDomainId != null) {
          const urlRow = await insertSourceUrl(dbCtx.db, {
            domain_id: dbDomainId,
            url: urlRecord.url,
            content_type_hint: urlRecord.classification.page_type,
            depth: 1,
            status: "scraped",
          });
          dbUrlId = urlRow.id;
        }
        const memUrlId = `url_${randomUUID().slice(0, 8)}`;
        const effectiveUrlId = dbUrlId ?? memUrlId;

        // ── STEP 4: scrape ────────────────────────────────────────────────
        const scrapeResult = await withRetry(
          () => scrapePage(client, {
            urlId: effectiveUrlId,
            domainId: effectiveDomainId,
            url: urlRecord.url,
            contentType: urlRecord.classification.page_type,
            captureScreenshot: true,
          }),
          "scrape",
        );

        // ── DB: insert source_page ──────────────────────────────────────────
        // Insert before building the sourcePage object so we get the DB UUID.
        let dbPageId: string | null = null;
        if (dbCtx != null && dbDomainId != null && dbUrlId != null) {
          const pageRow = await insertSourcePage(dbCtx.db, {
            url_id: dbUrlId,
            domain_id: dbDomainId,
            url: urlRecord.url,
            raw_html: scrapeResult.sourcePage.raw_html ?? undefined,
            text_content: scrapeResult.sourcePage.text_content ?? undefined,
            http_status: scrapeResult.sourcePage.http_status,
            content_type: urlRecord.classification.page_type,
            word_count: scrapeResult.sourcePage.word_count ?? undefined,
          });
          dbPageId = pageRow.id;
        }
        const effectivePageId = dbPageId ?? `page_${randomUUID().slice(0, 8)}`;

        // Build sourcePage with effective (DB or in-memory) IDs.
        // The rules engine receives the DB UUID in page.id when persist is active.
        const sourcePage: SourcePage & { id: string } = {
          id: effectivePageId,
          url_id: effectiveUrlId,
          domain_id: effectiveDomainId,
          url: urlRecord.url,
          raw_html: scrapeResult.sourcePage.raw_html,
          text_content: scrapeResult.sourcePage.text_content,
          http_status: scrapeResult.sourcePage.http_status,
          scraped_at: scrapeResult.sourcePage.scraped_at,
          content_type: urlRecord.classification.page_type,
          word_count: scrapeResult.sourcePage.word_count,
        };

        // ── STEP 5: normalize ─────────────────────────────────────────────
        const normalized = normalizeSourcePage(sourcePage);
        domainGapCount += normalized.content_gaps.length;
        pageCount++;

        // ── DB: insert observations ────────────────────────────────────────
        if (dbCtx != null && dbDomainId != null && dbPageId != null) {
          if (normalized.listing != null) {
            await insertListing(dbCtx.db, {
              source_page_id: dbPageId,
              domain_id: dbDomainId,
              unit_name: normalized.listing.unit_name ?? null,
              bedroom_count: normalized.listing.bedroom_count ?? null,
              bathroom_count: normalized.listing.bathroom_count ?? null,
              square_footage: normalized.listing.square_footage ?? null,
              amenities: normalized.listing.amenities,
              minimum_stay_nights: normalized.listing.minimum_stay_nights ?? null,
              availability_mentioned: normalized.listing.availability_mentioned,
            });
          }
          for (const po of normalized.pricing_observations) {
            await insertPricingObservation(dbCtx.db, {
              source_page_id: dbPageId,
              domain_id: dbDomainId,
              price_raw: po.price_raw,
              price_numeric: po.price_numeric ?? null,
              price_unit: po.price_unit,
              fees_mentioned: po.fees_mentioned,
              total_cost_shown: po.total_cost_shown,
              price_quote: po.price_quote,
            });
          }
          for (const pol of normalized.policy_observations) {
            await insertPolicyObservation(dbCtx.db, {
              source_page_id: dbPageId,
              domain_id: dbDomainId,
              policy_type: pol.policy_type,
              policy_summary: pol.policy_summary,
              policy_url: pol.policy_url ?? null,
            });
          }
          if (normalized.schema_observation != null) {
            await insertSchemaObservation(dbCtx.db, {
              source_page_id: dbPageId,
              has_structured_data: normalized.schema_observation.has_structured_data,
              schema_types_found: normalized.schema_observation.schema_types_found,
              title_present: normalized.schema_observation.title_present,
              meta_description_present: normalized.schema_observation.meta_description_present,
            });
          }
          for (const gap of normalized.content_gaps) {
            const gapRow = await insertContentGap(dbCtx.db, {
              source_page_id: dbPageId,
              domain_id: dbDomainId,
              gap_type: gap.gap_type,
              description: gap.description,
            });
            domainDbGapIds.push(gapRow.id);
          }
        }

        // ── STEP 6: rules ─────────────────────────────────────────────────
        const ruleResults = evaluateAllRules({
          run_id: runId,
          domain_id: effectiveDomainId,
          page: sourcePage,
          normalized,
          screenshot_ref: scrapeResult.screenshot?.file_ref ?? null,
        });

        const violations = collectViolations(ruleResults);
        const pageFindings: Array<RuleViolation & { id: string; domain: string }> = [];
        // Deduplicate: one finding per (page, rule_family).
        const seenRuleFamilies = new Set<string>();

        for (const v of violations) {
          const dedupKey = `${effectivePageId}:${v.rule_family}`;
          if (seenRuleFamilies.has(dedupKey)) continue;
          seenRuleFamilies.add(dedupKey);

          const finding = { ...v, id: `cf_${randomUUID().slice(0, 8)}`, domain };
          allFindings.push(finding);
          pageFindings.push(finding);
          domainFindingCount++;

          // ── DB: insert compliance_finding ─────────────────────────────────
          // result:       "fail" | "uncertain_needs_review"
          //               ↓ toFindingResult ↓
          // rule_result:  "FAIL" | "WARN"
          //
          // reviewer_status: propagated from violation (pending | needs_review)
          if (dbCtx != null && dbDomainId != null && dbPageId != null) {
            // Strip inline base64 screenshots (mock client placeholder) — store null instead.
            const screenshotRef =
              v.screenshot_ref != null && v.screenshot_ref.startsWith("data:")
                ? null
                : v.screenshot_ref;
            const findingRow = await insertFinding(dbCtx.db, {
              source_page_id: dbPageId,
              domain_id: dbDomainId,
              run_id: dbCtx.runId,
              rule_family: v.rule_family,
              rule_result: toFindingResult(v.result),
              severity: v.severity,
              description: v.description,
              source_url: v.source_url,
              screenshot_ref: screenshotRef,
              snippet: v.snippet,
              confidence: v.confidence,
              reviewer_status: v.reviewer_status,
            });
            domainDbFindingIds.push(findingRow.id);
          }
        }

        // Capture per-page fixture for golden-set eval replay
        if (config.fixturesDir) {
          captureFixture(config.fixturesDir, {
            fixture_id: `fix_${randomUUID().slice(0, 8)}`,
            run_id: runId,
            domain,
            domain_id: effectiveDomainId,
            page_id: effectivePageId,
            url: urlRecord.url,
            content_type: urlRecord.classification.page_type,
            text_content: sourcePage.text_content,
            normalized,
            findings: pageFindings,
            scraped_at: sourcePage.scraped_at,
          });
        }
      }

      // ── DB: mark domain crawled ─────────────────────────────────────────
      if (dbCtx != null && dbDomainId != null) {
        await setDomainStatus(dbCtx.db, dbDomainId, {
          status: "mapped",
          crawled_at: new Date().toISOString(),
        });
        await insertAuditEvent(dbCtx.db, {
          workspace_id: dbCtx.workspaceId,
          run_id: dbCtx.runId,
          actor: "system",
          action: "domain.crawled",
          entity_type: "domain",
          entity_id: dbDomainId,
          payload: {
            page_count: pageCount,
            finding_count: domainFindingCount,
            gap_count: domainGapCount,
          },
        });
      }

      allGapsByDomain[domain] = domainGapCount;
      domainStates.push({
        id: memDomainId,
        dbId: dbDomainId,
        domain,
        pageCount,
        findingCount: domainFindingCount,
        gapCount: domainGapCount,
        dbFindingIds: domainDbFindingIds,
        dbGapIds: domainDbGapIds,
      });
      console.log(`  └─ ${pageCount} pages · ${domainFindingCount} findings · ${domainGapCount} gaps\n`);

      } catch (domainErr) {
        const isRateLimit =
          domainErr instanceof FirecrawlError && domainErr.retryable;
        const label = isRateLimit ? "rate-limited" : "error";
        const msg = domainErr instanceof Error ? domainErr.message : String(domainErr);
        console.log(`  └─ skipped (${label}): ${msg}\n`);

        if (dbCtx != null && dbDomainId != null) {
          await setDomainStatus(dbCtx.db, dbDomainId, { status: "unreachable" });
        }

        if (dbCtx != null) {
          await insertAuditEvent(dbCtx.db, {
            workspace_id: dbCtx.workspaceId,
            run_id: dbCtx.runId,
            actor: "system",
            action: "domain.skipped",
            entity_type: "domain",
            entity_id: domain,
            payload: { reason: label, error: msg },
          });
        }
      }

    } // end for discovered_domain

    // ── STEP 7: brief ───────────────────────────────────────────────────────
    console.log(`[7/7] brief — scoring targets and generating outputs`);

    const targets: TargetScore[] = domainStates
      .filter((d) => d.pageCount > 0)
      .map((d) => scoreTarget(d, allFindings, allGapsByDomain[d.domain] ?? 0))
      .sort((a, b) => b.score - a.score);

    // ── DB: insert opportunity_targets + outbound briefs ───────────────────
    if (dbCtx != null) {
      for (const target of targets) {
        const ds = domainStates.find((d) => d.domain === target.domain);
        if (ds?.dbId != null) {
          const targetRow = await insertOpportunityTarget(dbCtx.db, {
            domain_id: ds.dbId,
            run_id: dbCtx.runId,
            score: target.score,
            signal_tier: target.tier,
            score_breakdown: target.breakdown,
            contributing_finding_ids: ds.dbFindingIds,
            contributing_gap_ids: ds.dbGapIds,
            top_signals: target.topSignals,
            recommendation: target.recommendation,
          });

          // Generate outbound brief for HIGH + MODERATE targets only
          if (target.tier === "HIGH" || target.tier === "MODERATE") {
            const domainFindings = allFindings.filter((f) => f.domain === target.domain);
            const briefContent = generateOutboundBriefContent({
              domain: target.domain,
              score: target.score,
              tier: target.tier,
              topSignals: target.topSignals,
              recommendation: target.recommendation,
              findings: domainFindings,
              operatorDomain: config.operatorDomain,
              metro: config.metro,
            });
            await insertOutboundBrief(dbCtx.db, {
              run_id: dbCtx.runId,
              opportunity_target_id: targetRow.id,
              content: briefContent,
            });
          }
        }
      }
    }

    let briefStepId: string | null = null;
    if (dbCtx != null) {
      const stepRow = await insertStep(dbCtx.db, {
        run_id: dbCtx.runId,
        name: "brief",
        input_count: allFindings.length,
      });
      briefStepId = stepRow.id;
    }
    const brief = generateBrief(config, runId, domainStates, allFindings, targets);

    // ── Write JSON + markdown outputs (secondary artifacts) ─────────────────
    const exportsDir = join(config.outputDir, "exports");
    const reportsDir = join(config.outputDir, "reports");
    mkdirSync(exportsDir, { recursive: true });
    mkdirSync(reportsDir, { recursive: true });

    const findingsPath = join(exportsDir, "findings.json");
    const targetsPath = join(exportsDir, "targets.json");
    const briefPath = join(reportsDir, "weekly_brief.md");

    writeFileSync(findingsPath, JSON.stringify(allFindings, null, 2));
    writeFileSync(targetsPath, JSON.stringify(targets, null, 2));
    writeFileSync(briefPath, brief);

    // ── DB: insert report row ───────────────────────────────────────────────
    if (dbCtx != null) {
      const reportRow = await insertReport(dbCtx.db, {
        run_id: dbCtx.runId,
        workspace_id: dbCtx.workspaceId,
        type: "weekly_brief",
        metro: config.metro,
      });
      await insertAuditEvent(dbCtx.db, {
        workspace_id: dbCtx.workspaceId,
        run_id: dbCtx.runId,
        actor: "system",
        action: "report.created",
        entity_type: "report",
        entity_id: reportRow.id,
        payload: {
          type: "weekly_brief",
          finding_count: allFindings.length,
          target_count: targets.length,
          brief_path: briefPath,
        },
      });
      if (briefStepId != null) {
        await setStepStatus(dbCtx.db, briefStepId, {
          status: "completed",
          output_count: 1,
        });
      }
    }

    // ── DB: mark run completed ──────────────────────────────────────────────
    if (dbCtx != null) {
      await setRunStatus(dbCtx.db, dbCtx.runId, {
        status: "completed",
        completed_at: new Date().toISOString(),
      });
      await insertAuditEvent(dbCtx.db, {
        workspace_id: dbCtx.workspaceId,
        run_id: dbCtx.runId,
        actor: "system",
        action: "run.completed",
        entity_type: "run",
        entity_id: dbCtx.runId,
        payload: {
          domain_count: domainStates.length,
          finding_count: allFindings.length,
          target_count: targets.length,
        },
      });
    }

    console.log(`\n───────────────────────────────────────────────`);
    console.log(`  Run complete: ${runId}`);
    if (dbCtx != null) console.log(`  DB run:    ${dbCtx.runId}`);
    console.log(`  Domains:   ${domainStates.length}`);
    console.log(`  Findings:  ${allFindings.length} (${allFindings.filter((f) => f.severity === "high").length} high)`);
    console.log(`  Targets:   ${targets.length} (${targets.filter((t) => t.tier === "HIGH").length} HIGH)`);
    console.log(`  Output:`);
    console.log(`    ${findingsPath}`);
    console.log(`    ${targetsPath}`);
    console.log(`    ${briefPath}`);
    console.log(`───────────────────────────────────────────────\n`);
  } catch (err) {
    // ── DB: mark run failed ─────────────────────────────────────────────────
    if (dbCtx != null) {
      const errMsg = err instanceof Error ? err.message : String(err);
      await setRunStatus(dbCtx.db, dbCtx.runId, {
        status: "failed",
        error: errMsg,
        completed_at: new Date().toISOString(),
      });
      await insertAuditEvent(dbCtx.db, {
        workspace_id: dbCtx.workspaceId,
        run_id: dbCtx.runId,
        actor: "system",
        action: "run.failed",
        entity_type: "run",
        entity_id: dbCtx.runId,
        payload: { error: errMsg },
      });
    }
    throw err;
  }
}
