/**
 * Entry point: pnpm --filter @complicore/worker pipeline
 *
 * Modes:
 *   FIRECRAWL_API_KEY not set → mock client (fast, no network)
 *   FIRECRAWL_API_KEY set     → real Firecrawl client
 *
 *   DATABASE_URL not set      → in-memory only, JSON output
 *   DATABASE_URL set          → persists to Postgres + JSON output
 *
 * Workspace resolution (when DATABASE_URL is set):
 *   WORKSPACE_ID set          → use that workspace
 *   WORKSPACE_ID not set      → auto-provision a workspace and print the ID
 *                               Set WORKSPACE_ID=<id> to reuse it next run.
 */

import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { runPipeline } from "./pipeline.js";
import { createMockClient } from "./mock-client.js";
import { createClient } from "@complicore/firecrawl/client";
import type { PipelineConfig } from "./pipeline.js";

const __dirname = dirname(fileURLToPath(import.meta.url));

const apiKey = process.env["FIRECRAWL_API_KEY"];
const client = apiKey ? createClient({ apiKey }) : createMockClient();

if (apiKey) {
  console.log("Using real Firecrawl client.");
} else {
  console.log("FIRECRAWL_API_KEY not set — using mock client.");
}

const metro = process.env["METRO"] ?? "Austin, TX";
const operatorDomain = process.env["OPERATOR_DOMAIN"] ?? "mycompany.com";

const config: PipelineConfig = {
  metro,
  operatorDomain,
  outputDir: join(__dirname, "../output"),
  fixturesDir: join(__dirname, "../../../datasets/fixtures"),
  maxUrlsPerDomain: 5,
};

// ── DB wiring (optional) ──────────────────────────────────────────────────
if (process.env["DATABASE_URL"]) {
  const { getDb } = await import("@complicore/core/db/client");
  const db = getDb();

  let workspaceId = process.env["WORKSPACE_ID"];

  if (workspaceId == null) {
    // Auto-provision a workspace with the pipeline defaults.
    // The caller should save the printed WORKSPACE_ID for subsequent runs.
    const { workspaces } = await import("@complicore/core/db/schema");
    const rows = await db
      .insert(workspaces)
      .values({ name: "CompliCore v1", metro, operator_domain: operatorDomain })
      .returning();
    const ws = rows[0];
    if (ws == null) throw new Error("insertWorkspace: no row returned");
    workspaceId = ws.id;
    console.log(`Provisioned workspace: ${workspaceId}`);
    console.log(`  → set WORKSPACE_ID=${workspaceId} to reuse on subsequent runs\n`);
  } else {
    console.log(`Using workspace: ${workspaceId}`);
  }

  config.db = db;
  config.workspaceId = workspaceId;
} else {
  console.log("DATABASE_URL not set — running in-memory only.\n");
}

await runPipeline(client, config);
