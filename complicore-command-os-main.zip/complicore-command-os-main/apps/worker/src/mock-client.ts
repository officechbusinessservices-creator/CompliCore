/**
 * Mock Firecrawl client for pipeline development without API credits.
 * Returns deterministic fixture data keyed by domain.
 */

import type {
  FirecrawlClient,
  FirecrawlScrapeResponse,
  FirecrawlMapResponse,
  FirecrawlSearchResponse,
  FirecrawlCrawlStartResponse,
  FirecrawlCrawlStatusResponse,
} from "@complicore/firecrawl/client";

// ---------------------------------------------------------------------------
// Per-domain page fixtures
// ---------------------------------------------------------------------------

const DOMAIN_PAGES: Record<string, Array<{ url: string; markdown: string; html: string }>> = {
  "capitalcityliving.com": [
    {
      url: "https://capitalcityliving.com/",
      markdown: "# Capital City Living — Austin Corporate Housing\n\nFurnished apartments for business travelers.\n\nCall us or fill out the form below.",
      html: '<html><head><title>Capital City Living</title></head><body><h1>Capital City Living</h1></body></html>',
    },
    {
      url: "https://capitalcityliving.com/listings/downtown-studio",
      markdown: "# Downtown Studio\n\nContact us for pricing.\n\n1 bedroom. 1 bathroom. 480 sq ft.\n\nAmenities: WiFi, washer/dryer, parking.",
      html: '<html><head><title>Downtown Studio</title></head><body></body></html>',
    },
    {
      url: "https://capitalcityliving.com/listings/south-congress-1br",
      markdown: "# South Congress 1BR\n\nContact us for pricing.\n\n1 bedroom. 1 bathroom. 650 sq ft.\n\nAmenities: WiFi, gym access, rooftop.",
      html: '<html><head><title>South Congress 1BR</title></head><body></body></html>',
    },
    {
      url: "https://capitalcityliving.com/contact",
      markdown: "# Contact\n\nFill out the form below and we will get back to you.\n\nNo phone number listed.",
      html: '<html><head><title>Contact</title></head><body><form><input name="email"/></form></body></html>',
    },
    {
      url: "https://capitalcityliving.com/terms",
      markdown: "# Terms\n\nSee our cancellation policy.\n\nNote: cancellation policy page is unavailable.",
      html: '<html><head><title>Terms</title></head><body></body></html>',
    },
  ],
  "sixthstreetsuites.com": [
    {
      url: "https://sixthstreetsuites.com/",
      markdown: "# Sixth Street Suites — Short Term Rentals Austin\n\nPremium furnished suites.",
      html: '<html><head><title>Sixth Street Suites</title></head><body></body></html>',
    },
    {
      url: "https://sixthstreetsuites.com/suites/lady-bird-one-bed",
      markdown: "# Lady Bird One Bedroom\n\nFrom $3,200–$4,100/mo.\n\n1 bedroom. 1 bathroom. 720 sq ft.\n\nAmenities: WiFi, balcony, concierge.",
      html: '<html><head><title>Lady Bird Suite</title></head><body></body></html>',
    },
    {
      url: "https://sixthstreetsuites.com/contact",
      markdown: "# Contact\n\nEmail us at hello@sixthstreetsuites.com\n\nName, email, and phone required.",
      html: '<html><head><title>Contact</title></head><body><form><input name="phone"/></form></body></html>',
    },
    {
      url: "https://sixthstreetsuites.com/pricing",
      markdown: "# Pricing\n\nSuites from $3,200/month. Range varies by floor and season.\n\nCleaning fee charged separately. Amount varies.",
      html: '<html><head><title>Pricing</title></head><body></body></html>',
    },
  ],
  "austinstays.com": [
    {
      url: "https://austinstays.com/",
      markdown: "# Austin Stays — Furnished Monthly Apartments\n\nPrivacy policy | Terms of service\n\nContact: 512-555-0100\n\nReviews: ★★★★☆ 4.6 from 312 guests",
      html: '<html><head><title>Austin Stays</title><meta name="description" content="Furnished apartments Austin"/><script type="application/ld+json">{"@context":"https://schema.org","@type":"LodgingBusiness","name":"Austin Stays"}</script></head><body></body></html>',
    },
    {
      url: "https://austinstays.com/listings/south-congress-2br",
      markdown: "# South Congress 2BR\n\nFrom $4,800/month. Cleaning fee: $200.\n\n2 bedrooms. 2 bathrooms. 1,100 sq ft.\n\nCancellation policy: 30-day notice required.\n\nAmenities: WiFi, parking, in-unit laundry.\n\nContact us: 512-555-0100",
      html: '<html><head><title>South Congress 2BR</title><script type="application/ld+json">{"@context":"https://schema.org","@type":"Accommodation","name":"South Congress 2BR"}</script></head><body></body></html>',
    },
    {
      url: "https://austinstays.com/privacy-policy",
      markdown: "# Privacy Policy\n\nWe collect your name, email, and phone for booking purposes. Data is not sold to third parties.",
      html: '<html><head><title>Privacy Policy</title></head><body></body></html>',
    },
    {
      url: "https://austinstays.com/terms",
      markdown: "# Terms and Conditions\n\nCancellation policy: 30-day notice required for full refund. 14-day notice for 50% refund.",
      html: '<html><head><title>Terms</title></head><body></body></html>',
    },
  ],
};

const DOMAIN_URLS: Record<string, string[]> = {
  "capitalcityliving.com": [
    "https://capitalcityliving.com/",
    "https://capitalcityliving.com/listings/downtown-studio",
    "https://capitalcityliving.com/listings/south-congress-1br",
    "https://capitalcityliving.com/contact",
    "https://capitalcityliving.com/terms",
  ],
  "sixthstreetsuites.com": [
    "https://sixthstreetsuites.com/",
    "https://sixthstreetsuites.com/suites/lady-bird-one-bed",
    "https://sixthstreetsuites.com/contact",
    "https://sixthstreetsuites.com/pricing",
  ],
  "austinstays.com": [
    "https://austinstays.com/",
    "https://austinstays.com/listings/south-congress-2br",
    "https://austinstays.com/privacy-policy",
    "https://austinstays.com/terms",
  ],
};

// ---------------------------------------------------------------------------
// Mock client factory
// ---------------------------------------------------------------------------

export function createMockClient(): FirecrawlClient {
  return {
    async search(_query, options) {
      const limit = options?.limit ?? 5;
      const results = [
        { url: "https://capitalcityliving.com", title: "Capital City Living — Austin Corporate Housing", description: "Furnished apartments for business travelers in Austin" },
        { url: "https://sixthstreetsuites.com", title: "Sixth Street Suites — Short Term Rentals", description: "Premium furnished suites in downtown Austin" },
        { url: "https://austinstays.com", title: "Austin Stays — Furnished Monthly Apartments", description: "Monthly furnished rentals from $2,800" },
      ].slice(0, limit);
      return { success: true, data: results } satisfies FirecrawlSearchResponse;
    },

    async map(url, _options) {
      const domain = new URL(url).hostname.replace(/^www\./, "");
      const links = DOMAIN_URLS[domain] ?? [url];
      return { success: true, links } satisfies FirecrawlMapResponse;
    },

    async scrape(url, _options) {
      const domain = new URL(url).hostname.replace(/^www\./, "");
      const pages = DOMAIN_PAGES[domain] ?? [];
      const page = pages.find((p) => p.url === url);

      return {
        success: true,
        data: {
          markdown: page?.markdown ?? `# Page\n\nContent at ${url}`,
          html: page?.html ?? `<html><head><title>Page</title></head><body></body></html>`,
          screenshot: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
          metadata: { sourceURL: url, statusCode: 200 },
        },
      } satisfies FirecrawlScrapeResponse;
    },

    async crawlStart(_url, _options) {
      return { success: true, id: "mock-crawl-001", url: "mock" } satisfies FirecrawlCrawlStartResponse;
    },

    async crawlStatus(_id) {
      return { status: "completed", total: 0, completed: 0, creditsUsed: 0, expiresAt: new Date().toISOString() } satisfies FirecrawlCrawlStatusResponse;
    },
  };
}
