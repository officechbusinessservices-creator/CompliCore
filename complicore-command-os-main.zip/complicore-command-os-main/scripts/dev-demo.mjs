#!/usr/bin/env node
/**
 * scripts/dev-demo.mjs
 *
 * Runs the full CompliCore demo in one command:
 *   pnpm dev:demo
 *
 * Steps:
 *   1. Load + validate environment (.env.local at repo root)
 *   2. Run DB migrations  (drizzle-kit migrate, packages/core)
 *   3. Run pipeline once  (worker — uses mock client if no FIRECRAWL_API_KEY)
 *   4. Start web app      (apps/web — next dev)
 *
 * Required env vars (in .env.local at repo root):
 *   DATABASE_URL   — Neon (or any Postgres) connection string
 *
 * Optional env vars:
 *   FIRECRAWL_API_KEY — if absent, mock client is used (fast, no network)
 *   WORKSPACE_ID      — reuse an existing workspace across runs
 */

import { spawnSync, spawn } from "node:child_process";
import { readFileSync, existsSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const SCRIPT_DIR = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(SCRIPT_DIR, "..");
const ENV_FILE = resolve(ROOT, ".env.local");

const OFFLINE = process.argv.includes("--offline");

// ── Colours ──────────────────────────────────────────────────────────────────
const c = {
  reset: "\x1b[0m",
  dim: "\x1b[2m",
  bold: "\x1b[1m",
  green: "\x1b[32m",
  red: "\x1b[31m",
  yellow: "\x1b[33m",
  cyan: "\x1b[36m",
};

function step(n, label) {
  console.log(`\n${c.bold}${c.cyan}[${n}/3]${c.reset} ${label}`);
}

function ok(msg) {
  console.log(`${c.green}✓${c.reset} ${msg}`);
}

function fail(msg, hint) {
  console.error(`\n${c.red}✖ ${msg}${c.reset}`);
  if (hint) console.error(`  ${c.dim}${hint}${c.reset}`);
  process.exit(1);
}

// ── Load .env.local ───────────────────────────────────────────────────────────
if (!existsSync(ENV_FILE)) {
  fail(
    ".env.local not found at repo root.",
    "Create .env.local and set DATABASE_URL=postgresql://..."
  );
}

const env = { ...process.env };

for (const raw of readFileSync(ENV_FILE, "utf8").split("\n")) {
  const line = raw.trim();
  if (!line || line.startsWith("#")) continue;
  const eq = line.indexOf("=");
  if (eq === -1) continue;
  const key = line.slice(0, eq).trim();
  const val = line.slice(eq + 1).trim();
  // Shell env takes precedence over .env.local
  if (env[key] == null || env[key] === "") env[key] = val;
}

// ── Validate required vars ────────────────────────────────────────────────────
if (!env["DATABASE_URL"]) {
  fail(
    "DATABASE_URL is not set.",
    "Add DATABASE_URL=postgresql://... to .env.local at repo root."
  );
}

if (!env["FIRECRAWL_API_KEY"]) {
  console.log(
    `${c.yellow}⚠${c.reset}  FIRECRAWL_API_KEY not set — ${c.dim}pipeline will use mock client (fast, no network)${c.reset}`
  );
}

// ── Helper: run a command synchronously, exit on non-zero ────────────────────
function runSync(file, args, cwd = ROOT) {
  const result = spawnSync(file, args, { stdio: "inherit", env, cwd });
  if (result.error) throw result.error;
  if (result.status !== 0) {
    fail(`Command failed: ${file} ${args.join(" ")} (exit ${result.status})`);
  }
}

// ── Step 1: Sync schema ───────────────────────────────────────────────────────
step(1, "Sync DB schema");
const coreDir = resolve(ROOT, "packages/core");
try {
  runSync("pnpm", ["exec", "drizzle-kit", "push", "--force"], coreDir);
  ok("Schema up to date.");
} catch (err) {
  fail(
    "DB schema sync failed.",
    "Check DATABASE_URL in .env.local and that the DB is reachable."
  );
}

// ── Step 2: Pipeline ──────────────────────────────────────────────────────────
if (OFFLINE) {
  step(2, "Pipeline skipped  (--offline: using existing DB data)");
  console.log(`${c.dim}  Assuming a prior run is already in the DB.${c.reset}`);
  console.log(`${c.dim}  Run without --offline to ingest fresh data.${c.reset}`);
} else {
  step(2, "Run pipeline  (discover → scrape → normalize → rules → brief)");
  const workerDir = resolve(ROOT, "apps/worker");
  try {
    runSync(
      "node",
      ["--import", "tsx/esm", "src/run.ts"],
      workerDir
    );
    ok("Pipeline complete — findings and targets written to DB.");
  } catch (err) {
    fail("Pipeline failed.", "Check worker output above for details.");
  }
}

// ── Step 3: Start web ─────────────────────────────────────────────────────────
step(3, "Start web app");
console.log(`${c.dim}  Starting Next.js dev server…${c.reset}`);

const webDir = resolve(ROOT, "apps/web");
const web = spawn("pnpm", ["exec", "next", "dev"], {
  cwd: webDir,
  env,
  stdio: "inherit",
});

web.on("error", (err) => {
  fail(`Failed to start web app: ${err.message}`);
});

web.on("exit", (code) => {
  if (code !== 0 && code !== null) {
    fail(`Web app exited with code ${code}`);
  }
});

// Print URL after Next.js has had time to emit its own Ready line
setTimeout(() => {
  console.log(`\n${c.bold}${c.green}────────────────────────────────────${c.reset}`);
  console.log(`${c.bold}  CompliCore demo ready${c.reset}`);
  console.log(`  ${c.cyan}http://localhost:3000${c.reset}`);
  console.log(`${c.bold}${c.green}────────────────────────────────────${c.reset}\n`);
}, 5000);

// Forward SIGINT / SIGTERM so Ctrl-C cleanly kills Next.js
for (const sig of ["SIGINT", "SIGTERM"]) {
  process.on(sig, () => {
    web.kill(sig);
    process.exit(0);
  });
}
