/**
 * URL inventory via Firecrawl map.
 *
 * This is the "map" step of the pipeline:
 *   discover → map → classify → scrape → normalize → rules → brief
 *
 * Given a domain, discovers all publicly accessible URLs and checks
 * robots.txt compliance before returning. Each URL is returned as a
 * SourceUrl record (without DB IDs — those are assigned at write time).
 */

import type { FirecrawlClient } from "./client.js";
import type { PageType } from "../../core/src/page-taxonomy.js";

// ---------------------------------------------------------------------------
// Robots.txt
// ---------------------------------------------------------------------------

interface RobotsTxtResult {
  url: string;
  disallowedPaths: string[];
  fetchedAt: string;
  fetchError: string | null;
}

async function fetchRobotsTxt(domain: string): Promise<RobotsTxtResult> {
  const url = `https://${domain}/robots.txt`;
  const result: RobotsTxtResult = {
    url,
    disallowedPaths: [],
    fetchedAt: new Date().toISOString(),
    fetchError: null,
  };

  try {
    const response = await fetch(url, {
      headers: { "User-Agent": "CompliCore-Scout/1.0" },
    });

    if (!response.ok) {
      // 404 means no robots.txt — all paths allowed
      return result;
    }

    const text = await response.text();
    result.disallowedPaths = parseRobotsTxtDisallowed(text);
  } catch (err) {
    result.fetchError = String(err);
  }

  return result;
}

function parseRobotsTxtDisallowed(content: string): string[] {
  const disallowed: string[] = [];
  let isRelevantAgent = false;

  for (const line of content.split("\n")) {
    const trimmed = line.trim();
    if (trimmed.startsWith("#") || trimmed === "") continue;

    const [directive, ...valueParts] = trimmed.split(":");
    const value = valueParts.join(":").trim();

    if (directive?.toLowerCase() === "user-agent") {
      isRelevantAgent = value === "*" || value.toLowerCase().includes("bot");
    }

    if (
      isRelevantAgent &&
      directive?.toLowerCase() === "disallow" &&
      value !== ""
    ) {
      disallowed.push(value);
    }
  }

  return disallowed;
}

function isDisallowed(urlPath: string, disallowedPaths: string[]): boolean {
  for (const pattern of disallowedPaths) {
    if (urlPath.startsWith(pattern)) return true;
  }
  return false;
}

// ---------------------------------------------------------------------------
// Input / output types
// ---------------------------------------------------------------------------

export interface MapDomainInput {
  domain: string;
  domainId: string;
  /** Firecrawl map options */
  limit?: number;
  includeSubdomains?: boolean;
  sitemapOnly?: boolean;
}

/** A URL record ready to be written to the database. domain_id not yet resolved. */
export interface MappedUrl {
  domainId: string;
  url: string;
  /** Hint assigned by classify step — set to "other" at map time. */
  contentTypeHint: PageType;
  depth: number;
  status: "pending";
  discoveredAt: string;
}

export interface MapDomainResult {
  domain: string;
  domainId: string;
  robotsTxt: RobotsTxtResult;
  urls: MappedUrl[];
  blockedCount: number;
}

// ---------------------------------------------------------------------------
// Main function
// ---------------------------------------------------------------------------

export async function mapDomain(
  client: FirecrawlClient,
  input: MapDomainInput,
): Promise<MapDomainResult> {
  const robotsTxt = await fetchRobotsTxt(input.domain);

  const response = await client.map(`https://${input.domain}`, {
    limit: input.limit ?? 500,
    includeSubdomains: input.includeSubdomains ?? false,
    sitemapOnly: input.sitemapOnly ?? false,
  });

  let blockedCount = 0;
  const now = new Date().toISOString();
  const urls: MappedUrl[] = [];

  for (const rawUrl of response.links) {
    let parsed: URL;
    try {
      parsed = new URL(rawUrl);
    } catch {
      continue;
    }

    // Skip non-HTTP(S) URLs
    if (!parsed.protocol.startsWith("http")) continue;

    // Enforce robots.txt
    if (isDisallowed(parsed.pathname, robotsTxt.disallowedPaths)) {
      blockedCount++;
      continue;
    }

    // Estimate depth from path segments
    const depth = parsed.pathname.split("/").filter(Boolean).length;

    urls.push({
      domainId: input.domainId,
      url: rawUrl,
      contentTypeHint: "other", // classify step will refine this
      depth,
      status: "pending",
      discoveredAt: now,
    });
  }

  return {
    domain: input.domain,
    domainId: input.domainId,
    robotsTxt,
    urls,
    blockedCount,
  };
}

// ---------------------------------------------------------------------------
// Fixtures (for tests — no network required)
// ---------------------------------------------------------------------------

export const FIXTURES = {
  input: {
    domain: "example-housing.com",
    domainId: "domain-001",
    limit: 100,
  } satisfies MapDomainInput,

  robotsTxt: {
    url: "https://example-housing.com/robots.txt",
    disallowedPaths: ["/admin", "/internal", "/api/private"],
    fetchedAt: "2026-03-29T00:00:00.000Z",
    fetchError: null,
  } satisfies RobotsTxtResult,

  result: {
    domain: "example-housing.com",
    domainId: "domain-001",
    robotsTxt: {
      url: "https://example-housing.com/robots.txt",
      disallowedPaths: ["/admin", "/internal", "/api/private"],
      fetchedAt: "2026-03-29T00:00:00.000Z",
      fetchError: null,
    },
    blockedCount: 0,
    urls: [
      {
        domainId: "domain-001",
        url: "https://example-housing.com/",
        contentTypeHint: "other",
        depth: 0,
        status: "pending",
        discoveredAt: "2026-03-29T00:00:00.000Z",
      },
      {
        domainId: "domain-001",
        url: "https://example-housing.com/listings/studio-downtown",
        contentTypeHint: "other",
        depth: 2,
        status: "pending",
        discoveredAt: "2026-03-29T00:00:00.000Z",
      },
      {
        domainId: "domain-001",
        url: "https://example-housing.com/pricing",
        contentTypeHint: "other",
        depth: 1,
        status: "pending",
        discoveredAt: "2026-03-29T00:00:00.000Z",
      },
      {
        domainId: "domain-001",
        url: "https://example-housing.com/terms",
        contentTypeHint: "other",
        depth: 1,
        status: "pending",
        discoveredAt: "2026-03-29T00:00:00.000Z",
      },
    ],
  } satisfies MapDomainResult,
} as const;
