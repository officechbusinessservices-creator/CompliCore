/**
 * Targeted page extraction via Firecrawl scrape.
 *
 * This is the "scrape" step of the pipeline:
 *   discover → map → classify → scrape → normalize → rules → brief
 *
 * Scrapes a single URL and returns a SourcePage + optional Screenshot.
 * Browser flows (JS-heavy SPAs, scroll-triggered content) are isolated
 * as a TODO — the static path is fully implemented.
 */

import type { FirecrawlClient } from "./client.js";
import type { PageType } from "../../core/src/page-taxonomy.js";
import type { SourcePage, Screenshot } from "../../core/src/types.js";

// ---------------------------------------------------------------------------
// Input / output types
// ---------------------------------------------------------------------------

export interface ScrapePageInput {
  urlId: string;
  domainId: string;
  url: string;
  contentType: PageType;
  /** Capture a screenshot alongside the scrape. Default: true. */
  captureScreenshot?: boolean;
  /**
   * Milliseconds to wait for the page to settle before scraping.
   * Use for pages with known loading delays.
   * Avoid setting this on every scrape — it increases credit consumption.
   */
  waitForMs?: number;
}

export interface ScrapePageResult {
  sourcePage: Omit<SourcePage, "id">;
  screenshot: Omit<Screenshot, "id"> | null;
}

// ---------------------------------------------------------------------------
// Main function
// ---------------------------------------------------------------------------

export async function scrapePage(
  client: FirecrawlClient,
  input: ScrapePageInput,
): Promise<ScrapePageResult> {
  const captureScreenshot = input.captureScreenshot ?? true;

  const formats: Array<"markdown" | "html" | "screenshot" | "links"> = [
    "markdown",
    "html",
  ];
  if (captureScreenshot) formats.push("screenshot");

  const response = await client.scrape(input.url, {
    formats,
    ...(input.waitForMs !== undefined && { waitFor: input.waitForMs }),
  });

  const { data } = response;
  const scrapedAt = new Date().toISOString();

  const sourcePage: Omit<SourcePage, "id"> = {
    url_id: input.urlId,
    domain_id: input.domainId,
    url: input.url,
    raw_html: data.html ?? null,
    text_content: data.markdown ?? null,
    http_status: data.metadata.statusCode,
    scraped_at: scrapedAt,
    content_type: input.contentType,
    word_count: data.markdown ? countWords(data.markdown) : null,
  };

  let screenshot: Omit<Screenshot, "id"> | null = null;
  if (captureScreenshot && data.screenshot) {
    screenshot = {
      source_page_id: "", // set by caller after sourcePage is persisted
      //
      // file_ref is the raw value returned by Firecrawl:
      //   - mock client  → 1×1 stub data URI (STUB_SCREENSHOT_DATA_URI)
      //   - real client  → full-page screenshot as a data URI
      //
      // TODO (blob upload): before storing, upload the data URI to Vercel Blob
      // and replace file_ref with the blob URL.  Insert point in the pipeline:
      //   apps/worker/src/pipeline.ts — immediately after scrapePage() returns,
      //   before evaluateAllRules().  Only upload when !isStubScreenshot(file_ref).
      //
      file_ref: data.screenshot,
      width: 1280,
      height: 800,
      captured_at: scrapedAt,
    };
  }

  return { sourcePage, screenshot };
}

/**
 * Browser-based scrape for JavaScript-heavy pages.
 *
 * TODO: implement when needed.
 * Browser flows should be isolated here so the static scrape path
 * never depends on browser infrastructure.
 *
 * Candidate use cases:
 * - SPA listing pages that render units via client-side JS
 * - Pricing pages behind a quote-request form
 * - Availability calendars
 */
export async function scrapePageWithBrowser(
  _client: FirecrawlClient,
  _input: ScrapePageInput & { actions: unknown[] },
): Promise<ScrapePageResult> {
  throw new Error(
    "scrapePageWithBrowser is not yet implemented. " +
      "Use scrapePage for static content.",
  );
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function countWords(markdown: string): number {
  return markdown
    .replace(/[#*`_~\[\]()>|-]/g, " ")
    .split(/\s+/)
    .filter(Boolean).length;
}

// ---------------------------------------------------------------------------
// Fixtures (for tests — no network required)
// ---------------------------------------------------------------------------

export const FIXTURES = {
  input: {
    urlId: "url-001",
    domainId: "domain-001",
    url: "https://example-housing.com/listings/studio-downtown",
    contentType: "listing_detail",
    captureScreenshot: true,
  } satisfies ScrapePageInput,

  result: {
    sourcePage: {
      url_id: "url-001",
      domain_id: "domain-001",
      url: "https://example-housing.com/listings/studio-downtown",
      raw_html:
        "<html><head><title>Furnished Studio — Downtown Austin</title></head>" +
        "<body><h1>Furnished Studio</h1><p>From $3,200/month.</p>" +
        "<p>Cancellation policy: 30-day notice required.</p>" +
        "<p>Cleaning fee: $150. No service fee.</p></body></html>",
      text_content:
        "# Furnished Studio — Downtown Austin\n\n" +
        "From **$3,200/month**.\n\n" +
        "1 bedroom. 1 bathroom. 520 sq ft.\n\n" +
        "Amenities: high-speed WiFi, in-unit washer/dryer, fully equipped kitchen.\n\n" +
        "Cancellation policy: 30-day notice required for full refund.\n\n" +
        "Cleaning fee: $150. No service fee.",
      http_status: 200,
      scraped_at: "2026-03-29T00:00:00.000Z",
      content_type: "listing_detail",
      word_count: 62,
    } satisfies Omit<SourcePage, "id">,

    screenshot: {
      source_page_id: "",
      file_ref:
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
      width: 1280,
      height: 800,
      captured_at: "2026-03-29T00:00:00.000Z",
    } satisfies Omit<Screenshot, "id">,
  } satisfies ScrapePageResult,
} as const;
