/**
 * Page type classification.
 *
 * This is the "classify" step of the pipeline:
 *   discover → map → classify → scrape → normalize → rules → brief
 *
 * Classification is deterministic and runs on URL patterns alone (no network
 * required). An optional content refinement pass is available for cases
 * where the URL is ambiguous — it uses text signals from already-scraped
 * content if available.
 *
 * No AI is used here. Classification must be reproducible and auditable.
 */

import {
  type PageClassification,
  type PageType,
} from "../../core/src/page-taxonomy.js";

// ---------------------------------------------------------------------------
// URL pattern rules
// ---------------------------------------------------------------------------

interface UrlRule {
  pattern: RegExp;
  type: PageType;
  signals: string[];
}

/**
 * Rules are evaluated in order. First match wins.
 * More specific patterns must come before general ones.
 */
const URL_RULES: UrlRule[] = [
  // Gated / dynamic — check before listing/pricing to catch login walls
  {
    pattern: /\/(login|sign-in|signin|account|dashboard|portal|my-account)/i,
    type: "gated_dynamic",
    signals: ["URL path indicates authentication-required area"],
  },

  // Privacy
  {
    pattern: /\/(privacy[-_]?policy|privacy|data[-_]?policy|gdpr)/i,
    type: "privacy",
    signals: ["URL path contains privacy policy indicator"],
  },

  // Policy terms (after privacy to avoid conflict)
  {
    pattern: /\/(terms[-_]?(of[-_]?service|and[-_]?conditions)?|cancellation[-_]?policy|refund[-_]?policy|lease[-_]?terms|tos|policies?)/i,
    type: "policy_terms",
    signals: ["URL path contains terms/policy indicator"],
  },

  // Pricing
  {
    pattern: /\/(pricing|rates?|price[-_]?list|fee[-_]?schedule|quote|cost)/i,
    type: "pricing",
    signals: ["URL path contains pricing indicator"],
  },

  // Contact
  {
    pattern: /\/(contact[-_]?us?|get[-_]?in[-_]?touch|reach[-_]?us?|support|inquiry|inquir[ye])/i,
    type: "contact",
    signals: ["URL path contains contact indicator"],
  },

  // Location / neighborhood
  {
    pattern: /\/(location|neighborhood|area|district|map|where[-_]?we[-_]?are)/i,
    type: "location",
    signals: ["URL path contains location indicator"],
  },

  // Trust signals
  {
    pattern: /\/(about|reviews?|testimonials?|awards?|accreditation|certif|press|media)/i,
    type: "trust_signals",
    signals: ["URL path contains trust/about indicator"],
  },

  // Blog / editorial
  {
    pattern: /\/(blog|news|articles?|guide|resources?|tips?|insights?|post)/i,
    type: "blog_content",
    signals: ["URL path contains editorial content indicator"],
  },

  // Listing detail — specific unit pages
  {
    pattern: /\/(listing[s]?|apartment[s]?|unit[s]?|suite[s]?|propert(y|ies)|furnished|studio|condo|flat|room[s]?)\//i,
    type: "listing_detail",
    signals: ["URL path contains listing segment with trailing slash (section page)"],
  },
  {
    pattern: /\/(listing[s]?|apartment[s]?|unit[s]?|suite[s]?|propert(y|ies)|furnished|studio|condo|flat|room[s]?)$/i,
    type: "listing_detail",
    signals: ["URL path ends with listing indicator"],
  },

  // Homepage
  {
    pattern: /^https?:\/\/[^/]+(\/)?$/,
    type: "homepage",
    signals: ["URL is root path"],
  },
];

// ---------------------------------------------------------------------------
// Content signal rules (applied only when URL match confidence is < high)
// ---------------------------------------------------------------------------

interface ContentRule {
  pattern: RegExp;
  type: PageType;
  signal: string;
}

const CONTENT_RULES: ContentRule[] = [
  { pattern: /privacy\s+policy/i, type: "privacy", signal: "Content contains 'privacy policy'" },
  { pattern: /cancellation\s+policy/i, type: "policy_terms", signal: "Content contains 'cancellation policy'" },
  { pattern: /terms\s+(of\s+service|and\s+conditions)/i, type: "policy_terms", signal: "Content contains 'terms of service'" },
  { pattern: /\$[\d,]+\s*(\/|per)\s*(month|mo\b|night|week)/i, type: "pricing", signal: "Content contains price-per-period pattern" },
  { pattern: /bedroom[s]?|bathroom[s]?|sq\.?\s*ft/i, type: "listing_detail", signal: "Content contains unit specification patterns" },
  { pattern: /contact\s+us|get\s+in\s+touch|send\s+us\s+a\s+message/i, type: "contact", signal: "Content contains contact call-to-action" },
  { pattern: /review[s]?|testimonial[s]?|rating[s]?/i, type: "trust_signals", signal: "Content contains review/testimonial patterns" },
];

// ---------------------------------------------------------------------------
// Classification functions
// ---------------------------------------------------------------------------

/**
 * Classify a URL using URL pattern matching only.
 * Fast and network-free. Use for the classify pipeline step.
 */
export function classifyUrl(url: string): PageClassification {
  for (const rule of URL_RULES) {
    let testTarget: string;
    try {
      testTarget = new URL(url).pathname;
    } catch {
      testTarget = url;
    }

    if (rule.pattern.test(url) || rule.pattern.test(testTarget)) {
      return {
        page_type: rule.type,
        confidence: "high",
        signals: rule.signals,
      };
    }
  }

  return {
    page_type: "other",
    confidence: "low",
    signals: ["No URL pattern matched"],
  };
}

/**
 * Refine a classification using content signals.
 * Use when URL classification confidence is not "high".
 * Safe to call with an empty string — falls back to the URL result.
 */
export function refineWithContent(
  urlResult: PageClassification,
  textContent: string,
): PageClassification {
  if (urlResult.confidence === "high" || !textContent) return urlResult;

  const matched: ContentRule[] = [];
  for (const rule of CONTENT_RULES) {
    if (rule.pattern.test(textContent)) {
      matched.push(rule);
    }
  }

  if (matched.length === 0) return urlResult;

  // Take the most-specific content match (first in CONTENT_RULES order)
  const best = matched[0];

  // If content agrees with URL result, upgrade confidence
  if (best.type === urlResult.page_type) {
    return {
      page_type: urlResult.page_type,
      confidence: "high",
      signals: [...urlResult.signals, best.signal],
    };
  }

  // Content and URL disagree — surface both signals, keep medium confidence
  return {
    page_type: best.type,
    confidence: "medium",
    signals: [
      ...urlResult.signals,
      best.signal,
      `URL suggested "${urlResult.page_type}", content overrides to "${best.type}"`,
    ],
  };
}

/**
 * Full classification: URL pattern first, content refinement if needed.
 */
export function classifyPage(
  url: string,
  textContent?: string,
): PageClassification {
  const urlResult = classifyUrl(url);
  if (!textContent || urlResult.confidence === "high") return urlResult;
  return refineWithContent(urlResult, textContent);
}

// ---------------------------------------------------------------------------
// Fixtures (for tests)
// ---------------------------------------------------------------------------

export const FIXTURES = {
  cases: [
    {
      url: "https://example-housing.com/",
      expectedType: "homepage" as PageType,
      expectedConfidence: "high" as const,
    },
    {
      url: "https://example-housing.com/listings/studio-downtown",
      expectedType: "listing_detail" as PageType,
      expectedConfidence: "high" as const,
    },
    {
      url: "https://example-housing.com/pricing",
      expectedType: "pricing" as PageType,
      expectedConfidence: "high" as const,
    },
    {
      url: "https://example-housing.com/terms",
      expectedType: "policy_terms" as PageType,
      expectedConfidence: "high" as const,
    },
    {
      url: "https://example-housing.com/privacy-policy",
      expectedType: "privacy" as PageType,
      expectedConfidence: "high" as const,
    },
    {
      url: "https://example-housing.com/contact-us",
      expectedType: "contact" as PageType,
      expectedConfidence: "high" as const,
    },
    {
      url: "https://example-housing.com/about",
      expectedType: "trust_signals" as PageType,
      expectedConfidence: "high" as const,
    },
    {
      url: "https://example-housing.com/blog/furnished-tips",
      expectedType: "blog_content" as PageType,
      expectedConfidence: "high" as const,
    },
    {
      url: "https://example-housing.com/login",
      expectedType: "gated_dynamic" as PageType,
      expectedConfidence: "high" as const,
    },
    {
      url: "https://example-housing.com/p/austin-guide",
      textContent: "bedroom bathroom sq ft from $3,200/month",
      expectedType: "listing_detail" as PageType,
      expectedConfidence: "medium" as const,
    },
  ],
} as const;
