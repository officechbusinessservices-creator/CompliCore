/**
 * Firecrawl HTTP client for CompliCore Command OS.
 *
 * Wraps the Firecrawl v1 REST API using native fetch.
 * No third-party HTTP library; no SDK dependency.
 *
 * All callers must supply a FirecrawlConfig. The recommended pattern is:
 *   const client = createClient({ apiKey: process.env.FIRECRAWL_API_KEY! });
 */

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

export interface FirecrawlConfig {
  apiKey: string;
  /** Override base URL for local proxy or self-hosted Firecrawl. */
  baseUrl?: string;
  /**
   * Maximum number of retries on 429 or 5xx responses.
   * Default: 3.
   */
  maxRetries?: number;
  /**
   * Initial backoff in ms before first retry.
   * Subsequent retries use exponential backoff.
   * Default: 1000.
   */
  initialBackoffMs?: number;
}

const DEFAULT_BASE_URL = "https://api.firecrawl.dev";
const DEFAULT_MAX_RETRIES = 3;
const DEFAULT_INITIAL_BACKOFF_MS = 1_000;

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

export type FirecrawlErrorCode =
  | "AUTH_FAILED"
  | "RATE_LIMITED"
  | "CREDIT_EXHAUSTED"
  | "VALIDATION_ERROR"
  | "SERVER_ERROR"
  | "TIMEOUT"
  | "NETWORK_ERROR"
  | "UNEXPECTED";

export class FirecrawlError extends Error {
  constructor(
    public readonly code: FirecrawlErrorCode,
    message: string,
    public readonly httpStatus?: number,
    public readonly retryable: boolean = false,
  ) {
    super(message);
    this.name = "FirecrawlError";
  }
}

// ---------------------------------------------------------------------------
// Raw API response shapes
// ---------------------------------------------------------------------------

export interface FirecrawlMetadata {
  title?: string;
  description?: string;
  ogTitle?: string;
  ogDescription?: string;
  language?: string;
  sourceURL: string;
  statusCode: number;
  error?: string | null;
}

export interface FirecrawlScrapeData {
  markdown?: string;
  html?: string;
  /** URL string or base64 data URI */
  screenshot?: string;
  metadata: FirecrawlMetadata;
  links?: string[];
}

export interface FirecrawlScrapeResponse {
  success: true;
  data: FirecrawlScrapeData;
}

export interface FirecrawlMapResponse {
  success: true;
  links: string[];
}

export interface FirecrawlCrawlStartResponse {
  success: true;
  id: string;
  url: string;
}

export interface FirecrawlCrawlStatusResponse {
  status: "scraping" | "completed" | "failed" | "cancelled";
  total: number;
  completed: number;
  creditsUsed: number;
  expiresAt: string;
  data?: FirecrawlScrapeData[];
}

export interface FirecrawlSearchResult {
  url: string;
  title?: string;
  description?: string;
  markdown?: string;
}

export interface FirecrawlSearchResponse {
  success: true;
  data: FirecrawlSearchResult[];
}

// ---------------------------------------------------------------------------
// Client
// ---------------------------------------------------------------------------

export interface FirecrawlClient {
  scrape(
    url: string,
    options?: ScrapeOptions,
  ): Promise<FirecrawlScrapeResponse>;
  map(url: string, options?: MapOptions): Promise<FirecrawlMapResponse>;
  crawlStart(
    url: string,
    options?: CrawlOptions,
  ): Promise<FirecrawlCrawlStartResponse>;
  crawlStatus(id: string): Promise<FirecrawlCrawlStatusResponse>;
  search(query: string, options?: SearchOptions): Promise<FirecrawlSearchResponse>;
}

export interface ScrapeOptions {
  formats?: Array<"markdown" | "html" | "screenshot" | "links">;
  /**
   * Browser actions for JavaScript-heavy pages.
   * TODO: implement when needed — keep isolated from static scrape path.
   */
  actions?: never;
  waitFor?: number;
  timeout?: number;
  headers?: Record<string, string>;
}

export interface MapOptions {
  includeSubdomains?: boolean;
  sitemapOnly?: boolean;
  limit?: number;
  ignoreSitemap?: boolean;
}

export interface CrawlOptions {
  maxDepth?: number;
  limit?: number;
  allowBackwardLinks?: boolean;
  allowExternalLinks?: boolean;
  includePaths?: string[];
  excludePaths?: string[];
  formats?: Array<"markdown" | "html" | "screenshot">;
}

export interface SearchOptions {
  limit?: number;
  lang?: string;
  country?: string;
}

export function createClient(config: FirecrawlConfig): FirecrawlClient {
  const baseUrl = config.baseUrl ?? DEFAULT_BASE_URL;
  const maxRetries = config.maxRetries ?? DEFAULT_MAX_RETRIES;
  const initialBackoffMs =
    config.initialBackoffMs ?? DEFAULT_INITIAL_BACKOFF_MS;

  async function request<T>(
    method: "GET" | "POST",
    path: string,
    body?: unknown,
  ): Promise<T> {
    let lastError: FirecrawlError | undefined;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      if (attempt > 0) {
        const delay = initialBackoffMs * Math.pow(2, attempt - 1);
        await sleep(delay);
      }

      let response: Response;
      try {
        response = await fetch(`${baseUrl}${path}`, {
          method,
          headers: {
            Authorization: `Bearer ${config.apiKey}`,
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: body !== undefined ? JSON.stringify(body) : undefined,
        });
      } catch (err) {
        lastError = new FirecrawlError(
          "NETWORK_ERROR",
          `Network request failed: ${String(err)}`,
          undefined,
          true,
        );
        continue;
      }

      if (response.ok) {
        const json = await response.json();
        return json as T;
      }

      const errorBody = await response.text().catch(() => "");
      lastError = toFirecrawlError(response.status, errorBody);

      if (!lastError.retryable) break;
    }

    throw lastError ?? new FirecrawlError("UNEXPECTED", "Unknown error");
  }

  return {
    scrape(url, options = {}) {
      return request<FirecrawlScrapeResponse>("POST", "/v1/scrape", {
        url,
        formats: options.formats ?? ["markdown", "html", "screenshot"],
        ...(options.waitFor !== undefined && { waitFor: options.waitFor }),
        ...(options.timeout !== undefined && { timeout: options.timeout }),
        ...(options.headers !== undefined && { headers: options.headers }),
      });
    },

    map(url, options = {}) {
      return request<FirecrawlMapResponse>("POST", "/v1/map", {
        url,
        includeSubdomains: options.includeSubdomains ?? false,
        sitemapOnly: options.sitemapOnly ?? false,
        limit: options.limit ?? 5_000,
        ignoreSitemap: options.ignoreSitemap ?? false,
      });
    },

    crawlStart(url, options = {}) {
      return request<FirecrawlCrawlStartResponse>("POST", "/v1/crawl", {
        url,
        maxDepth: options.maxDepth ?? 3,
        limit: options.limit ?? 100,
        allowBackwardLinks: options.allowBackwardLinks ?? false,
        allowExternalLinks: options.allowExternalLinks ?? false,
        ...(options.includePaths && { includePaths: options.includePaths }),
        ...(options.excludePaths && { excludePaths: options.excludePaths }),
        scrapeOptions: {
          formats: options.formats ?? ["markdown", "html"],
        },
      });
    },

    crawlStatus(id) {
      return request<FirecrawlCrawlStatusResponse>(
        "GET",
        `/v1/crawl/${encodeURIComponent(id)}`,
      );
    },

    search(query, options = {}) {
      return request<FirecrawlSearchResponse>("POST", "/v1/search", {
        query,
        limit: options.limit ?? 10,
        ...(options.lang && { lang: options.lang }),
        ...(options.country && { country: options.country }),
      });
    },
  };
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function toFirecrawlError(status: number, body: string): FirecrawlError {
  switch (status) {
    case 401:
    case 403:
      return new FirecrawlError("AUTH_FAILED", `Auth failed (${status}): ${body}`, status, false);
    case 402:
      return new FirecrawlError("CREDIT_EXHAUSTED", "Firecrawl credit limit reached", status, false);
    case 422:
      return new FirecrawlError("VALIDATION_ERROR", `Invalid request: ${body}`, status, false);
    case 429:
      return new FirecrawlError("RATE_LIMITED", "Rate limited — will retry", status, true);
    default:
      if (status >= 500) {
        return new FirecrawlError("SERVER_ERROR", `Server error (${status}): ${body}`, status, true);
      }
      return new FirecrawlError("UNEXPECTED", `Unexpected HTTP ${status}: ${body}`, status, false);
  }
}

// ---------------------------------------------------------------------------
// Fixtures (for tests — no network required)
// ---------------------------------------------------------------------------

export const FIXTURES = {
  scrapeResponse: {
    success: true as const,
    data: {
      markdown:
        "# Furnished Studio — Downtown Austin\n\nFrom **$3,200/month**.\n\nCancellation policy: 30-day notice required for refund.\n\nCleaning fee: $150. No service fee.",
      html: "<html><head><title>Furnished Studio — Downtown Austin</title></head><body></body></html>",
      screenshot: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
      metadata: {
        title: "Furnished Studio — Downtown Austin",
        description: "Short-term furnished studio available from $3,200/month",
        sourceURL: "https://example-housing.com/listings/studio-downtown",
        statusCode: 200,
      },
    },
  },

  mapResponse: {
    success: true as const,
    links: [
      "https://example-housing.com/",
      "https://example-housing.com/listings",
      "https://example-housing.com/listings/studio-downtown",
      "https://example-housing.com/pricing",
      "https://example-housing.com/contact",
      "https://example-housing.com/terms",
    ],
  },

  crawlStartResponse: {
    success: true as const,
    id: "test-crawl-id-001",
    url: "https://api.firecrawl.dev/v1/crawl/test-crawl-id-001",
  },

  crawlStatusCompleted: {
    status: "completed" as const,
    total: 2,
    completed: 2,
    creditsUsed: 2,
    expiresAt: "2026-04-05T00:00:00.000Z",
    data: [
      {
        markdown: "# Listings\n\n- Studio from $3,200/month\n- 1BR from $4,500/month",
        metadata: {
          title: "Listings",
          sourceURL: "https://example-housing.com/listings",
          statusCode: 200,
        },
      },
      {
        markdown: "# Pricing\n\nAll rates include utilities. Cleaning fee: $150. 30-day minimum stay.",
        metadata: {
          title: "Pricing",
          sourceURL: "https://example-housing.com/pricing",
          statusCode: 200,
        },
      },
    ],
  },

  searchResponse: {
    success: true as const,
    data: [
      {
        url: "https://example-housing.com",
        title: "Example Corporate Housing — Austin TX",
        description: "Furnished apartments for corporate travelers in Austin",
        markdown: "Corporate housing in Austin. Studio and 1BR units available.",
      },
      {
        url: "https://stay-austin.com",
        title: "Stay Austin — Extended Stay Apartments",
        description: "Monthly furnished rentals in downtown Austin",
        markdown: "Extended stay furnished apartments. From $2,800/month.",
      },
    ],
  },
} satisfies {
  scrapeResponse: FirecrawlScrapeResponse;
  mapResponse: FirecrawlMapResponse;
  crawlStartResponse: FirecrawlCrawlStartResponse;
  crawlStatusCompleted: FirecrawlCrawlStatusResponse;
  searchResponse: FirecrawlSearchResponse;
};
