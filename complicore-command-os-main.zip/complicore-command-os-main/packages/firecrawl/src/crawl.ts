/**
 * Section-level ingestion via Firecrawl crawl.
 *
 * Crawl is used when a domain section needs to be ingested in bulk
 * (e.g., all listing pages under /listings/*) rather than scraping
 * individual URLs one at a time.
 *
 * Returns SourcePage records for all crawled pages in the section.
 * Polls until completion or timeout.
 */

import type { FirecrawlClient } from "./client.js";
import type { PageType } from "../../core/src/page-taxonomy.js";
import type { SourcePage } from "../../core/src/types.js";

// ---------------------------------------------------------------------------
// Input / output types
// ---------------------------------------------------------------------------

export interface CrawlSectionInput {
  domainId: string;
  /** Root URL to crawl from, e.g. "https://example.com/listings" */
  rootUrl: string;
  contentType: PageType;
  maxDepth?: number;
  limit?: number;
  /**
   * Only include URLs whose path starts with these prefixes.
   * e.g. ["/listings", "/properties"]
   */
  includePaths?: string[];
  /**
   * Milliseconds to wait between poll attempts.
   * Default: 3000.
   */
  pollIntervalMs?: number;
  /**
   * Maximum total milliseconds to wait for crawl completion.
   * Default: 120_000 (2 minutes).
   */
  timeoutMs?: number;
}

export interface CrawlSectionResult {
  rootUrl: string;
  pages: Array<Omit<SourcePage, "id">>;
  completedAt: string;
  creditsUsed: number;
}

// ---------------------------------------------------------------------------
// Main function
// ---------------------------------------------------------------------------

export async function crawlSection(
  client: FirecrawlClient,
  input: CrawlSectionInput,
): Promise<CrawlSectionResult> {
  const pollIntervalMs = input.pollIntervalMs ?? 3_000;
  const timeoutMs = input.timeoutMs ?? 120_000;

  // Start crawl
  const startResponse = await client.crawlStart(input.rootUrl, {
    maxDepth: input.maxDepth ?? 3,
    limit: input.limit ?? 100,
    includePaths: input.includePaths,
    formats: ["markdown", "html"],
  });

  const crawlId = startResponse.id;
  const deadline = Date.now() + timeoutMs;

  // Poll until complete
  let statusResponse = await client.crawlStatus(crawlId);

  while (
    statusResponse.status === "scraping" &&
    Date.now() < deadline
  ) {
    await sleep(pollIntervalMs);
    statusResponse = await client.crawlStatus(crawlId);
  }

  if (statusResponse.status === "failed") {
    throw new Error(`Crawl ${crawlId} failed`);
  }

  if (statusResponse.status === "scraping") {
    throw new Error(
      `Crawl ${crawlId} did not complete within ${timeoutMs}ms timeout`,
    );
  }

  // Build SourcePage records
  const completedAt = new Date().toISOString();
  const pages: Array<Omit<SourcePage, "id">> = [];

  for (const pageData of statusResponse.data ?? []) {
    if (!pageData.metadata?.sourceURL) continue;

    pages.push({
      url_id: "", // caller assigns after URL record is persisted
      domain_id: input.domainId,
      url: pageData.metadata.sourceURL,
      raw_html: pageData.html ?? null,
      text_content: pageData.markdown ?? null,
      http_status: pageData.metadata.statusCode,
      scraped_at: completedAt,
      content_type: input.contentType,
      word_count: pageData.markdown ? countWords(pageData.markdown) : null,
    });
  }

  return {
    rootUrl: input.rootUrl,
    pages,
    completedAt,
    creditsUsed: statusResponse.creditsUsed,
  };
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function countWords(markdown: string): number {
  return markdown
    .replace(/[#*`_~\[\]()>|-]/g, " ")
    .split(/\s+/)
    .filter(Boolean).length;
}

// ---------------------------------------------------------------------------
// Fixtures (for tests — no network required)
// ---------------------------------------------------------------------------

export const FIXTURES = {
  input: {
    domainId: "domain-001",
    rootUrl: "https://example-housing.com/listings",
    contentType: "listing_detail",
    maxDepth: 2,
    limit: 50,
    includePaths: ["/listings"],
    pollIntervalMs: 100,
    timeoutMs: 5_000,
  } satisfies CrawlSectionInput,

  result: {
    rootUrl: "https://example-housing.com/listings",
    completedAt: "2026-03-29T00:01:00.000Z",
    creditsUsed: 2,
    pages: [
      {
        url_id: "",
        domain_id: "domain-001",
        url: "https://example-housing.com/listings",
        raw_html: "<html><body><h1>Listings</h1></body></html>",
        text_content:
          "# Listings\n\n- Studio from $3,200/month\n- 1BR from $4,500/month",
        http_status: 200,
        scraped_at: "2026-03-29T00:01:00.000Z",
        content_type: "listing_detail",
        word_count: 12,
      },
      {
        url_id: "",
        domain_id: "domain-001",
        url: "https://example-housing.com/listings/one-bedroom",
        raw_html: "<html><body><h1>1 Bedroom — South Congress</h1></body></html>",
        text_content:
          "# 1 Bedroom — South Congress\n\n" +
          "From **$4,500/month**.\n\n" +
          "1 bedroom. 1 bathroom. 780 sq ft.\n\n" +
          "Minimum stay: 30 nights.",
        http_status: 200,
        scraped_at: "2026-03-29T00:01:00.000Z",
        content_type: "listing_detail",
        word_count: 28,
      },
    ] satisfies Array<Omit<SourcePage, "id">>,
  } satisfies CrawlSectionResult,
} as const;
