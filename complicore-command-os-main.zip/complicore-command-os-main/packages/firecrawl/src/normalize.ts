/**
 * Observation extraction from scraped page content.
 *
 * This is the "normalize" step of the pipeline:
 *   discover → map → classify → scrape → normalize → rules → brief
 *
 * Takes a SourcePage and extracts typed observations:
 *   - Listing (unit specification)
 *   - PricingObservations (price and fee signals)
 *   - PolicyObservations (cancellation, refund, lease, house rules)
 *   - SchemaObservation (structured data signals)
 *   - ContentGaps (required content that is absent)
 *
 * All extraction is deterministic regex/pattern matching.
 * No AI. No inferences. Only what is present in the source text.
 *
 * If a field cannot be extracted, it is null. Null is not a gap — it is
 * an extraction miss. Gaps are only recorded for content that is expected
 * but provably absent.
 */

import type {
  ContentGap,
  ContentGapType,
  Listing,
  PolicyObservation,
  PolicyType,
  PricingObservation,
  PriceUnit,
  SchemaObservation,
  SourcePage,
} from "../../core/src/types.js";
import {
  isExtractable,
  isRequired,
  type PageType,
} from "../../core/src/page-taxonomy.js";

// ---------------------------------------------------------------------------
// Output type
// ---------------------------------------------------------------------------

export interface NormalizedPageData {
  source_page_id: string;
  listing: Omit<Listing, "id"> | null;
  pricing_observations: Array<Omit<PricingObservation, "id">>;
  policy_observations: Array<Omit<PolicyObservation, "id">>;
  schema_observation: Omit<SchemaObservation, "id"> | null;
  content_gaps: Array<Omit<ContentGap, "id">>;
  extraction_notes: string[];
}

// ---------------------------------------------------------------------------
// Listing extraction
// ---------------------------------------------------------------------------

const BEDROOM_PATTERNS = [
  /(\d+)\s*(?:bed(?:room)?[s]?)\b/i,
  /(\d+)\s*br\b/i,
  /studio/i, // signals 0 bedrooms
];

const BATHROOM_PATTERNS = [
  /(\d+(?:\.\d)?)\s*(?:bath(?:room)?[s]?)\b/i,
  /(\d+(?:\.\d)?)\s*ba\b/i,
];

const SQ_FT_PATTERNS = [
  /(\d{3,4})\s*sq(?:uare)?\s*(?:ft|feet|foot)/i,
  /(\d{3,4})\s*sqft/i,
];

const MIN_STAY_PATTERNS = [
  /minimum\s+stay[:\s]+(\d+)\s*(?:night[s]?|day[s]?)/i,
  /(\d+)[- ]night\s+minimum/i,
  /(\d+)[- ]day\s+minimum/i,
  /min(?:imum)?\.?\s*(\d+)\s*nights?/i,
];

function extractListing(
  text: string,
  sourcePageId: string,
  domainId: string,
): Omit<Listing, "id"> | null {
  let bedroomCount: number | null = null;
  let studioSignal = false;

  for (const pattern of BEDROOM_PATTERNS) {
    const match = text.match(pattern);
    if (match) {
      if (/studio/i.test(match[0])) {
        studioSignal = true;
        bedroomCount = 0;
      } else {
        bedroomCount = parseInt(match[1], 10);
      }
      break;
    }
  }

  let bathroomCount: number | null = null;
  for (const pattern of BATHROOM_PATTERNS) {
    const match = text.match(pattern);
    if (match) {
      bathroomCount = parseFloat(match[1]);
      break;
    }
  }

  let squareFootage: number | null = null;
  for (const pattern of SQ_FT_PATTERNS) {
    const match = text.match(pattern);
    if (match) {
      squareFootage = parseInt(match[1], 10);
      break;
    }
  }

  let minimumStayNights: number | null = null;
  for (const pattern of MIN_STAY_PATTERNS) {
    const match = text.match(pattern);
    if (match) {
      minimumStayNights = parseInt(match[1], 10);
      break;
    }
  }

  const amenityMatch = text.match(
    /amenities?[:\s]+([^\n.]+)/i,
  );
  const amenities: string[] = amenityMatch
    ? amenityMatch[1]
        .split(/,|;/)
        .map((a) => a.trim())
        .filter((a) => a.length > 2 && a.length < 60)
    : [];

  const availabilityMentioned =
    /available|availability|book now|reserve/i.test(text);

  // Only emit a listing record if we found at least one unit specification
  const hasUnitSpec =
    bedroomCount !== null ||
    studioSignal ||
    bathroomCount !== null ||
    squareFootage !== null;

  if (!hasUnitSpec) return null;

  return {
    source_page_id: sourcePageId,
    domain_id: domainId,
    unit_name: extractTitle(text),
    bedroom_count: bedroomCount,
    bathroom_count: bathroomCount,
    square_footage: squareFootage,
    amenities,
    minimum_stay_nights: minimumStayNights,
    availability_mentioned: availabilityMentioned,
  };
}

function extractTitle(text: string): string | null {
  const match = text.match(/^#\s+(.+)$/m);
  return match ? match[1].trim() : null;
}

// ---------------------------------------------------------------------------
// Pricing extraction
// ---------------------------------------------------------------------------

const PRICE_PATTERNS: Array<{
  pattern: RegExp;
  unit: PriceUnit;
}> = [
  { pattern: /\$\s*([\d,]+)\s*(?:\/|per)\s*month\b/i, unit: "per_month" },
  { pattern: /\$\s*([\d,]+)\s*(?:\/|per)\s*mo\b/i, unit: "per_month" },
  { pattern: /\$\s*([\d,]+)\s*(?:\/|per)\s*night\b/i, unit: "per_night" },
  { pattern: /\$\s*([\d,]+)\s*(?:\/|per)\s*week\b/i, unit: "per_week" },
  { pattern: /from\s+\$\s*([\d,]+)/i, unit: "unknown" },
  { pattern: /starting\s+at\s+\$\s*([\d,]+)/i, unit: "unknown" },
  { pattern: /\$\s*([\d,]+)\s*(?:\/month|\/mo|\/night|\/week)?/i, unit: "unknown" },
];

const FEE_PATTERNS = [
  /cleaning\s+fee/i,
  /service\s+fee/i,
  /security\s+deposit/i,
  /administrative\s+fee/i,
  /parking\s+fee/i,
  /pet\s+fee/i,
  /utility\s+fee/i,
  /move[-\s]?(?:in|out)\s+fee/i,
];

function extractPricingObservations(
  text: string,
  sourcePageId: string,
  domainId: string,
): Array<Omit<PricingObservation, "id">> {
  const observations: Array<Omit<PricingObservation, "id">> = [];

  for (const { pattern, unit } of PRICE_PATTERNS) {
    const matches = [...text.matchAll(new RegExp(pattern.source, "gi"))];
    for (const match of matches) {
      const priceRaw = match[0].trim();
      const numericStr = match[1]?.replace(/,/g, "");
      const priceNumeric = numericStr ? parseFloat(numericStr) : null;

      // Detect contextual price unit from surrounding text
      const resolvedUnit = resolveUnit(match.index ?? 0, text, unit);

      const feesMentioned = FEE_PATTERNS.filter((p) => p.test(text)).map(
        (p) => {
          const m = text.match(p);
          return m ? m[0].toLowerCase() : "";
        },
      ).filter(Boolean);

      const totalCostShown = /total\s+cost|all[-\s]?inclusive|all[-\s]?in\s+price/i.test(text);

      const quoteMatch = extractQuoteAroundMatch(text, match.index ?? 0, 150);

      observations.push({
        source_page_id: sourcePageId,
        domain_id: domainId,
        price_raw: priceRaw,
        price_numeric: priceNumeric,
        price_unit: resolvedUnit,
        fees_mentioned: [...new Set(feesMentioned)],
        total_cost_shown: totalCostShown,
        price_quote: quoteMatch,
      });

      // Only take the first price match to avoid duplicate observations
      break;
    }
    if (observations.length > 0) break;
  }

  return observations;
}

function resolveUnit(
  matchIndex: number,
  fullText: string,
  hintUnit: PriceUnit,
): PriceUnit {
  if (hintUnit !== "unknown") return hintUnit;
  const context = fullText.slice(
    Math.max(0, matchIndex - 20),
    matchIndex + 50,
  );
  if (/\/month|per month|monthly|\bmo\b/i.test(context)) return "per_month";
  if (/\/night|per night|nightly/i.test(context)) return "per_night";
  if (/\/week|per week|weekly/i.test(context)) return "per_week";
  return "unknown";
}

// ---------------------------------------------------------------------------
// Policy extraction
// ---------------------------------------------------------------------------

const POLICY_SECTIONS: Array<{
  pattern: RegExp;
  type: PolicyType;
}> = [
  { pattern: /cancellation\s+policy[:\s]+([^.]{20,300}\.)/is, type: "cancellation" },
  { pattern: /refund\s+policy[:\s]+([^.]{20,300}\.)/is, type: "refund" },
  { pattern: /lease\s+terms?[:\s]+([^.]{20,300}\.)/is, type: "lease" },
  { pattern: /house\s+rules?[:\s]+([^.]{20,300}\.)/is, type: "house_rules" },
];

function extractPolicyObservations(
  text: string,
  sourcePageId: string,
  domainId: string,
): Array<Omit<PolicyObservation, "id">> {
  const observations: Array<Omit<PolicyObservation, "id">> = [];

  for (const { pattern, type } of POLICY_SECTIONS) {
    const match = text.match(pattern);
    if (!match) continue;

    const summary = match[1]?.trim().slice(0, 300) ?? match[0].trim().slice(0, 300);

    observations.push({
      source_page_id: sourcePageId,
      domain_id: domainId,
      policy_type: type,
      policy_summary: summary,
      policy_url: null, // caller resolves linked policy URLs from links[]
    });
  }

  return observations;
}

// ---------------------------------------------------------------------------
// Schema observation (from raw HTML)
// ---------------------------------------------------------------------------

function extractSchemaObservation(
  sourcePageId: string,
  rawHtml: string | null,
): Omit<SchemaObservation, "id"> | null {
  if (!rawHtml) return null;

  const schemaTypesFound: string[] = [];

  // JSON-LD blocks
  const jsonLdMatches = rawHtml.matchAll(
    /<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi,
  );
  for (const match of jsonLdMatches) {
    try {
      const parsed = JSON.parse(match[1]);
      const types = extractSchemaTypes(parsed);
      schemaTypesFound.push(...types);
    } catch {
      // Malformed JSON-LD — skip
    }
  }

  // OG / meta schema signals
  const hasOgType = /<meta[^>]*property=["']og:type["']/i.test(rawHtml);
  if (hasOgType) schemaTypesFound.push("OGType");

  const hasStructuredData = schemaTypesFound.length > 0;
  const titlePresent = /<title[^>]*>[^<]+<\/title>/i.test(rawHtml);
  const metaDescriptionPresent =
    /<meta[^>]*name=["']description["'][^>]*content=["'][^"']+["']/i.test(
      rawHtml,
    );

  return {
    source_page_id: sourcePageId,
    has_structured_data: hasStructuredData,
    schema_types_found: [...new Set(schemaTypesFound)],
    title_present: titlePresent,
    meta_description_present: metaDescriptionPresent,
  };
}

function extractSchemaTypes(parsed: unknown): string[] {
  if (!parsed || typeof parsed !== "object") return [];
  const obj = parsed as Record<string, unknown>;
  const types: string[] = [];
  if (typeof obj["@type"] === "string") types.push(obj["@type"]);
  if (Array.isArray(obj["@type"])) {
    for (const t of obj["@type"]) {
      if (typeof t === "string") types.push(t);
    }
  }
  if (Array.isArray(obj["@graph"])) {
    for (const node of obj["@graph"]) {
      types.push(...extractSchemaTypes(node));
    }
  }
  return types;
}

// ---------------------------------------------------------------------------
// Content gap detection
// ---------------------------------------------------------------------------

/**
 * Identify required content that is absent from a page or its text.
 * Only call for page types where each gap type is expected.
 */
function detectContentGaps(
  text: string,
  pageType: PageType,
  sourcePageId: string,
  domainId: string,
): Array<Omit<ContentGap, "id">> {
  const gaps: Array<Omit<ContentGap, "id">> = [];

  const checks: Array<{
    gapType: ContentGapType;
    applicableTo: PageType[];
    absent: boolean;
    description: string;
  }> = [
    {
      gapType: "no_pricing",
      applicableTo: ["listing_detail", "pricing", "homepage"],
      absent: !/\$\s*[\d,]+/.test(text),
      description:
        "No price information found on a page expected to show pricing.",
    },
    {
      gapType: "no_cancellation_policy",
      applicableTo: ["listing_detail", "policy_terms", "pricing"],
      absent: !/cancellation/i.test(text),
      description: "No cancellation policy mention found.",
    },
    {
      gapType: "no_privacy_policy",
      applicableTo: ["homepage"],
      absent: !/privacy\s+policy/i.test(text),
      description: "No privacy policy link or mention found on the homepage.",
    },
    {
      gapType: "no_contact_path",
      applicableTo: ["homepage", "listing_detail"],
      absent: !/contact|phone|email|call us|get in touch/i.test(text),
      description: "No contact path (phone, email, or contact link) found.",
    },
    {
      gapType: "no_fee_disclosure",
      applicableTo: ["pricing", "listing_detail"],
      absent: !/fee|cleaning|service\s+fee|deposit/i.test(text),
      description:
        "No fee disclosure found on a page expected to list fees.",
    },
    {
      gapType: "no_trust_signals",
      applicableTo: ["homepage"],
      absent:
        !/review|testimonial|award|accredited|certified|rating|\d+\s+(?:client|guest|customer)/i.test(
          text,
        ),
      description:
        "No trust signals (reviews, awards, certifications) found on the homepage.",
    },
  ];

  for (const check of checks) {
    if (!check.applicableTo.includes(pageType)) continue;
    if (!check.absent) continue;

    gaps.push({
      source_page_id: sourcePageId,
      domain_id: domainId,
      gap_type: check.gapType,
      description: check.description,
    });
  }

  return gaps;
}

// ---------------------------------------------------------------------------
// Main function
// ---------------------------------------------------------------------------

export function normalizeSourcePage(
  page: SourcePage & { id: string },
): NormalizedPageData {
  const notes: string[] = [];

  if (!isExtractable(page.content_type)) {
    return {
      source_page_id: page.id,
      listing: null,
      pricing_observations: [],
      policy_observations: [],
      schema_observation: null,
      content_gaps: [],
      extraction_notes: [
        `Page type "${page.content_type}" is not in the extractable set — skipped.`,
      ],
    };
  }

  const text = page.text_content ?? "";

  if (!text) {
    notes.push("text_content is empty — extraction skipped for text-based fields.");
  }

  const listing =
    text && page.content_type === "listing_detail"
      ? extractListing(text, page.id, page.domain_id)
      : null;

  if (!listing && page.content_type === "listing_detail" && text) {
    notes.push("No unit specification signals found in listing_detail page.");
  }

  const pricingObservations = text
    ? extractPricingObservations(text, page.id, page.domain_id)
    : [];

  const policyObservations = text
    ? extractPolicyObservations(text, page.id, page.domain_id)
    : [];

  const schemaObservation = extractSchemaObservation(page.id, page.raw_html);

  const contentGaps = text
    ? detectContentGaps(text, page.content_type, page.id, page.domain_id)
    : [];

  return {
    source_page_id: page.id,
    listing,
    pricing_observations: pricingObservations,
    policy_observations: policyObservations,
    schema_observation: schemaObservation,
    content_gaps: contentGaps,
    extraction_notes: notes,
  };
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function extractQuoteAroundMatch(
  text: string,
  matchIndex: number,
  radius: number,
): string {
  const start = Math.max(0, matchIndex - radius);
  const end = Math.min(text.length, matchIndex + radius);
  return text.slice(start, end).trim().replace(/\s+/g, " ");
}

// ---------------------------------------------------------------------------
// Fixtures (for tests)
// ---------------------------------------------------------------------------

export const FIXTURES = {
  listingPage: {
    id: "page-001",
    url_id: "url-001",
    domain_id: "domain-001",
    url: "https://example-housing.com/listings/studio-downtown",
    raw_html:
      '<html><head><title>Furnished Studio — Downtown Austin</title>' +
      '<meta name="description" content="Short-term furnished studio from $3,200/month">' +
      '<script type="application/ld+json">{"@context":"https://schema.org","@type":"LodgingBusiness","name":"Example Housing"}</script>' +
      "</head><body></body></html>",
    text_content:
      "# Furnished Studio — Downtown Austin\n\n" +
      "From **$3,200/month**.\n\n" +
      "1 bedroom. 1 bathroom. 520 sq ft.\n\n" +
      "Amenities: high-speed WiFi, in-unit washer/dryer, fully equipped kitchen.\n\n" +
      "Cancellation policy: 30-day notice required for full refund.\n\n" +
      "Cleaning fee: $150. No service fee.\n\n" +
      "Contact us at leasing@example-housing.com.",
    http_status: 200,
    scraped_at: "2026-03-29T00:00:00.000Z",
    content_type: "listing_detail" as PageType,
    word_count: 62,
  },

  pricingPage: {
    id: "page-002",
    url_id: "url-002",
    domain_id: "domain-001",
    url: "https://example-housing.com/pricing",
    raw_html:
      "<html><head><title>Pricing</title></head><body></body></html>",
    text_content:
      "# Pricing\n\n" +
      "All rates include utilities. 30-night minimum stay.\n\n" +
      "- Studio: from $2,800/month\n" +
      "- 1 Bedroom: from $3,800/month\n\n" +
      "Cleaning fee: $150 per stay. Security deposit: $500.",
    http_status: 200,
    scraped_at: "2026-03-29T00:00:00.000Z",
    content_type: "pricing" as PageType,
    word_count: 44,
  },

  gatedPage: {
    id: "page-003",
    url_id: "url-003",
    domain_id: "domain-001",
    url: "https://example-housing.com/login",
    raw_html: "<html><body>Login required</body></html>",
    text_content: "Login to view your account.",
    http_status: 200,
    scraped_at: "2026-03-29T00:00:00.000Z",
    content_type: "gated_dynamic" as PageType,
    word_count: 5,
  },
} as const;
