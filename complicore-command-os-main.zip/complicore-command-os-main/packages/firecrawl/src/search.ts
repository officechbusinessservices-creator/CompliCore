/**
 * Domain discovery via Firecrawl search.
 *
 * This is the "discover" step of the pipeline:
 *   discover → map → classify → scrape → normalize → rules → brief
 *
 * Given a metro name, it discovers competitor corporate housing operator
 * domains via search queries. Returns bare domain strings ready for the
 * map step.
 *
 * Scope: public web only, one metro per call.
 */

import type { FirecrawlClient, FirecrawlSearchResult } from "./client.js";

// ---------------------------------------------------------------------------
// Input / output types
// ---------------------------------------------------------------------------

export interface DiscoverDomainsInput {
  /** City and state, e.g. "Austin, TX" */
  metro: string;
  /**
   * Additional query terms appended to the base search.
   * e.g. ["extended stay", "corporate apartment"]
   */
  queryTerms?: string[];
  /** Maximum number of search results to retrieve. Default: 20. */
  limit?: number;
  /** The operator's own domain — excluded from results. */
  operatorDomain?: string;
}

export interface DiscoveredDomain {
  domain: string;
  sourceUrl: string;
  title: string | null;
  snippet: string | null;
}

export interface DiscoverDomainsResult {
  metro: string;
  domains: DiscoveredDomain[];
  queryCount: number;
}

// ---------------------------------------------------------------------------
// Discovery queries
// ---------------------------------------------------------------------------

const BASE_QUERY_TEMPLATES = [
  "{metro} corporate housing furnished apartments",
  "{metro} extended stay furnished rentals monthly",
  "{metro} short term furnished apartments corporate",
] as const;

function buildQueries(metro: string, extraTerms: string[]): string[] {
  const base = BASE_QUERY_TEMPLATES.map((t) => t.replace("{metro}", metro));
  const extras = extraTerms.map(
    (term) => `${metro} ${term} furnished apartments`,
  );
  return [...base, ...extras];
}

// ---------------------------------------------------------------------------
// Domain extraction
// ---------------------------------------------------------------------------

function extractDomain(url: string): string | null {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

function toDiscoveredDomain(
  result: FirecrawlSearchResult,
): DiscoveredDomain | null {
  const domain = extractDomain(result.url);
  if (!domain) return null;

  return {
    domain,
    sourceUrl: result.url,
    title: result.title ?? null,
    snippet: result.description ?? null,
  };
}

// ---------------------------------------------------------------------------
// Main function
// ---------------------------------------------------------------------------

export async function discoverDomains(
  client: FirecrawlClient,
  input: DiscoverDomainsInput,
): Promise<DiscoverDomainsResult> {
  const queries = buildQueries(input.metro, input.queryTerms ?? []);
  const perQueryLimit = Math.ceil((input.limit ?? 20) / queries.length);

  const seen = new Set<string>();
  if (input.operatorDomain) {
    seen.add(input.operatorDomain.replace(/^www\./, ""));
  }

  const domains: DiscoveredDomain[] = [];

  for (const query of queries) {
    const response = await client.search(query, {
      limit: perQueryLimit,
      lang: "en",
    });

    for (const result of response.data) {
      const discovered = toDiscoveredDomain(result);
      if (!discovered) continue;
      if (seen.has(discovered.domain)) continue;

      seen.add(discovered.domain);
      domains.push(discovered);
    }
  }

  return {
    metro: input.metro,
    domains,
    queryCount: queries.length,
  };
}

// ---------------------------------------------------------------------------
// Fixtures (for tests — no network required)
// ---------------------------------------------------------------------------

export const FIXTURES = {
  input: {
    metro: "Austin, TX",
    operatorDomain: "mycompany.com",
  } satisfies DiscoverDomainsInput,

  result: {
    metro: "Austin, TX",
    queryCount: 3,
    domains: [
      {
        domain: "example-housing.com",
        sourceUrl: "https://example-housing.com",
        title: "Example Corporate Housing — Austin TX",
        snippet: "Furnished apartments for corporate travelers in Austin",
      },
      {
        domain: "stay-austin.com",
        sourceUrl: "https://stay-austin.com",
        title: "Stay Austin — Extended Stay Apartments",
        snippet: "Monthly furnished rentals in downtown Austin",
      },
    ],
  } satisfies DiscoverDomainsResult,
} as const;
