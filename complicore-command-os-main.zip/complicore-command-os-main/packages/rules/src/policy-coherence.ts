/**
 * Rule family: policy_coherence
 *
 * Is the policy specific enough for a guest to act on?
 * A policy that exists but is too vague to understand is a coherence failure.
 *
 * Applicable page types: any page that carries policy observations.
 * The rule skips pages with no policy observations.
 */

import {
  type RuleContext,
  type RuleFamilyResult,
  pass,
  violation,
} from "./index.js";

/** Minimum character length for a policy to be considered substantive. */
const MIN_POLICY_CHARS = 20;

export function evaluatePolicyCoherence(
  context: RuleContext,
): RuleFamilyResult {
  const { page, normalized, screenshot_ref } = context;
  const policies = normalized.policy_observations;

  if (policies.length === 0) {
    return pass(
      "policy_coherence",
      "No policy observations on this page — rule not applicable.",
    );
  }

  const violations: RuleFamilyResult["violations"] = [];

  for (const policy of policies) {
    const summaryLength = policy.policy_summary.trim().length;

    if (summaryLength < MIN_POLICY_CHARS) {
      // Policy exists but is too short to convey actionable terms.
      violations.push(
        violation("policy_coherence", "fail", {
          severity: "medium",
          confidence: "high",
          description:
            `The ${policy.policy_type} policy is present but too vague to act on ` +
            `(${summaryLength} characters — minimum is ${MIN_POLICY_CHARS}). ` +
            "A policy of this length cannot provide guests with meaningful notice.",
          snippet: policy.policy_summary || "(policy text not extractable)",
          source_url: page.url,
          screenshot_ref,
        }),
      );
      continue;
    }

    if (policy.policy_url === null) {
      // Policy is inline only — no permanent URL.
      // This is an uncertainty: the policy might be on a separate page
      // that was not linked in the scraped content.
      violations.push(
        violation("policy_coherence", "uncertain_needs_review", {
          severity: "medium",
          confidence: "medium",
          description:
            `The ${policy.policy_type} policy is present inline but no dedicated policy ` +
            "page URL was found. This may be intentional (inline policy) or a sign that " +
            "the policy lacks a durable, linkable location. Reviewer should confirm.",
          snippet: policy.policy_summary.slice(0, 200),
          source_url: page.url,
          screenshot_ref,
        }),
      );
    }
  }

  const hasViolations = violations.length > 0;
  const hasFailures = violations.some((v) => v.result === "fail");

  return {
    rule_family: "policy_coherence",
    result: hasFailures ? "fail" : hasViolations ? "uncertain_needs_review" : "pass",
    violations,
  };
}
