/**
 * Rule family: privacy_presence
 *
 * Does the operator's web presence include a privacy policy?
 *
 * Evaluated on homepages only. The homepage is the most reliable indicator
 * of domain-level privacy posture — if a privacy policy link is absent
 * from the homepage, the domain likely lacks one entirely.
 *
 * Applicable page types: homepage
 */

import {
  type RuleContext,
  type RuleFamilyResult,
  contextSnippet,
  pass,
  violation,
} from "./index.js";

export function evaluatePrivacyPresence(
  context: RuleContext,
): RuleFamilyResult {
  const { page, normalized, screenshot_ref } = context;

  if (page.content_type !== "homepage") {
    return pass(
      "privacy_presence",
      `Page type "${page.content_type}" — privacy presence is evaluated on homepage only.`,
    );
  }

  const privacyGap = normalized.content_gaps.find(
    (g) => g.gap_type === "no_privacy_policy",
  );

  if (!privacyGap) {
    return pass("privacy_presence");
  }

  const text = page.text_content ?? "";

  return {
    rule_family: "privacy_presence",
    result: "fail",
    violations: [
      violation("privacy_presence", "fail", {
        severity: "high",
        confidence: "high",
        description:
          "No privacy policy was found on the homepage. " +
          "Operating a transactional website without a privacy policy is a compliance risk " +
          "in most jurisdictions (CCPA, GDPR, state-level requirements).",
        snippet: contextSnippet(text) || "(no content extracted)",
        source_url: page.url,
        screenshot_ref,
      }),
    ],
  };
}
