/**
 * Rule family: schema_quality
 *
 * Does the page carry machine-readable structured data?
 * Listing pages without schema.org markup are invisible to search aggregators
 * and may signal underinvestment in web operations.
 *
 * Applicable page types: listing_detail
 */

import {
  type RuleContext,
  type RuleFamilyResult,
  contextSnippet,
  pass,
  violation,
} from "./index.js";

/** Schema.org types that indicate a well-formed lodging/property listing. */
const RELEVANT_SCHEMA_TYPES = [
  "LodgingBusiness",
  "Accommodation",
  "Product",
  "Apartment",
  "House",
  "RentalAction",
];

export function evaluateSchemaQuality(
  context: RuleContext,
): RuleFamilyResult {
  const { page, normalized, screenshot_ref } = context;

  if (page.content_type !== "listing_detail") {
    return pass(
      "schema_quality",
      `Page type "${page.content_type}" — schema quality is evaluated on listing_detail pages only.`,
    );
  }

  const obs = normalized.schema_observation;
  const text = page.text_content ?? "";
  const violations: RuleFamilyResult["violations"] = [];

  if (!obs) {
    // Raw HTML was unavailable — cannot evaluate structured data.
    return pass(
      "schema_quality",
      "No schema_observation (raw_html was null) — evaluation skipped.",
    );
  }

  if (!obs.has_structured_data) {
    violations.push(
      violation("schema_quality", "fail", {
        severity: "medium",
        confidence: "high",
        description:
          "This listing page has no machine-readable structured data (JSON-LD, schema.org). " +
          "Search engines and aggregators cannot extract unit details, pricing, or availability. " +
          "This is a competitive disadvantage in organic discovery.",
        snippet: contextSnippet(text) || "(no content extracted)",
        source_url: page.url,
        screenshot_ref,
      }),
    );
  } else {
    // Structured data is present — check for relevant types.
    const hasRelevantType = obs.schema_types_found.some((t) =>
      RELEVANT_SCHEMA_TYPES.includes(t),
    );

    if (!hasRelevantType) {
      const foundTypes =
        obs.schema_types_found.length > 0
          ? obs.schema_types_found.join(", ")
          : "none detected";

      violations.push(
        violation("schema_quality", "uncertain_needs_review", {
          severity: "medium",
          confidence: "medium",
          description:
            `Structured data is present but does not include a lodging-relevant type ` +
            `(found: ${foundTypes}; expected one of: ${RELEVANT_SCHEMA_TYPES.join(", ")}). ` +
            "Reviewer should verify the schema types are appropriate for a rental listing.",
          snippet: contextSnippet(text),
          source_url: page.url,
          screenshot_ref,
        }),
      );
    }
  }

  const hasViolations = violations.length > 0;
  const hasFailures = violations.some((v) => v.result === "fail");

  return {
    rule_family: "schema_quality",
    result: hasFailures ? "fail" : hasViolations ? "uncertain_needs_review" : "pass",
    violations,
  };
}
