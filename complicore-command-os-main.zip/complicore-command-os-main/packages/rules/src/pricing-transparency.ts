/**
 * Rule families: pricing_transparency + fee_visibility.
 *
 * pricing_transparency — Is pricing present and parseable?
 * fee_visibility       — Are fees and total cost disclosed?
 *
 * Applicable page types: listing_detail, pricing, homepage
 */

import type { PageType } from "../../core/src/page-taxonomy.js";
import {
  type RuleContext,
  type RuleFamilyResult,
  contextSnippet,
  pass,
  violation,
} from "./index.js";

const APPLICABLE_TYPES: PageType[] = ["listing_detail", "pricing", "homepage"];

export function evaluatePricingTransparency(
  context: RuleContext,
): RuleFamilyResult {
  const { page, normalized, screenshot_ref } = context;

  if (!APPLICABLE_TYPES.includes(page.content_type)) {
    return pass(
      "pricing_transparency",
      `Page type "${page.content_type}" is out of scope for pricing rules.`,
    );
  }

  const text = page.text_content ?? "";
  const pricingObs = normalized.pricing_observations;
  const violations: RuleFamilyResult["violations"] = [];

  // -------------------------------------------------------------------------
  // pricing_transparency: price must be parseable
  // -------------------------------------------------------------------------

  if (pricingObs.length === 0) {
    // No price found on a page type expected to carry pricing.
    // homepage is not hard-required to show pricing, so use medium confidence.
    const severity = page.content_type === "pricing" ? "high" : "medium";
    const isHomepage = page.content_type === "homepage";

    violations.push(
      violation("pricing_transparency", isHomepage ? "uncertain_needs_review" : "fail", {
        severity,
        confidence: isHomepage ? "medium" : "high",
        description:
          page.content_type === "pricing"
            ? "A dedicated pricing page contains no detectable price information."
            : "No pricing information found on a page expected to surface rates.",
        snippet: contextSnippet(text) || "(empty page)",
        source_url: page.url,
        screenshot_ref,
      }),
    );
  } else {
    for (const obs of pricingObs) {
      // Price text exists but could not be parsed to a number.
      if (obs.price_numeric === null && obs.price_raw.length > 0) {
        violations.push(
          violation("pricing_transparency", "fail", {
            severity: "high",
            confidence: "high",
            description:
              `Pricing text is present ("${obs.price_raw}") but could not be parsed to a ` +
              "numeric value. This may indicate obfuscated or intentionally vague pricing.",
            snippet: obs.price_quote,
            source_url: page.url,
            screenshot_ref,
          }),
        );
      }

      // Price unit is unknown — rate period is not stated.
      if (obs.price_unit === "unknown" && obs.price_numeric !== null) {
        violations.push(
          violation("pricing_transparency", "uncertain_needs_review", {
            severity: "medium",
            confidence: "medium",
            description:
              `Price of $${obs.price_numeric.toLocaleString()} is shown without a stated ` +
              "rate period (per night, per week, per month). Requires human review.",
            snippet: obs.price_quote,
            source_url: page.url,
            screenshot_ref,
          }),
        );
      }
    }
  }

  // -------------------------------------------------------------------------
  // fee_visibility: fees and total cost must be disclosed
  // -------------------------------------------------------------------------

  for (const obs of pricingObs) {
    if (obs.fees_mentioned.length === 0 && !obs.total_cost_shown) {
      // No fee disclosure at all.
      violations.push(
        violation("fee_visibility" as (typeof violations)[0]["rule_family"], "fail", {
          severity: "medium",
          confidence: "high",
          description:
            "No fees are disclosed and no all-inclusive total is shown. " +
            "Guests cannot determine the true cost from this page.",
          snippet: obs.price_quote,
          source_url: page.url,
          screenshot_ref,
        }),
      );
    } else if (obs.fees_mentioned.length > 0 && !obs.total_cost_shown) {
      // Fees mentioned but no all-in total.
      violations.push(
        violation("fee_visibility" as (typeof violations)[0]["rule_family"], "uncertain_needs_review", {
          severity: "medium",
          confidence: "medium",
          description:
            `Fees are mentioned (${obs.fees_mentioned.slice(0, 3).join(", ")}) ` +
            "but no all-inclusive total price is shown. " +
            "Reviewer should confirm whether a total is available elsewhere on the page.",
          snippet: obs.price_quote,
          source_url: page.url,
          screenshot_ref,
        }),
      );
    }
  }

  const hasViolations = violations.length > 0;
  const hasFailures = violations.some((v) => v.result === "fail");

  return {
    rule_family: "pricing_transparency",
    result: hasFailures ? "fail" : hasViolations ? "uncertain_needs_review" : "pass",
    violations,
  };
}
