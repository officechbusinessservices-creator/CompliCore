/**
 * Rules engine tests — one describe block per rule family.
 * Every rule must have a pass case, a fail case, and an uncertain case
 * where the rule supports it.
 *
 * All fixtures use real-shaped data from packages/firecrawl/src/normalize.ts
 * and packages/core/src/types.ts. No fake production data.
 */

import { describe, it, expect } from "vitest";
import type { RuleContext } from "../index.js";
import type { SourcePage } from "../../../core/src/types.js";
import type { NormalizedPageData } from "../../../firecrawl/src/normalize.js";
import { evaluatePricingTransparency } from "../pricing-transparency.js";
import { evaluatePolicyCoherence } from "../policy-coherence.js";
import { evaluatePrivacyPresence } from "../privacy-presence.js";
import { evaluateDisclosureSignals } from "../disclosure-signals.js";
import { evaluateSchemaQuality } from "../schema-quality.js";
import { evaluateContactPath } from "../contact-path.js";
import { evaluateTrustSignals } from "../trust-signals.js";

// ---------------------------------------------------------------------------
// Test helpers
// ---------------------------------------------------------------------------

function makeContext(
  overrides: {
    pageType?: SourcePage["content_type"];
    textContent?: string;
    rawHtml?: string;
    normalized?: Partial<NormalizedPageData>;
    screenshotRef?: string | null;
  } = {},
): RuleContext {
  const pageId = "page-test-001";
  const domainId = "domain-test-001";
  const url = "https://example-housing.com/test-page";

  const page: SourcePage & { id: string } = {
    id: pageId,
    url_id: "url-001",
    domain_id: domainId,
    url,
    raw_html: overrides.rawHtml ?? "<html><head><title>Test</title></head><body></body></html>",
    text_content: overrides.textContent ?? "Test page content.",
    http_status: 200,
    scraped_at: "2026-03-29T00:00:00.000Z",
    content_type: overrides.pageType ?? "listing_detail",
    word_count: 3,
  };

  const defaultNormalized: NormalizedPageData = {
    source_page_id: pageId,
    listing: null,
    pricing_observations: [],
    policy_observations: [],
    schema_observation: null,
    content_gaps: [],
    extraction_notes: [],
  };

  return {
    run_id: "run-test-001",
    domain_id: domainId,
    page,
    normalized: { ...defaultNormalized, ...overrides.normalized },
    screenshot_ref: overrides.screenshotRef ?? "file://screenshot.png",
  };
}

function makePricingObs(
  opts: {
    priceRaw?: string;
    priceNumeric?: number | null;
    priceUnit?: "per_month" | "per_night" | "per_week" | "unknown";
    feesMentioned?: string[];
    totalCostShown?: boolean;
  } = {},
) {
  return {
    source_page_id: "page-test-001",
    domain_id: "domain-test-001",
    price_raw: opts.priceRaw ?? "$3,200/month",
    price_numeric: opts.priceNumeric !== undefined ? opts.priceNumeric : 3200,
    price_unit: opts.priceUnit ?? "per_month",
    fees_mentioned: opts.feesMentioned ?? [],
    total_cost_shown: opts.totalCostShown ?? false,
    price_quote: `From ${opts.priceRaw ?? "$3,200/month"}. Available now.`,
  };
}

function makePolicyObs(
  opts: {
    type?: "cancellation" | "refund" | "lease" | "house_rules" | "other";
    summary?: string;
    policyUrl?: string | null;
  } = {},
) {
  return {
    source_page_id: "page-test-001",
    domain_id: "domain-test-001",
    policy_type: opts.type ?? "cancellation",
    policy_summary:
      opts.summary ?? "30-day notice required for full refund.",
    policy_url: opts.policyUrl !== undefined ? opts.policyUrl : "https://example-housing.com/terms",
  };
}

// ---------------------------------------------------------------------------
// pricing_transparency + fee_visibility
// ---------------------------------------------------------------------------

describe("pricing_transparency", () => {
  it("pass: price is numeric with known unit and fees disclosed", () => {
    const ctx = makeContext({
      pageType: "listing_detail",
      normalized: {
        pricing_observations: [
          makePricingObs({
            priceNumeric: 3200,
            priceUnit: "per_month",
            feesMentioned: ["cleaning fee"],
            totalCostShown: true,
          }),
        ],
      },
    });
    const result = evaluatePricingTransparency(ctx);
    expect(result.result).toBe("pass");
    expect(result.violations).toHaveLength(0);
  });

  it("fail: dedicated pricing page has no price", () => {
    const ctx = makeContext({
      pageType: "pricing",
      textContent: "Our pricing page. Contact us for rates.",
      normalized: { pricing_observations: [] },
    });
    const result = evaluatePricingTransparency(ctx);
    expect(result.result).toBe("fail");
    const v = result.violations[0];
    expect(v.rule_family).toBe("pricing_transparency");
    expect(v.severity).toBe("high");
    expect(v.confidence).toBe("high");
    expect(v.snippet.length).toBeGreaterThan(0);
    expect(v.reviewer_status).toBe("pending");
  });

  it("fail: price text present but not parseable (obfuscated)", () => {
    const ctx = makeContext({
      pageType: "listing_detail",
      normalized: {
        pricing_observations: [
          makePricingObs({ priceRaw: "Call for rates", priceNumeric: null }),
        ],
      },
    });
    const result = evaluatePricingTransparency(ctx);
    const failViolations = result.violations.filter((v) => v.result === "fail");
    expect(failViolations.length).toBeGreaterThan(0);
    expect(failViolations[0].severity).toBe("high");
  });

  it("uncertain_needs_review: price numeric but unit is unknown", () => {
    const ctx = makeContext({
      pageType: "listing_detail",
      normalized: {
        pricing_observations: [
          makePricingObs({ priceNumeric: 3200, priceUnit: "unknown" }),
        ],
      },
    });
    const result = evaluatePricingTransparency(ctx);
    const uncertain = result.violations.filter(
      (v) => v.result === "uncertain_needs_review",
    );
    expect(uncertain.length).toBeGreaterThan(0);
    expect(uncertain[0].reviewer_status).toBe("needs_review");
  });

  it("fail (fee_visibility): fees absent and no total shown", () => {
    const ctx = makeContext({
      pageType: "listing_detail",
      normalized: {
        pricing_observations: [
          makePricingObs({ feesMentioned: [], totalCostShown: false }),
        ],
      },
    });
    const result = evaluatePricingTransparency(ctx);
    const feeViolations = result.violations.filter(
      (v) => v.rule_family === "fee_visibility",
    );
    expect(feeViolations.length).toBeGreaterThan(0);
    expect(feeViolations[0].result).toBe("fail");
  });

  it("uncertain (fee_visibility): fees mentioned but no all-in total", () => {
    const ctx = makeContext({
      pageType: "listing_detail",
      normalized: {
        pricing_observations: [
          makePricingObs({ feesMentioned: ["cleaning fee"], totalCostShown: false }),
        ],
      },
    });
    const result = evaluatePricingTransparency(ctx);
    const feeViolations = result.violations.filter(
      (v) => v.rule_family === "fee_visibility",
    );
    expect(feeViolations[0].result).toBe("uncertain_needs_review");
  });

  it("skip: non-applicable page type returns pass with skip_reason", () => {
    const ctx = makeContext({ pageType: "blog_content" });
    const result = evaluatePricingTransparency(ctx);
    expect(result.result).toBe("pass");
    expect(result.skip_reason).toBeDefined();
  });
});

// ---------------------------------------------------------------------------
// policy_coherence
// ---------------------------------------------------------------------------

describe("policy_coherence", () => {
  it("pass: cancellation policy is substantive with a dedicated URL", () => {
    const ctx = makeContext({
      normalized: {
        policy_observations: [makePolicyObs()],
      },
    });
    const result = evaluatePolicyCoherence(ctx);
    expect(result.result).toBe("pass");
  });

  it("fail: cancellation policy summary is too short", () => {
    const ctx = makeContext({
      normalized: {
        policy_observations: [makePolicyObs({ summary: "No refunds." })],
      },
    });
    const result = evaluatePolicyCoherence(ctx);
    expect(result.result).toBe("fail");
    expect(result.violations[0].severity).toBe("medium");
    expect(result.violations[0].snippet).toBe("No refunds.");
  });

  it("uncertain_needs_review: substantive policy but no policy URL", () => {
    const ctx = makeContext({
      normalized: {
        policy_observations: [makePolicyObs({ policyUrl: null })],
      },
    });
    const result = evaluatePolicyCoherence(ctx);
    expect(result.result).toBe("uncertain_needs_review");
    expect(result.violations[0].reviewer_status).toBe("needs_review");
  });

  it("skip: no policy observations returns pass", () => {
    const ctx = makeContext({ normalized: { policy_observations: [] } });
    const result = evaluatePolicyCoherence(ctx);
    expect(result.result).toBe("pass");
    expect(result.skip_reason).toBeDefined();
  });
});

// ---------------------------------------------------------------------------
// privacy_presence
// ---------------------------------------------------------------------------

describe("privacy_presence", () => {
  it("pass: homepage with no privacy gap", () => {
    const ctx = makeContext({
      pageType: "homepage",
      normalized: { content_gaps: [] },
    });
    const result = evaluatePrivacyPresence(ctx);
    expect(result.result).toBe("pass");
  });

  it("fail: homepage has no_privacy_policy gap", () => {
    const ctx = makeContext({
      pageType: "homepage",
      textContent: "Welcome to Example Housing. Furnished apartments in Austin.",
      normalized: {
        content_gaps: [
          {
            source_page_id: "page-test-001",
            domain_id: "domain-test-001",
            gap_type: "no_privacy_policy",
            description: "No privacy policy link or mention found on the homepage.",
          },
        ],
      },
    });
    const result = evaluatePrivacyPresence(ctx);
    expect(result.result).toBe("fail");
    expect(result.violations[0].severity).toBe("high");
    expect(result.violations[0].confidence).toBe("high");
    expect(result.violations[0].reviewer_status).toBe("pending");
    expect(result.violations[0].snippet.length).toBeGreaterThan(0);
  });

  it("skip: non-homepage returns pass with skip_reason", () => {
    const ctx = makeContext({ pageType: "listing_detail" });
    const result = evaluatePrivacyPresence(ctx);
    expect(result.result).toBe("pass");
    expect(result.skip_reason).toBeDefined();
  });
});

// ---------------------------------------------------------------------------
// disclosure_signals
// ---------------------------------------------------------------------------

describe("disclosure_signals", () => {
  it("pass: pricing and cancellation policy both present", () => {
    const ctx = makeContext({
      normalized: {
        pricing_observations: [makePricingObs()],
        policy_observations: [makePolicyObs()],
      },
    });
    const result = evaluateDisclosureSignals(ctx);
    expect(result.result).toBe("pass");
  });

  it("fail: pricing present but no policies at all", () => {
    const ctx = makeContext({
      normalized: {
        pricing_observations: [makePricingObs()],
        policy_observations: [],
      },
    });
    const result = evaluateDisclosureSignals(ctx);
    expect(result.result).toBe("fail");
    expect(result.violations[0].severity).toBe("high");
  });

  it("uncertain_needs_review: fees disclosed but no cancellation policy", () => {
    const ctx = makeContext({
      normalized: {
        pricing_observations: [
          makePricingObs({ feesMentioned: ["cleaning fee", "security deposit"] }),
        ],
        policy_observations: [makePolicyObs({ type: "house_rules" })],
      },
    });
    const result = evaluateDisclosureSignals(ctx);
    expect(result.result).toBe("uncertain_needs_review");
  });

  it("skip: no pricing on page", () => {
    const ctx = makeContext({ normalized: { pricing_observations: [] } });
    const result = evaluateDisclosureSignals(ctx);
    expect(result.result).toBe("pass");
    expect(result.skip_reason).toBeDefined();
  });
});

// ---------------------------------------------------------------------------
// schema_quality
// ---------------------------------------------------------------------------

describe("schema_quality", () => {
  it("pass: listing_detail with LodgingBusiness schema", () => {
    const ctx = makeContext({
      pageType: "listing_detail",
      normalized: {
        schema_observation: {
          source_page_id: "page-test-001",
          has_structured_data: true,
          schema_types_found: ["LodgingBusiness"],
          title_present: true,
          meta_description_present: true,
        },
      },
    });
    const result = evaluateSchemaQuality(ctx);
    expect(result.result).toBe("pass");
  });

  it("fail: listing_detail with no structured data", () => {
    const ctx = makeContext({
      pageType: "listing_detail",
      textContent: "Furnished Studio — Downtown Austin. From $3,200/month.",
      normalized: {
        schema_observation: {
          source_page_id: "page-test-001",
          has_structured_data: false,
          schema_types_found: [],
          title_present: true,
          meta_description_present: false,
        },
      },
    });
    const result = evaluateSchemaQuality(ctx);
    expect(result.result).toBe("fail");
    expect(result.violations[0].severity).toBe("medium");
    expect(result.violations[0].confidence).toBe("high");
  });

  it("uncertain_needs_review: structured data present but wrong type", () => {
    const ctx = makeContext({
      pageType: "listing_detail",
      normalized: {
        schema_observation: {
          source_page_id: "page-test-001",
          has_structured_data: true,
          schema_types_found: ["WebPage", "BreadcrumbList"],
          title_present: true,
          meta_description_present: true,
        },
      },
    });
    const result = evaluateSchemaQuality(ctx);
    expect(result.result).toBe("uncertain_needs_review");
    expect(result.violations[0].reviewer_status).toBe("needs_review");
  });

  it("skip: non-listing_detail page type", () => {
    const ctx = makeContext({ pageType: "pricing" });
    const result = evaluateSchemaQuality(ctx);
    expect(result.result).toBe("pass");
    expect(result.skip_reason).toBeDefined();
  });
});

// ---------------------------------------------------------------------------
// contact_path_completeness
// ---------------------------------------------------------------------------

describe("contact_path_completeness", () => {
  it("pass: no contact gap on homepage", () => {
    const ctx = makeContext({
      pageType: "homepage",
      normalized: { content_gaps: [] },
    });
    const result = evaluateContactPath(ctx);
    expect(result.result).toBe("pass");
  });

  it("fail: homepage has no_contact_path gap", () => {
    const ctx = makeContext({
      pageType: "homepage",
      textContent: "Welcome to Example Housing. Furnished apartments in Austin.",
      normalized: {
        content_gaps: [
          {
            source_page_id: "page-test-001",
            domain_id: "domain-test-001",
            gap_type: "no_contact_path",
            description: "No contact path found.",
          },
        ],
      },
    });
    const result = evaluateContactPath(ctx);
    expect(result.result).toBe("fail");
    expect(result.violations[0].severity).toBe("high");
    expect(result.violations[0].confidence).toBe("high");
  });

  it("fail: listing_detail with no contact path", () => {
    const ctx = makeContext({
      pageType: "listing_detail",
      textContent: "1BR furnished apartment. $4,500/month.",
      normalized: {
        content_gaps: [
          {
            source_page_id: "page-test-001",
            domain_id: "domain-test-001",
            gap_type: "no_contact_path",
            description: "No contact path found.",
          },
        ],
      },
    });
    const result = evaluateContactPath(ctx);
    expect(result.result).toBe("fail");
  });

  it("skip: non-applicable page type", () => {
    const ctx = makeContext({ pageType: "blog_content" });
    const result = evaluateContactPath(ctx);
    expect(result.result).toBe("pass");
    expect(result.skip_reason).toBeDefined();
  });
});

// ---------------------------------------------------------------------------
// trust_signals
// ---------------------------------------------------------------------------

describe("trust_signals", () => {
  it("pass: homepage with no trust gap", () => {
    const ctx = makeContext({
      pageType: "homepage",
      normalized: { content_gaps: [] },
    });
    const result = evaluateTrustSignals(ctx);
    expect(result.result).toBe("pass");
  });

  it("fail: homepage with no_trust_signals gap", () => {
    const ctx = makeContext({
      pageType: "homepage",
      textContent: "Welcome to Example Housing. We offer furnished apartments.",
      normalized: {
        content_gaps: [
          {
            source_page_id: "page-test-001",
            domain_id: "domain-test-001",
            gap_type: "no_trust_signals",
            description: "No trust signals found on homepage.",
          },
        ],
      },
    });
    const result = evaluateTrustSignals(ctx);
    expect(result.result).toBe("fail");
    expect(result.violations[0].severity).toBe("medium");
    // Confidence is medium — trust signals may appear in images
    expect(result.violations[0].confidence).toBe("medium");
    expect(result.violations[0].snippet.length).toBeGreaterThan(0);
  });

  it("skip: non-homepage page type", () => {
    const ctx = makeContext({ pageType: "listing_detail" });
    const result = evaluateTrustSignals(ctx);
    expect(result.result).toBe("pass");
    expect(result.skip_reason).toBeDefined();
  });
});
