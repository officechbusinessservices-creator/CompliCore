/**
 * Rule family: trust_signals
 *
 * Does the homepage carry social proof or credibility markers?
 * Operators without visible trust signals (reviews, awards, accreditations)
 * are at a competitive disadvantage and may signal operational immaturity.
 *
 * Applicable page types: homepage
 */

import {
  type RuleContext,
  type RuleFamilyResult,
  contextSnippet,
  pass,
  violation,
} from "./index.js";

export function evaluateTrustSignals(
  context: RuleContext,
): RuleFamilyResult {
  const { page, normalized, screenshot_ref } = context;

  if (page.content_type !== "homepage") {
    return pass(
      "trust_signals",
      `Page type "${page.content_type}" — trust signals are evaluated on homepage only.`,
    );
  }

  const trustGap = normalized.content_gaps.find(
    (g) => g.gap_type === "no_trust_signals",
  );

  if (!trustGap) {
    return pass("trust_signals");
  }

  const text = page.text_content ?? "";

  return {
    rule_family: "trust_signals",
    result: "fail",
    violations: [
      violation("trust_signals", "fail", {
        severity: "medium",
        confidence: "medium",
        description:
          "No trust signals detected on the homepage (no reviews, testimonials, " +
          "awards, accreditations, or guest counts). " +
          "Competitors with visible social proof have a conversion advantage. " +
          "Confidence is medium — trust signals may appear below the fold or in images.",
        snippet: contextSnippet(text) || "(no content extracted)",
        source_url: page.url,
        screenshot_ref,
      }),
    ],
  };
}
