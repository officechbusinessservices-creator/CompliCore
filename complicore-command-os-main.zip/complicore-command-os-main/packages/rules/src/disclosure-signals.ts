/**
 * Rule family: disclosure_signals
 *
 * If a page shows pricing, does it also disclose at least one policy?
 * Operators who advertise rates without any policy terms create asymmetric
 * information for guests.
 *
 * This rule evaluates the combination of pricing and policy presence
 * on a single page. Domain-level cross-page analysis is a future extension.
 *
 * Applicable page types: any page with pricing observations.
 */

import {
  type RuleContext,
  type RuleFamilyResult,
  pass,
  violation,
} from "./index.js";

export function evaluateDisclosureSignals(
  context: RuleContext,
): RuleFamilyResult {
  const { page, normalized, screenshot_ref } = context;
  const hasPricing = normalized.pricing_observations.length > 0;

  if (!hasPricing) {
    return pass(
      "disclosure_signals",
      "No pricing observations on this page — disclosure rule not applicable.",
    );
  }

  const hasPolicies = normalized.policy_observations.length > 0;
  const violations: RuleFamilyResult["violations"] = [];

  if (!hasPolicies) {
    // Pricing is present; no policy of any type is present on the same page.
    const firstPrice = normalized.pricing_observations[0];
    violations.push(
      violation("disclosure_signals", "fail", {
        severity: "high",
        confidence: "high",
        description:
          "Pricing information is displayed without any accompanying policy terms " +
          "(no cancellation, refund, lease, or house rules). " +
          "Guests are shown a price but cannot evaluate the conditions of the agreement.",
        snippet: firstPrice.price_quote,
        source_url: page.url,
        screenshot_ref,
      }),
    );
  } else {
    // Check for the specific combination: fees present but no cancellation policy.
    const hasFees = normalized.pricing_observations.some(
      (o) => o.fees_mentioned.length > 0,
    );
    const hasCancellationPolicy = normalized.policy_observations.some(
      (p) => p.policy_type === "cancellation",
    );

    if (hasFees && !hasCancellationPolicy) {
      const obsWithFees = normalized.pricing_observations.find(
        (o) => o.fees_mentioned.length > 0,
      )!;
      violations.push(
        violation("disclosure_signals", "uncertain_needs_review", {
          severity: "medium",
          confidence: "medium",
          description:
            `Fees are disclosed (${obsWithFees.fees_mentioned.slice(0, 3).join(", ")}) ` +
            "but no cancellation policy is present on the same page. " +
            "Guests can see additional charges but not the conditions for refund. " +
            "Reviewer should check if cancellation terms appear elsewhere on the domain.",
          snippet: obsWithFees.price_quote,
          source_url: page.url,
          screenshot_ref,
        }),
      );
    }
  }

  const hasViolations = violations.length > 0;
  const hasFailures = violations.some((v) => v.result === "fail");

  return {
    rule_family: "disclosure_signals",
    result: hasFailures ? "fail" : hasViolations ? "uncertain_needs_review" : "pass",
    violations,
  };
}
