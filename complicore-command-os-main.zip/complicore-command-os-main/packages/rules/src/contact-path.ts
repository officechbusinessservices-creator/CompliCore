/**
 * Rule family: contact_path_completeness
 *
 * Can a prospective guest find a way to contact the operator?
 * A website that advertises units but provides no contact path
 * is a friction point and a trust signal failure.
 *
 * Applicable page types: homepage, listing_detail
 */

import type { PageType } from "../../core/src/page-taxonomy.js";
import {
  type RuleContext,
  type RuleFamilyResult,
  contextSnippet,
  pass,
  violation,
} from "./index.js";

const APPLICABLE_TYPES: PageType[] = ["homepage", "listing_detail"];

export function evaluateContactPath(
  context: RuleContext,
): RuleFamilyResult {
  const { page, normalized, screenshot_ref } = context;

  if (!APPLICABLE_TYPES.includes(page.content_type)) {
    return pass(
      "contact_path_completeness",
      `Page type "${page.content_type}" — contact path is evaluated on homepage and listing_detail only.`,
    );
  }

  const contactGap = normalized.content_gaps.find(
    (g) => g.gap_type === "no_contact_path",
  );

  if (!contactGap) {
    return pass("contact_path_completeness");
  }

  const text = page.text_content ?? "";

  return {
    rule_family: "contact_path_completeness",
    result: "fail",
    violations: [
      violation("contact_path_completeness", "fail", {
        severity: "high",
        confidence: "high",
        description:
          `No contact path was found on this ${page.content_type} page. ` +
          "A prospective guest cannot reach the operator by phone, email, form, or chat. " +
          "This is both a trust signal failure and a conversion barrier.",
        snippet: contextSnippet(text) || "(no content extracted)",
        source_url: page.url,
        screenshot_ref,
      }),
    ],
  };
}
