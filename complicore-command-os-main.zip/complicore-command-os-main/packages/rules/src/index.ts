/**
 * Rules engine for CompliCore Command OS.
 *
 * Applies all rule families to a normalized page and returns violations
 * ready for persistence as ComplianceFinding records.
 *
 * Pipeline position:
 *   discover → map → classify → scrape → normalize → rules → brief
 *
 * Design invariants:
 * - Every rule is a pure function: same input → same output.
 * - No side effects. No DB writes. No network calls.
 * - A finding without a snippet is never emitted (snippet may be a context
 *   window when the violation is the absence of content).
 * - "uncertain_needs_review" sets reviewer_status to "needs_review" so the
 *   reviewer agent gates it before publication.
 */

import type {
  Evidence,
  FindingSeverity,
  RuleFamily,
  SourcePage,
} from "../../core/src/types.js";
import type { NormalizedPageData } from "../../firecrawl/src/normalize.js";

import { evaluatePricingTransparency } from "./pricing-transparency.js";
import { evaluatePolicyCoherence } from "./policy-coherence.js";
import { evaluatePrivacyPresence } from "./privacy-presence.js";
import { evaluateDisclosureSignals } from "./disclosure-signals.js";
import { evaluateSchemaQuality } from "./schema-quality.js";
import { evaluateContactPath } from "./contact-path.js";
import { evaluateTrustSignals } from "./trust-signals.js";

// ---------------------------------------------------------------------------
// Core types
// ---------------------------------------------------------------------------

/** The three possible outcomes of evaluating a rule against a page. */
export type RuleResult = "pass" | "fail" | "uncertain_needs_review";

/**
 * All data a rule needs to evaluate a single page.
 * Rules must not perform any I/O.
 */
export interface RuleContext {
  run_id: string;
  domain_id: string;
  /** The scraped page, with its database-assigned id. */
  page: SourcePage & { id: string };
  /** Observations extracted from the page by the normalize step. */
  normalized: NormalizedPageData;
  /**
   * Reference to the screenshot taken during scrape, if one was captured.
   * Passed through to findings so the evidence viewer can show the screenshot.
   */
  screenshot_ref: string | null;
}

/**
 * A single rule violation, shaped to become a ComplianceFinding record.
 * `id` and `created_at` are assigned at write time.
 */
export interface RuleViolation {
  result: Exclude<RuleResult, "pass">;
  rule_family: RuleFamily;
  severity: FindingSeverity;

  // --- Evidence (all required) ---
  source_url: string;
  screenshot_ref: string | null;
  /**
   * Verbatim text extract from the page that supports this finding.
   * For absence-of-content violations, this is a context window showing
   * what the page DOES contain, establishing the finding is page-specific.
   */
  snippet: string;
  confidence: Evidence["confidence"];
  /**
   * "pending" for clear violations.
   * "needs_review" for uncertain findings — blocked from publication
   * until a reviewer approves.
   */
  reviewer_status: Evidence["reviewer_status"];

  description: string;
}

/**
 * Result of evaluating one rule family against one page.
 */
export interface RuleFamilyResult {
  rule_family: RuleFamily;
  result: RuleResult;
  /** Populated only when result is "fail" or "uncertain_needs_review". */
  violations: RuleViolation[];
  /**
   * Explanation when the rule family was not evaluated because the
   * page type is out of scope for this rule.
   */
  skip_reason?: string;
}

// ---------------------------------------------------------------------------
// Runner
// ---------------------------------------------------------------------------

type RuleEvaluator = (context: RuleContext) => RuleFamilyResult;

const RULE_EVALUATORS: RuleEvaluator[] = [
  evaluatePricingTransparency,
  evaluatePolicyCoherence,
  evaluatePrivacyPresence,
  evaluateDisclosureSignals,
  evaluateSchemaQuality,
  evaluateContactPath,
  evaluateTrustSignals,
];

/**
 * Evaluate all rule families against a single normalized page.
 * Returns one RuleFamilyResult per rule family evaluated.
 * Skipped families are included with result="pass" and a skip_reason.
 */
export function evaluateAllRules(context: RuleContext): RuleFamilyResult[] {
  return RULE_EVALUATORS.map((evaluate) => evaluate(context));
}

/**
 * Collect only violations from a set of rule family results.
 * Convenience for callers that only need findings for persistence.
 */
export function collectViolations(results: RuleFamilyResult[]): RuleViolation[] {
  return results.flatMap((r) => r.violations);
}

// ---------------------------------------------------------------------------
// Shared helpers (used across rule files)
// ---------------------------------------------------------------------------

/**
 * Extract a context snippet from the page's text content.
 * Used when the violation is the *absence* of content — the snippet
 * shows what the page does contain so the reviewer has context.
 *
 * @param text  Full page text content
 * @param chars Maximum characters to return (default 200)
 */
export function contextSnippet(text: string, chars = 200): string {
  return text.trim().slice(0, chars).replace(/\s+/g, " ");
}

/**
 * Build a pass result for a rule family. No violations.
 */
export function pass(family: RuleFamily, skipReason?: string): RuleFamilyResult {
  return {
    rule_family: family,
    result: "pass",
    violations: [],
    ...(skipReason !== undefined && { skip_reason: skipReason }),
  };
}

/**
 * Build a violation record with all required evidence fields populated.
 */
export function violation(
  family: RuleFamily,
  result: Exclude<RuleResult, "pass">,
  opts: {
    severity: FindingSeverity;
    confidence: Evidence["confidence"];
    description: string;
    snippet: string;
    source_url: string;
    screenshot_ref: string | null;
  },
): RuleViolation {
  return {
    result,
    rule_family: family,
    severity: opts.severity,
    source_url: opts.source_url,
    screenshot_ref: opts.screenshot_ref,
    snippet: opts.snippet,
    confidence: opts.confidence,
    reviewer_status: result === "uncertain_needs_review" ? "needs_review" : "pending",
    description: opts.description,
  };
}

// Re-export rule evaluators for direct use in tests
export {
  evaluatePricingTransparency,
  evaluatePolicyCoherence,
  evaluatePrivacyPresence,
  evaluateDisclosureSignals,
  evaluateSchemaQuality,
  evaluateContactPath,
  evaluateTrustSignals,
};
