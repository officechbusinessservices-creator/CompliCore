/**
 * Output contracts for CompliCore Command OS v1.
 *
 * These types define the published shape of each of the five v1 outputs:
 *   1. Weekly executive brief
 *   2. Compliance findings log
 *   3. Growth intelligence brief
 *   4. Acquisition target list
 *   5. Evidence viewer entry
 *
 * Output contracts are intentionally decoupled from the internal entity types.
 * They represent what a reviewer approves and what an operator receives.
 * Internal IDs are included for traceability but not expected to be rendered.
 */

import type {
  ComplianceFinding,
  ContentGapType,
  ISODatetime,
  OpportunityTarget,
  RuleFamily,
  RunStatus,
} from "./types.js";

// ---------------------------------------------------------------------------
// Evidence viewer
// ---------------------------------------------------------------------------

/**
 * A single entry in the evidence viewer.
 * Pairs a finding or signal with its source page and screenshot.
 *
 * This is the atomic unit of evidence — one claim, one source, one screenshot.
 */
export interface EvidenceViewerEntry {
  /** ID of the ComplianceFinding or OpportunityTarget this evidence supports. */
  finding_id: string;
  finding_type: "compliance_finding" | "opportunity_target";
  source_url: string;
  /** Verbatim quote from the source page. */
  snippet: string;
  /**
   * Reference to the screenshot file. Null if screenshot was not captured.
   * The evidence viewer must render the screenshot when present.
   */
  screenshot_ref: string | null;
  confidence: ComplianceFinding["confidence"];
  reviewer_status: ComplianceFinding["reviewer_status"];
  /** Rule family that produced this finding, if applicable. */
  rule_family: RuleFamily | null;
  domain: string;
  scraped_at: ISODatetime;
}

// ---------------------------------------------------------------------------
// Compliance findings log
// ---------------------------------------------------------------------------

/**
 * A single row in the compliance findings log.
 * Flattened from ComplianceFinding for display and export.
 */
export interface ComplianceFindingRow {
  finding_id: string;
  domain: string;
  rule_family: RuleFamily;
  severity: ComplianceFinding["severity"];
  rule_result: ComplianceFinding["rule_result"];
  description: string;
  source_url: string;
  snippet: string;
  screenshot_ref: string | null;
  confidence: ComplianceFinding["confidence"];
  reviewer_status: ComplianceFinding["reviewer_status"];
  created_at: ISODatetime;
}

/**
 * The full compliance findings log for one run.
 * This is the output that a reviewer approves before publication.
 */
export interface ComplianceFindingsLog {
  run_id: string;
  metro: string;
  generated_at: ISODatetime;
  approved_at: ISODatetime | null;
  /**
   * Total counts for the reviewer summary header.
   */
  summary: {
    total_findings: number;
    high_severity_count: number;
    medium_severity_count: number;
    domains_audited: number;
    domains_with_findings: number;
  };
  findings: ComplianceFindingRow[];
}

// ---------------------------------------------------------------------------
// Acquisition target list
// ---------------------------------------------------------------------------

/**
 * A single row in the acquisition target list.
 * Score and signals are shown; raw breakdown is available for drill-down.
 */
export interface AcquisitionTargetRow {
  target_id: string;
  domain: string;
  score: number;
  signal_tier: OpportunityTarget["signal_tier"];
  top_signals: string[];
  /** One sentence — what the signals show. No speculation about owner intent. */
  recommendation: string;
  contributing_finding_count: number;
  contributing_gap_count: number;
  reviewer_status: OpportunityTarget["reviewer_status"];
  created_at: ISODatetime;
}

/**
 * The full acquisition target list for one run.
 */
export interface AcquisitionTargetList {
  run_id: string;
  metro: string;
  generated_at: ISODatetime;
  approved_at: ISODatetime | null;
  summary: {
    total_targets: number;
    high_signal_count: number;
    moderate_signal_count: number;
    low_signal_count: number;
  };
  targets: AcquisitionTargetRow[];
}

// ---------------------------------------------------------------------------
// Growth intelligence brief
// ---------------------------------------------------------------------------

/** A market-level gap — a weakness shared by multiple competitors. */
export interface GrowthGapItem {
  rule_family: RuleFamily;
  /** Number of competitor domains that failed this rule family. */
  competitor_fail_count: number;
  market_gap_signal: "strong" | "moderate" | "weak";
  /**
   * One sentence — what the operator can do differently to stand out.
   * Must be grounded in the findings, not generic advice.
   */
  operator_differentiation_opportunity: string;
  /** Domain-level content gaps contributing to this market signal. */
  contributing_gap_types: ContentGapType[];
}

/**
 * The growth intelligence brief for one run.
 */
export interface GrowthIntelligenceBrief {
  run_id: string;
  metro: string;
  generated_at: ISODatetime;
  approved_at: ISODatetime | null;
  summary: {
    growth_gaps_identified: number;
    strong_signal_count: number;
    domains_analyzed: number;
  };
  growth_gaps: GrowthGapItem[];
}

// ---------------------------------------------------------------------------
// Weekly executive brief
// ---------------------------------------------------------------------------

/**
 * A single section of the weekly brief.
 * Each section maps to one of the four intelligence modules.
 */
export interface WeeklyBriefSection {
  title: string;
  module:
    | "market_intelligence"
    | "compliance"
    | "growth"
    | "acquisition";
  /**
   * The body of this section.
   * Each paragraph must cite at least one finding_id or target_id.
   * Uncited paragraphs must be flagged needs_review before approval.
   */
  paragraphs: WeeklyBriefParagraph[];
}

export interface WeeklyBriefParagraph {
  text: string;
  /** IDs of ComplianceFinding or OpportunityTarget records cited in this paragraph. */
  citation_ids: string[];
  /**
   * True if this paragraph has been reviewed and approved.
   * A section with any unapproved paragraph blocks the brief from approval.
   */
  approved: boolean;
}

/**
 * The weekly executive brief — the primary output delivered to the operator.
 *
 * Approval rules:
 * - All sections must have at least one paragraph.
 * - All paragraphs must be approved.
 * - No paragraph may have an empty citation_ids array (every claim needs a source).
 * - report.status must be "approved" before export is permitted.
 */
export interface WeeklyExecutiveBrief {
  run_id: string;
  metro: string;
  /** Week ending date, ISO 8601 date string (not datetime). */
  week_ending: string;
  generated_at: ISODatetime;
  approved_at: ISODatetime | null;
  exported_at: ISODatetime | null;
  run_status: RunStatus;
  sections: WeeklyBriefSection[];
  /**
   * High-level counts surfaced at the top of the brief.
   */
  headline_metrics: {
    compliance_findings_this_week: number;
    high_severity_findings: number;
    acquisition_targets_identified: number;
    high_signal_targets: number;
    growth_gaps_identified: number;
    domains_monitored: number;
  };
}
