/**
 * Drizzle ORM schema for CompliCore Command OS.
 *
 * Design decisions:
 * - pgEnum used only for gate-critical fields (reviewer_status, confidence,
 *   run_status, step_status, finding_status, report_status). These are
 *   enforced at the DB level because they gate publication.
 * - All other "enum-like" domain fields use `text`. TypeScript types in
 *   types.ts enforce them at compile time without making enum migrations brittle.
 * - Arrays (amenities, fees_mentioned, etc.) stored as jsonb for compatibility
 *   with the neon-http serverless driver.
 * - Timestamps are `timestamp with timezone`. Repos convert Date → ISODatetime.
 * - audit_events is append-only by convention. The repo intentionally exports
 *   no update or delete operations.
 */

import {
  boolean,
  integer,
  json,
  pgEnum,
  pgTable,
  real,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

// ---------------------------------------------------------------------------
// Gate-critical enums (DB-level enforcement)
// ---------------------------------------------------------------------------

export const reviewerStatusEnum = pgEnum("reviewer_status", [
  "pending",
  "approved",
  "needs_review",
  "rejected",
]);

export const confidenceEnum = pgEnum("confidence", ["high", "medium", "low"]);

export const runStatusEnum = pgEnum("run_status", [
  "pending",
  "running",
  "completed",
  "failed",
  "cancelled",
]);

export const stepStatusEnum = pgEnum("step_status", [
  "pending",
  "running",
  "completed",
  "failed",
  "skipped",
]);

export const findingStatusEnum = pgEnum("finding_status", [
  "open",
  "approved",
  "needs_review",
  "rejected",
]);

export const reportStatusEnum = pgEnum("report_status", [
  "draft",
  "approved",
  "exported",
]);

// ---------------------------------------------------------------------------
// workspaces
// ---------------------------------------------------------------------------

export const workspaces = pgTable("workspaces", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  metro: text("metro").notNull(),
  operator_domain: text("operator_domain").notNull(),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---------------------------------------------------------------------------
// objectives
// ---------------------------------------------------------------------------

export const objectives = pgTable("objectives", {
  id: uuid("id").defaultRandom().primaryKey(),
  workspace_id: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id),
  // ObjectiveType: compliance | market_intelligence | growth | acquisition
  type: text("type").notNull(),
  description: text("description").notNull(),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---------------------------------------------------------------------------
// runs
// ---------------------------------------------------------------------------

export const runs = pgTable("runs", {
  id: uuid("id").defaultRandom().primaryKey(),
  workspace_id: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id),
  status: runStatusEnum("status").notNull().default("pending"),
  metro: text("metro").notNull(),
  started_at: timestamp("started_at", { withTimezone: true }),
  completed_at: timestamp("completed_at", { withTimezone: true }),
  error: text("error"),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---------------------------------------------------------------------------
// steps
// ---------------------------------------------------------------------------

export const steps = pgTable("steps", {
  id: uuid("id").defaultRandom().primaryKey(),
  run_id: uuid("run_id")
    .notNull()
    .references(() => runs.id),
  // StepName: discover | map | classify | scrape | normalize | rules | brief
  name: text("name").notNull(),
  status: stepStatusEnum("status").notNull().default("pending"),
  input_count: integer("input_count").notNull().default(0),
  output_count: integer("output_count").notNull().default(0),
  error: text("error"),
  started_at: timestamp("started_at", { withTimezone: true }),
  completed_at: timestamp("completed_at", { withTimezone: true }),
});

// ---------------------------------------------------------------------------
// audit_events — APPEND-ONLY. No update or delete.
// ---------------------------------------------------------------------------

export const auditEvents = pgTable("audit_events", {
  id: uuid("id").defaultRandom().primaryKey(),
  workspace_id: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id),
  run_id: uuid("run_id").references(() => runs.id),
  // AuditActor: system | reviewer
  actor: text("actor").notNull(),
  actor_id: text("actor_id"),
  action: text("action").notNull(),
  entity_type: text("entity_type").notNull(),
  entity_id: text("entity_id").notNull(),
  payload: json("payload").$type<Record<string, unknown>>().notNull().default({}),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---------------------------------------------------------------------------
// domains
// ---------------------------------------------------------------------------

export const domains = pgTable("domains", {
  id: uuid("id").defaultRandom().primaryKey(),
  run_id: uuid("run_id")
    .notNull()
    .references(() => runs.id),
  domain: text("domain").notNull(),
  robots_txt_url: text("robots_txt_url"),
  disallowed_paths: json("disallowed_paths").$type<string[]>().notNull().default([]),
  sitemap_url: text("sitemap_url"),
  // DomainStatus: mapped | blocked | unreachable
  status: text("status").notNull().default("mapped"),
  crawled_at: timestamp("crawled_at", { withTimezone: true }),
});

// ---------------------------------------------------------------------------
// source_urls
// ---------------------------------------------------------------------------

export const sourceUrls = pgTable("source_urls", {
  id: uuid("id").defaultRandom().primaryKey(),
  domain_id: uuid("domain_id")
    .notNull()
    .references(() => domains.id),
  url: text("url").notNull(),
  // PageType from page-taxonomy
  content_type_hint: text("content_type_hint").notNull(),
  depth: integer("depth").notNull().default(0),
  // UrlStatus: pending | scraped | failed | skipped
  status: text("status").notNull().default("pending"),
  discovered_at: timestamp("discovered_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---------------------------------------------------------------------------
// source_pages
// ---------------------------------------------------------------------------

export const sourcePages = pgTable("source_pages", {
  id: uuid("id").defaultRandom().primaryKey(),
  url_id: uuid("url_id")
    .notNull()
    .references(() => sourceUrls.id),
  domain_id: uuid("domain_id")
    .notNull()
    .references(() => domains.id),
  url: text("url").notNull(),
  raw_html: text("raw_html"),
  text_content: text("text_content"),
  http_status: integer("http_status").notNull(),
  scraped_at: timestamp("scraped_at", { withTimezone: true }).defaultNow().notNull(),
  content_type: text("content_type").notNull(),
  word_count: integer("word_count"),
});

// ---------------------------------------------------------------------------
// screenshots
// ---------------------------------------------------------------------------

export const screenshots = pgTable("screenshots", {
  id: uuid("id").defaultRandom().primaryKey(),
  source_page_id: uuid("source_page_id")
    .notNull()
    .references(() => sourcePages.id),
  file_ref: text("file_ref").notNull(),
  width: integer("width").notNull(),
  height: integer("height").notNull(),
  captured_at: timestamp("captured_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---------------------------------------------------------------------------
// listings
// ---------------------------------------------------------------------------

export const listings = pgTable("listings", {
  id: uuid("id").defaultRandom().primaryKey(),
  source_page_id: uuid("source_page_id")
    .notNull()
    .references(() => sourcePages.id),
  domain_id: uuid("domain_id")
    .notNull()
    .references(() => domains.id),
  unit_name: text("unit_name"),
  bedroom_count: integer("bedroom_count"),
  bathroom_count: integer("bathroom_count"),
  square_footage: integer("square_footage"),
  amenities: json("amenities").$type<string[]>().notNull().default([]),
  minimum_stay_nights: integer("minimum_stay_nights"),
  availability_mentioned: boolean("availability_mentioned").notNull().default(false),
});

// ---------------------------------------------------------------------------
// pricing_observations
// ---------------------------------------------------------------------------

export const pricingObservations = pgTable("pricing_observations", {
  id: uuid("id").defaultRandom().primaryKey(),
  source_page_id: uuid("source_page_id")
    .notNull()
    .references(() => sourcePages.id),
  domain_id: uuid("domain_id")
    .notNull()
    .references(() => domains.id),
  price_raw: text("price_raw").notNull(),
  price_numeric: real("price_numeric"),
  // PriceUnit: per_night | per_month | per_week | unknown
  price_unit: text("price_unit").notNull().default("unknown"),
  fees_mentioned: json("fees_mentioned").$type<string[]>().notNull().default([]),
  total_cost_shown: boolean("total_cost_shown").notNull().default(false),
  price_quote: text("price_quote").notNull(),
});

// ---------------------------------------------------------------------------
// policy_observations
// ---------------------------------------------------------------------------

export const policyObservations = pgTable("policy_observations", {
  id: uuid("id").defaultRandom().primaryKey(),
  source_page_id: uuid("source_page_id")
    .notNull()
    .references(() => sourcePages.id),
  domain_id: uuid("domain_id")
    .notNull()
    .references(() => domains.id),
  // PolicyType: cancellation | refund | lease | house_rules | other
  policy_type: text("policy_type").notNull(),
  policy_summary: text("policy_summary").notNull(),
  policy_url: text("policy_url"),
});

// ---------------------------------------------------------------------------
// schema_observations
// ---------------------------------------------------------------------------

export const schemaObservations = pgTable("schema_observations", {
  id: uuid("id").defaultRandom().primaryKey(),
  source_page_id: uuid("source_page_id")
    .notNull()
    .references(() => sourcePages.id),
  has_structured_data: boolean("has_structured_data").notNull().default(false),
  schema_types_found: json("schema_types_found").$type<string[]>().notNull().default([]),
  title_present: boolean("title_present").notNull().default(false),
  meta_description_present: boolean("meta_description_present").notNull().default(false),
});

// ---------------------------------------------------------------------------
// content_gaps
// ---------------------------------------------------------------------------

export const contentGaps = pgTable("content_gaps", {
  id: uuid("id").defaultRandom().primaryKey(),
  source_page_id: uuid("source_page_id")
    .notNull()
    .references(() => sourcePages.id),
  domain_id: uuid("domain_id")
    .notNull()
    .references(() => domains.id),
  // ContentGapType: no_pricing | no_cancellation_policy | ... | other
  gap_type: text("gap_type").notNull(),
  description: text("description").notNull(),
});

// ---------------------------------------------------------------------------
// compliance_findings
// ---------------------------------------------------------------------------
// Flattens Evidence fields inline (source_url, screenshot_ref, snippet,
// confidence, reviewer_status) alongside finding-specific fields.

export const complianceFindings = pgTable("compliance_findings", {
  id: uuid("id").defaultRandom().primaryKey(),
  source_page_id: uuid("source_page_id")
    .notNull()
    .references(() => sourcePages.id),
  domain_id: uuid("domain_id")
    .notNull()
    .references(() => domains.id),
  run_id: uuid("run_id")
    .notNull()
    .references(() => runs.id),
  // RuleFamily text
  rule_family: text("rule_family").notNull(),
  // FindingResult: FAIL | WARN
  rule_result: text("rule_result").notNull(),
  // FindingSeverity: high | medium
  severity: text("severity").notNull(),
  description: text("description").notNull(),
  // FindingStatus (mirrors finding_status_enum for this field)
  status: findingStatusEnum("status").notNull().default("open"),
  // Evidence fields (inlined)
  source_url: text("source_url").notNull(),
  screenshot_ref: text("screenshot_ref"),
  snippet: text("snippet").notNull(),
  confidence: confidenceEnum("confidence").notNull(),
  reviewer_status: reviewerStatusEnum("reviewer_status").notNull().default("pending"),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---------------------------------------------------------------------------
// opportunity_targets
// ---------------------------------------------------------------------------

export const opportunityTargets = pgTable("opportunity_targets", {
  id: uuid("id").defaultRandom().primaryKey(),
  domain_id: uuid("domain_id")
    .notNull()
    .references(() => domains.id),
  run_id: uuid("run_id")
    .notNull()
    .references(() => runs.id),
  score: integer("score").notNull(),
  // SignalTier: HIGH | MODERATE | LOW
  signal_tier: text("signal_tier").notNull(),
  score_breakdown: json("score_breakdown")
    .$type<{
      compliance_failure_density: number;
      content_gap_density: number;
      pricing_opacity_flag: number;
      policy_absence_flag: number;
      schema_quality_fail: number;
    }>()
    .notNull(),
  contributing_finding_ids: json("contributing_finding_ids").$type<string[]>().notNull().default([]),
  contributing_gap_ids: json("contributing_gap_ids").$type<string[]>().notNull().default([]),
  top_signals: json("top_signals").$type<string[]>().notNull().default([]),
  recommendation: text("recommendation").notNull(),
  reviewer_status: reviewerStatusEnum("reviewer_status").notNull().default("pending"),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---------------------------------------------------------------------------
// outbound_briefs
// ---------------------------------------------------------------------------

export const outboundBriefs = pgTable("outbound_briefs", {
  id: uuid("id").defaultRandom().primaryKey(),
  run_id: uuid("run_id")
    .notNull()
    .references(() => runs.id),
  opportunity_target_id: uuid("opportunity_target_id")
    .notNull()
    .references(() => opportunityTargets.id),
  content: text("content").notNull(),
  // OutboundBriefStatus: draft | approved | sent
  status: text("status").notNull().default("draft"),
  reviewer_status: reviewerStatusEnum("reviewer_status").notNull().default("pending"),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  approved_at: timestamp("approved_at", { withTimezone: true }),
});

// ---------------------------------------------------------------------------
// reports
// ---------------------------------------------------------------------------

export const reports = pgTable("reports", {
  id: uuid("id").defaultRandom().primaryKey(),
  run_id: uuid("run_id")
    .notNull()
    .references(() => runs.id),
  workspace_id: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id),
  // ReportType: weekly_brief | compliance_log | growth_brief | acquisition_list
  type: text("type").notNull(),
  status: reportStatusEnum("status").notNull().default("draft"),
  metro: text("metro").notNull(),
  generated_at: timestamp("generated_at", { withTimezone: true }).defaultNow().notNull(),
  approved_at: timestamp("approved_at", { withTimezone: true }),
  exported_at: timestamp("exported_at", { withTimezone: true }),
});
