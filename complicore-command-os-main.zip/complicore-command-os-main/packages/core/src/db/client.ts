/**
 * Lazy DB client factory.
 *
 * neon() throws at call time if DATABASE_URL is not set. Calling it at module
 * load (top-level) crashes build pipelines before the env var is provisioned.
 * getDb() defers initialization until the first actual DB call.
 *
 * WARNING: Do NOT wrap the db in a Proxy for lazy init — this breaks libraries
 * that inspect the adapter object (e.g., Auth.js). Use this plain function instead.
 */

import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import * as schema from "./schema.js";

export type Db = ReturnType<typeof createDb>;

function createDb() {
  const sql = neon(process.env["DATABASE_URL"]!);
  return drizzle(sql, { schema });
}

let _db: Db | null = null;

export function getDb(): Db {
  if (_db === null) {
    _db = createDb();
  }
  return _db;
}
