-- Migration: 0001_initial
-- CompliCore Command OS — initial schema
-- Run with: pnpm --filter @complicore/core db:migrate

-- ---------------------------------------------------------------------------
-- Gate-critical enums (enforced at DB level)
-- ---------------------------------------------------------------------------

CREATE TYPE reviewer_status AS ENUM (
  'pending',
  'approved',
  'needs_review',
  'rejected'
);

CREATE TYPE confidence AS ENUM (
  'high',
  'medium',
  'low'
);

CREATE TYPE run_status AS ENUM (
  'pending',
  'running',
  'completed',
  'failed',
  'cancelled'
);

CREATE TYPE step_status AS ENUM (
  'pending',
  'running',
  'completed',
  'failed',
  'skipped'
);

CREATE TYPE finding_status AS ENUM (
  'open',
  'approved',
  'needs_review',
  'rejected'
);

CREATE TYPE report_status AS ENUM (
  'draft',
  'approved',
  'exported'
);

-- ---------------------------------------------------------------------------
-- workspaces
-- v1: one workspace per deployment; workspace_id threaded for future isolation
-- ---------------------------------------------------------------------------

CREATE TABLE workspaces (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          TEXT NOT NULL,
  metro         TEXT NOT NULL,
  operator_domain TEXT NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- objectives
-- ---------------------------------------------------------------------------

CREATE TABLE objectives (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id  UUID NOT NULL REFERENCES workspaces(id),
  type          TEXT NOT NULL,  -- ObjectiveType
  description   TEXT NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_objectives_workspace ON objectives(workspace_id);

-- ---------------------------------------------------------------------------
-- runs
-- ---------------------------------------------------------------------------

CREATE TABLE runs (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id  UUID NOT NULL REFERENCES workspaces(id),
  status        run_status NOT NULL DEFAULT 'pending',
  metro         TEXT NOT NULL,
  started_at    TIMESTAMPTZ,
  completed_at  TIMESTAMPTZ,
  error         TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_runs_workspace        ON runs(workspace_id);
CREATE INDEX idx_runs_workspace_status ON runs(workspace_id, status);
CREATE INDEX idx_runs_created_at       ON runs(created_at DESC);

-- ---------------------------------------------------------------------------
-- steps
-- ---------------------------------------------------------------------------

CREATE TABLE steps (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id        UUID NOT NULL REFERENCES runs(id),
  name          TEXT NOT NULL,        -- StepName
  status        step_status NOT NULL DEFAULT 'pending',
  input_count   INTEGER NOT NULL DEFAULT 0,
  output_count  INTEGER NOT NULL DEFAULT 0,
  error         TEXT,
  started_at    TIMESTAMPTZ,
  completed_at  TIMESTAMPTZ
);

CREATE INDEX idx_steps_run ON steps(run_id);

-- ---------------------------------------------------------------------------
-- audit_events
--
-- APPEND-ONLY. Never UPDATE or DELETE rows in this table.
-- The application layer enforces this: the repo exports insertAuditEvent only.
-- ---------------------------------------------------------------------------

CREATE TABLE audit_events (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id  UUID NOT NULL REFERENCES workspaces(id),
  run_id        UUID REFERENCES runs(id),
  actor         TEXT NOT NULL,        -- AuditActor: system | reviewer
  actor_id      TEXT,
  action        TEXT NOT NULL,        -- e.g. "finding.approved", "run.started"
  entity_type   TEXT NOT NULL,
  entity_id     TEXT NOT NULL,
  payload       JSONB NOT NULL DEFAULT '{}',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_audit_events_workspace        ON audit_events(workspace_id);
CREATE INDEX idx_audit_events_run              ON audit_events(run_id);
CREATE INDEX idx_audit_events_entity           ON audit_events(entity_type, entity_id);
CREATE INDEX idx_audit_events_workspace_action ON audit_events(workspace_id, action);

-- ---------------------------------------------------------------------------
-- domains
-- ---------------------------------------------------------------------------

CREATE TABLE domains (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id           UUID NOT NULL REFERENCES runs(id),
  domain           TEXT NOT NULL,
  robots_txt_url   TEXT,
  disallowed_paths JSONB NOT NULL DEFAULT '[]',
  sitemap_url      TEXT,
  status           TEXT NOT NULL DEFAULT 'mapped',  -- DomainStatus
  crawled_at       TIMESTAMPTZ
);

CREATE INDEX idx_domains_run    ON domains(run_id);
CREATE INDEX idx_domains_domain ON domains(domain);

-- ---------------------------------------------------------------------------
-- source_urls
-- ---------------------------------------------------------------------------

CREATE TABLE source_urls (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id         UUID NOT NULL REFERENCES domains(id),
  url               TEXT NOT NULL,
  content_type_hint TEXT NOT NULL,   -- PageType
  depth             INTEGER NOT NULL DEFAULT 0,
  status            TEXT NOT NULL DEFAULT 'pending',  -- UrlStatus
  discovered_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_source_urls_domain ON source_urls(domain_id);
CREATE INDEX idx_source_urls_status ON source_urls(domain_id, status);

-- ---------------------------------------------------------------------------
-- source_pages
-- ---------------------------------------------------------------------------

CREATE TABLE source_pages (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  url_id        UUID NOT NULL REFERENCES source_urls(id),
  domain_id     UUID NOT NULL REFERENCES domains(id),
  url           TEXT NOT NULL,
  raw_html      TEXT,
  text_content  TEXT,
  http_status   INTEGER NOT NULL,
  scraped_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  content_type  TEXT NOT NULL,       -- PageType
  word_count    INTEGER
);

CREATE INDEX idx_source_pages_url_id    ON source_pages(url_id);
CREATE INDEX idx_source_pages_domain_id ON source_pages(domain_id);

-- ---------------------------------------------------------------------------
-- screenshots
-- ---------------------------------------------------------------------------

CREATE TABLE screenshots (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_page_id UUID NOT NULL REFERENCES source_pages(id),
  file_ref       TEXT NOT NULL,
  width          INTEGER NOT NULL,
  height         INTEGER NOT NULL,
  captured_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_screenshots_source_page ON screenshots(source_page_id);

-- ---------------------------------------------------------------------------
-- listings
-- ---------------------------------------------------------------------------

CREATE TABLE listings (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_page_id        UUID NOT NULL REFERENCES source_pages(id),
  domain_id             UUID NOT NULL REFERENCES domains(id),
  unit_name             TEXT,
  bedroom_count         INTEGER,
  bathroom_count        INTEGER,
  square_footage        INTEGER,
  amenities             JSONB NOT NULL DEFAULT '[]',
  minimum_stay_nights   INTEGER,
  availability_mentioned BOOLEAN NOT NULL DEFAULT false
);

CREATE INDEX idx_listings_source_page ON listings(source_page_id);
CREATE INDEX idx_listings_domain      ON listings(domain_id);

-- ---------------------------------------------------------------------------
-- pricing_observations
-- ---------------------------------------------------------------------------

CREATE TABLE pricing_observations (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_page_id  UUID NOT NULL REFERENCES source_pages(id),
  domain_id       UUID NOT NULL REFERENCES domains(id),
  price_raw       TEXT NOT NULL,
  price_numeric   REAL,
  price_unit      TEXT NOT NULL DEFAULT 'unknown',  -- PriceUnit
  fees_mentioned  JSONB NOT NULL DEFAULT '[]',
  total_cost_shown BOOLEAN NOT NULL DEFAULT false,
  price_quote     TEXT NOT NULL
);

CREATE INDEX idx_pricing_observations_source_page ON pricing_observations(source_page_id);
CREATE INDEX idx_pricing_observations_domain      ON pricing_observations(domain_id);

-- ---------------------------------------------------------------------------
-- policy_observations
-- ---------------------------------------------------------------------------

CREATE TABLE policy_observations (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_page_id  UUID NOT NULL REFERENCES source_pages(id),
  domain_id       UUID NOT NULL REFERENCES domains(id),
  policy_type     TEXT NOT NULL,       -- PolicyType
  policy_summary  TEXT NOT NULL,
  policy_url      TEXT
);

CREATE INDEX idx_policy_observations_source_page ON policy_observations(source_page_id);
CREATE INDEX idx_policy_observations_domain      ON policy_observations(domain_id);

-- ---------------------------------------------------------------------------
-- schema_observations
-- ---------------------------------------------------------------------------

CREATE TABLE schema_observations (
  id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_page_id         UUID NOT NULL REFERENCES source_pages(id),
  has_structured_data    BOOLEAN NOT NULL DEFAULT false,
  schema_types_found     JSONB NOT NULL DEFAULT '[]',
  title_present          BOOLEAN NOT NULL DEFAULT false,
  meta_description_present BOOLEAN NOT NULL DEFAULT false
);

CREATE INDEX idx_schema_observations_source_page ON schema_observations(source_page_id);

-- ---------------------------------------------------------------------------
-- content_gaps
-- ---------------------------------------------------------------------------

CREATE TABLE content_gaps (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_page_id  UUID NOT NULL REFERENCES source_pages(id),
  domain_id       UUID NOT NULL REFERENCES domains(id),
  gap_type        TEXT NOT NULL,    -- ContentGapType
  description     TEXT NOT NULL
);

CREATE INDEX idx_content_gaps_source_page ON content_gaps(source_page_id);
CREATE INDEX idx_content_gaps_domain      ON content_gaps(domain_id);

-- ---------------------------------------------------------------------------
-- compliance_findings
-- Evidence fields (source_url, screenshot_ref, snippet, confidence,
-- reviewer_status) are inlined from the Evidence interface.
-- ---------------------------------------------------------------------------

CREATE TABLE compliance_findings (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_page_id  UUID NOT NULL REFERENCES source_pages(id),
  domain_id       UUID NOT NULL REFERENCES domains(id),
  run_id          UUID NOT NULL REFERENCES runs(id),
  rule_family     TEXT NOT NULL,                           -- RuleFamily
  rule_result     TEXT NOT NULL,                           -- FAIL | WARN
  severity        TEXT NOT NULL,                           -- high | medium
  description     TEXT NOT NULL,
  status          finding_status NOT NULL DEFAULT 'open',
  -- Evidence fields (inlined)
  source_url      TEXT NOT NULL,
  screenshot_ref  TEXT,
  snippet         TEXT NOT NULL,
  confidence      confidence NOT NULL,
  reviewer_status reviewer_status NOT NULL DEFAULT 'pending',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_compliance_findings_run             ON compliance_findings(run_id);
CREATE INDEX idx_compliance_findings_domain          ON compliance_findings(domain_id);
CREATE INDEX idx_compliance_findings_reviewer_status ON compliance_findings(reviewer_status);
CREATE INDEX idx_compliance_findings_run_status      ON compliance_findings(run_id, reviewer_status);

-- ---------------------------------------------------------------------------
-- opportunity_targets
-- ---------------------------------------------------------------------------

CREATE TABLE opportunity_targets (
  id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id               UUID NOT NULL REFERENCES domains(id),
  run_id                  UUID NOT NULL REFERENCES runs(id),
  score                   INTEGER NOT NULL,
  signal_tier             TEXT NOT NULL,     -- HIGH | MODERATE | LOW
  score_breakdown         JSONB NOT NULL,
  contributing_finding_ids JSONB NOT NULL DEFAULT '[]',
  contributing_gap_ids    JSONB NOT NULL DEFAULT '[]',
  top_signals             JSONB NOT NULL DEFAULT '[]',
  recommendation          TEXT NOT NULL,
  reviewer_status         reviewer_status NOT NULL DEFAULT 'pending',
  created_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_opportunity_targets_run             ON opportunity_targets(run_id);
CREATE INDEX idx_opportunity_targets_domain          ON opportunity_targets(domain_id);
CREATE INDEX idx_opportunity_targets_reviewer_status ON opportunity_targets(reviewer_status);

-- ---------------------------------------------------------------------------
-- outbound_briefs
-- ---------------------------------------------------------------------------

CREATE TABLE outbound_briefs (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id                UUID NOT NULL REFERENCES runs(id),
  opportunity_target_id UUID NOT NULL REFERENCES opportunity_targets(id),
  content               TEXT NOT NULL,
  status                TEXT NOT NULL DEFAULT 'draft',     -- OutboundBriefStatus
  reviewer_status       reviewer_status NOT NULL DEFAULT 'pending',
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  approved_at           TIMESTAMPTZ
);

CREATE INDEX idx_outbound_briefs_run    ON outbound_briefs(run_id);
CREATE INDEX idx_outbound_briefs_target ON outbound_briefs(opportunity_target_id);

-- ---------------------------------------------------------------------------
-- reports
-- ---------------------------------------------------------------------------

CREATE TABLE reports (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id       UUID NOT NULL REFERENCES runs(id),
  workspace_id UUID NOT NULL REFERENCES workspaces(id),
  type         TEXT NOT NULL,                     -- ReportType
  status       report_status NOT NULL DEFAULT 'draft',
  metro        TEXT NOT NULL,
  generated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  approved_at  TIMESTAMPTZ,
  exported_at  TIMESTAMPTZ
);

CREATE INDEX idx_reports_run       ON reports(run_id);
CREATE INDEX idx_reports_workspace ON reports(workspace_id);
CREATE INDEX idx_reports_status    ON reports(workspace_id, status);
