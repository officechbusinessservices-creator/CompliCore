/**
 * DB barrel export for @complicore/core/db
 *
 * Import the client and repos from here, or use the granular sub-path
 * exports in package.json for tree-shaking in the worker app.
 */

export { getDb, type Db } from "./client.js";
export * as schema from "./schema.js";

// Repos
export * from "./repos/runs.js";
export * from "./repos/steps.js";
export * from "./repos/domains.js";
export * from "./repos/source-urls.js";
export * from "./repos/source-pages.js";
export * from "./repos/listings.js";
export * from "./repos/pricing-observations.js";
export * from "./repos/policy-observations.js";
export * from "./repos/schema-observations.js";
export * from "./repos/content-gaps.js";
export * from "./repos/findings.js";
export * from "./repos/opportunity-targets.js";
export * from "./repos/reports.js";
export * from "./repos/audit-events.js";
export * from "./repos/outbound-briefs.js";
