/**
 * Repository: source_urls
 * Functions: insertSourceUrl
 */
import type { Db } from "../client.js";
import { sourceUrls } from "../schema.js";
import type { ISODatetime } from "../../types.js";
import type { PageType } from "../../page-taxonomy.js";

export interface SourceUrlRecord {
  id: string;
  domain_id: string;
  url: string;
  content_type_hint: string;
  depth: number;
  status: string;
  discovered_at: ISODatetime;
}

type SourceUrlRow = typeof sourceUrls.$inferSelect;

function toSourceUrl(row: SourceUrlRow): SourceUrlRecord {
  return {
    id: row.id,
    domain_id: row.domain_id,
    url: row.url,
    content_type_hint: row.content_type_hint,
    depth: row.depth,
    status: row.status,
    discovered_at: row.discovered_at.toISOString(),
  };
}

export interface CreateSourceUrlInput {
  domain_id: string;
  url: string;
  content_type_hint: PageType;
  depth?: number;
  status?: string;
}

export async function insertSourceUrl(
  db: Db,
  input: CreateSourceUrlInput,
): Promise<SourceUrlRecord> {
  const [row] = await db
    .insert(sourceUrls)
    .values({
      domain_id: input.domain_id,
      url: input.url,
      content_type_hint: input.content_type_hint,
      depth: input.depth ?? 0,
      status: input.status ?? "scraped",
    })
    .returning();
  if (row == null) throw new Error("insertSourceUrl: no row returned");
  return toSourceUrl(row);
}
