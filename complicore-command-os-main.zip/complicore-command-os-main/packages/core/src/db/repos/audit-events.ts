/**
 * Repository: audit_events
 *
 * APPEND-ONLY. This module intentionally exports only insertAuditEvent.
 * There are no update or delete functions. Do not add them.
 *
 * Every state-changing action in the system must call insertAuditEvent.
 * A finding reviewer_status change, a report approval, a run start —
 * all produce an audit event with before/after payload.
 */

import { desc, eq } from "drizzle-orm";
import type { Db } from "../client.js";
import { auditEvents } from "../schema.js";
import type { AuditEvent, AuditActor, ISODatetime } from "../../types.js";

// ---------------------------------------------------------------------------
// Timestamp helpers
// ---------------------------------------------------------------------------

function ts(d: Date): ISODatetime {
  return d.toISOString();
}

// ---------------------------------------------------------------------------
// Row → canonical type
// ---------------------------------------------------------------------------

type AuditEventRow = typeof auditEvents.$inferSelect;

function toAuditEvent(row: AuditEventRow): AuditEvent {
  return {
    id: row.id,
    workspace_id: row.workspace_id,
    run_id: row.run_id ?? null,
    actor: row.actor as AuditActor,
    actor_id: row.actor_id ?? null,
    action: row.action,
    entity_type: row.entity_type,
    entity_id: row.entity_id,
    payload: (row.payload ?? {}) as Record<string, unknown>,
    created_at: ts(row.created_at),
  };
}

// ---------------------------------------------------------------------------
// Input type
// ---------------------------------------------------------------------------

export interface InsertAuditEventInput {
  workspace_id: string;
  run_id?: string;
  actor: AuditActor;
  actor_id?: string;
  /** e.g. "finding.approved", "report.exported", "run.started" */
  action: string;
  entity_type: string;
  entity_id: string;
  payload?: Record<string, unknown>;
}

// ---------------------------------------------------------------------------
// Append-only write
// ---------------------------------------------------------------------------

export async function listAuditEventsByEntity(
  db: Db,
  entityId: string,
  limit = 50,
): Promise<AuditEvent[]> {
  const rows = await db
    .select()
    .from(auditEvents)
    .where(eq(auditEvents.entity_id, entityId))
    .orderBy(desc(auditEvents.created_at))
    .limit(limit);
  return rows.map(toAuditEvent);
}

export async function listAuditEventsByRun(
  db: Db,
  runId: string,
  limit = 200,
): Promise<AuditEvent[]> {
  const rows = await db
    .select()
    .from(auditEvents)
    .where(eq(auditEvents.run_id, runId))
    .orderBy(desc(auditEvents.created_at))
    .limit(limit);
  return rows.map(toAuditEvent);
}

export async function insertAuditEvent(
  db: Db,
  input: InsertAuditEventInput
): Promise<AuditEvent> {
  const [row] = await db
    .insert(auditEvents)
    .values({
      workspace_id: input.workspace_id,
      run_id: input.run_id ?? null,
      actor: input.actor,
      actor_id: input.actor_id ?? null,
      action: input.action,
      entity_type: input.entity_type,
      entity_id: input.entity_id,
      payload: input.payload ?? {},
    })
    .returning();
  if (row == null) throw new Error("insertAuditEvent: no row returned");
  return toAuditEvent(row);
}
