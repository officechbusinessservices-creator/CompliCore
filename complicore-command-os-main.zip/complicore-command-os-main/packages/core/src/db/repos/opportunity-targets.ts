/**
 * Repository: opportunity_targets
 *
 * Functions: insertOpportunityTarget, listTargetsByRun
 *
 * Opportunity targets are reviewer-gated: reviewer_status must be "approved"
 * before the target appears in any published output.
 */

import { eq } from "drizzle-orm";
import type { Db } from "../client.js";
import { opportunityTargets } from "../schema.js";
import type {
  OpportunityTarget,
  OpportunityScoreBreakdown,
  ISODatetime,
} from "../../types.js";

// ---------------------------------------------------------------------------
// Row → canonical type
// ---------------------------------------------------------------------------

type TargetRow = typeof opportunityTargets.$inferSelect;

function ts(d: Date): ISODatetime {
  return d.toISOString();
}

function toTarget(row: TargetRow): OpportunityTarget {
  return {
    id: row.id,
    domain_id: row.domain_id,
    run_id: row.run_id,
    score: row.score,
    signal_tier: row.signal_tier as OpportunityTarget["signal_tier"],
    score_breakdown: row.score_breakdown as OpportunityScoreBreakdown,
    contributing_finding_ids: (row.contributing_finding_ids ?? []) as string[],
    contributing_gap_ids: (row.contributing_gap_ids ?? []) as string[],
    top_signals: (row.top_signals ?? []) as string[],
    recommendation: row.recommendation,
    reviewer_status: row.reviewer_status,
    created_at: ts(row.created_at),
  };
}

// ---------------------------------------------------------------------------
// Input types
// ---------------------------------------------------------------------------

export interface CreateOpportunityTargetInput {
  domain_id: string;
  run_id: string;
  score: number;
  signal_tier: OpportunityTarget["signal_tier"];
  score_breakdown: OpportunityScoreBreakdown;
  /** DB UUIDs of ComplianceFinding rows that contributed to this score. */
  contributing_finding_ids: string[];
  contributing_gap_ids: string[];
  top_signals: string[];
  recommendation: string;
}

// ---------------------------------------------------------------------------
// Queries
// ---------------------------------------------------------------------------

export async function insertOpportunityTarget(
  db: Db,
  input: CreateOpportunityTargetInput,
): Promise<OpportunityTarget> {
  const [row] = await db
    .insert(opportunityTargets)
    .values({
      domain_id: input.domain_id,
      run_id: input.run_id,
      score: input.score,
      signal_tier: input.signal_tier,
      score_breakdown: input.score_breakdown,
      contributing_finding_ids: input.contributing_finding_ids,
      contributing_gap_ids: input.contributing_gap_ids,
      top_signals: input.top_signals,
      recommendation: input.recommendation,
      reviewer_status: "pending",
    })
    .returning();
  if (row == null) throw new Error("insertOpportunityTarget: no row returned");
  return toTarget(row);
}

export async function findTargetById(
  db: Db,
  id: string,
): Promise<OpportunityTarget | null> {
  const [row] = await db
    .select()
    .from(opportunityTargets)
    .where(eq(opportunityTargets.id, id));
  return row != null ? toTarget(row) : null;
}

export async function listTargetsByRun(
  db: Db,
  runId: string,
): Promise<OpportunityTarget[]> {
  const rows = await db
    .select()
    .from(opportunityTargets)
    .where(eq(opportunityTargets.run_id, runId))
    .orderBy(opportunityTargets.score);
  return rows.map(toTarget);
}

export async function setTargetReviewerStatus(
  db: Db,
  id: string,
  reviewerStatus: OpportunityTarget["reviewer_status"],
): Promise<OpportunityTarget> {
  const [row] = await db
    .update(opportunityTargets)
    .set({ reviewer_status: reviewerStatus })
    .where(eq(opportunityTargets.id, id))
    .returning();
  if (row == null) {
    throw new Error(`setTargetReviewerStatus: target ${id} not found`);
  }
  return toTarget(row);
}
