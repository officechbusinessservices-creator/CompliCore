/**
 * Repository: schema_observations
 *
 * Functions: insertSchemaObservation
 *
 * Schema observations capture structured data signals found in raw HTML:
 * JSON-LD types, OG tags, title, meta description.
 * One observation per page (null if raw_html was not captured).
 */

import type { Db } from "../client.js";
import { schemaObservations } from "../schema.js";
import type { SchemaObservation } from "../../types.js";

// ---------------------------------------------------------------------------
// Row → canonical type
// ---------------------------------------------------------------------------

type SchemaObservationRow = typeof schemaObservations.$inferSelect;

function toSchemaObservation(row: SchemaObservationRow): SchemaObservation {
  return {
    id: row.id,
    source_page_id: row.source_page_id,
    has_structured_data: row.has_structured_data,
    schema_types_found: (row.schema_types_found as string[]) ?? [],
    title_present: row.title_present,
    meta_description_present: row.meta_description_present,
  };
}

// ---------------------------------------------------------------------------
// Input types
// ---------------------------------------------------------------------------

export interface CreateSchemaObservationInput {
  source_page_id: string;
  has_structured_data: boolean;
  schema_types_found: string[];
  title_present: boolean;
  meta_description_present: boolean;
}

// ---------------------------------------------------------------------------
// Queries
// ---------------------------------------------------------------------------

export async function insertSchemaObservation(
  db: Db,
  input: CreateSchemaObservationInput,
): Promise<SchemaObservation> {
  const [row] = await db
    .insert(schemaObservations)
    .values({
      source_page_id: input.source_page_id,
      has_structured_data: input.has_structured_data,
      schema_types_found: input.schema_types_found,
      title_present: input.title_present,
      meta_description_present: input.meta_description_present,
    })
    .returning();
  if (row == null) throw new Error("insertSchemaObservation: no row returned");
  return toSchemaObservation(row);
}
