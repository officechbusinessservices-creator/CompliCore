/**
 * Repository: reports
 *
 * Functions: insertReport, findReportById, listReportsByRun, setReportStatus
 *
 * Reports are the final reviewer gate. status must be "approved" before
 * any export operation is permitted. setReportStatus enforces this by
 * recording approved_at / exported_at timestamps when those states are set.
 */

import { eq } from "drizzle-orm";
import type { Db } from "../client.js";
import { reports } from "../schema.js";
import type { Report, ReportStatus, ReportType, ISODatetime } from "../../types.js";

// ---------------------------------------------------------------------------
// Timestamp helpers
// ---------------------------------------------------------------------------

function ts(d: Date): ISODatetime {
  return d.toISOString();
}

function tsNull(d: Date | null | undefined): ISODatetime | null {
  return d != null ? d.toISOString() : null;
}

// ---------------------------------------------------------------------------
// Row → canonical type
// ---------------------------------------------------------------------------

type ReportRow = typeof reports.$inferSelect;

function toReport(row: ReportRow): Report {
  return {
    id: row.id,
    run_id: row.run_id,
    workspace_id: row.workspace_id,
    type: row.type as ReportType,
    status: row.status,
    metro: row.metro,
    generated_at: ts(row.generated_at),
    approved_at: tsNull(row.approved_at),
    exported_at: tsNull(row.exported_at),
  };
}

// ---------------------------------------------------------------------------
// Input types
// ---------------------------------------------------------------------------

export interface CreateReportInput {
  run_id: string;
  workspace_id: string;
  type: ReportType;
  metro: string;
}

export interface SetReportStatusInput {
  status: ReportStatus;
  /** Set when transitioning to "approved". */
  approved_at?: ISODatetime;
  /** Set when transitioning to "exported". */
  exported_at?: ISODatetime;
}

// ---------------------------------------------------------------------------
// Queries
// ---------------------------------------------------------------------------

export async function insertReport(
  db: Db,
  input: CreateReportInput
): Promise<Report> {
  const [row] = await db
    .insert(reports)
    .values({
      run_id: input.run_id,
      workspace_id: input.workspace_id,
      type: input.type,
      metro: input.metro,
      status: "draft",
    })
    .returning();
  if (row == null) throw new Error("insertReport: no row returned");
  return toReport(row);
}

export async function findReportById(
  db: Db,
  id: string
): Promise<Report | null> {
  const [row] = await db.select().from(reports).where(eq(reports.id, id));
  return row != null ? toReport(row) : null;
}

export async function listReportsByRun(
  db: Db,
  runId: string
): Promise<Report[]> {
  const rows = await db
    .select()
    .from(reports)
    .where(eq(reports.run_id, runId))
    .orderBy(reports.generated_at);
  return rows.map(toReport);
}

export async function setReportStatus(
  db: Db,
  id: string,
  input: SetReportStatusInput
): Promise<Report> {
  const updates: Partial<typeof reports.$inferInsert> = {
    status: input.status,
  };
  if (input.approved_at !== undefined) {
    updates.approved_at = new Date(input.approved_at);
  }
  if (input.exported_at !== undefined) {
    updates.exported_at = new Date(input.exported_at);
  }

  const [row] = await db
    .update(reports)
    .set(updates)
    .where(eq(reports.id, id))
    .returning();
  if (row == null) throw new Error(`setReportStatus: report ${id} not found`);
  return toReport(row);
}
