/**
 * Repository: domains
 *
 * Functions: insertDomain, findDomainById, listDomainsByRun, setDomainStatus
 */

import { eq } from "drizzle-orm";
import type { Db } from "../client.js";
import { domains } from "../schema.js";
import type { Domain, DomainStatus, ISODatetime } from "../../types.js";

// ---------------------------------------------------------------------------
// Timestamp helpers
// ---------------------------------------------------------------------------

function tsNull(d: Date | null | undefined): ISODatetime | null {
  return d != null ? d.toISOString() : null;
}

// ---------------------------------------------------------------------------
// Row → canonical type
// ---------------------------------------------------------------------------

type DomainRow = typeof domains.$inferSelect;

function toDomain(row: DomainRow): Domain {
  return {
    id: row.id,
    run_id: row.run_id,
    domain: row.domain,
    robots_txt_url: row.robots_txt_url ?? null,
    disallowed_paths: (row.disallowed_paths ?? []) as string[],
    sitemap_url: row.sitemap_url ?? null,
    status: row.status as DomainStatus,
    crawled_at: tsNull(row.crawled_at),
  };
}

// ---------------------------------------------------------------------------
// Input types
// ---------------------------------------------------------------------------

export interface CreateDomainInput {
  run_id: string;
  domain: string;
  robots_txt_url?: string;
  disallowed_paths?: string[];
  sitemap_url?: string;
  status?: DomainStatus;
}

export interface SetDomainStatusInput {
  status: DomainStatus;
  crawled_at?: ISODatetime;
}

// ---------------------------------------------------------------------------
// Queries
// ---------------------------------------------------------------------------

export async function insertDomain(
  db: Db,
  input: CreateDomainInput
): Promise<Domain> {
  const [row] = await db
    .insert(domains)
    .values({
      run_id: input.run_id,
      domain: input.domain,
      robots_txt_url: input.robots_txt_url ?? null,
      disallowed_paths: input.disallowed_paths ?? [],
      sitemap_url: input.sitemap_url ?? null,
      status: input.status ?? "mapped",
    })
    .returning();
  if (row == null) throw new Error("insertDomain: no row returned");
  return toDomain(row);
}

export async function findDomainById(
  db: Db,
  id: string
): Promise<Domain | null> {
  const [row] = await db.select().from(domains).where(eq(domains.id, id));
  return row != null ? toDomain(row) : null;
}

export async function listDomainsByRun(
  db: Db,
  runId: string
): Promise<Domain[]> {
  const rows = await db
    .select()
    .from(domains)
    .where(eq(domains.run_id, runId))
    .orderBy(domains.domain);
  return rows.map(toDomain);
}

export async function setDomainStatus(
  db: Db,
  id: string,
  input: SetDomainStatusInput
): Promise<Domain> {
  const updates: Partial<typeof domains.$inferInsert> = {
    status: input.status,
  };
  if (input.crawled_at !== undefined) {
    updates.crawled_at = new Date(input.crawled_at);
  }

  const [row] = await db
    .update(domains)
    .set(updates)
    .where(eq(domains.id, id))
    .returning();
  if (row == null) throw new Error(`setDomainStatus: domain ${id} not found`);
  return toDomain(row);
}
