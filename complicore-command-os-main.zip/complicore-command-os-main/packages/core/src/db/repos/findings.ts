/**
 * Repository: compliance_findings
 *
 * Functions: insertFinding, findFindingById, listFindingsByRun,
 *            listFindingsByDomain, setFindingReviewerStatus
 *
 * All findings include confidence and reviewer_status — these are the two
 * fields that gate publication. A finding may not be published until
 * reviewer_status is "approved".
 */

import { eq, and } from "drizzle-orm";
import type { Db } from "../client.js";
import { complianceFindings } from "../schema.js";
import type {
  ComplianceFinding,
  ISODatetime,
  RuleFamily,
  FindingResult,
  FindingSeverity,
  FindingStatus,
} from "../../types.js";

// ---------------------------------------------------------------------------
// Timestamp helpers
// ---------------------------------------------------------------------------

function ts(d: Date): ISODatetime {
  return d.toISOString();
}

// ---------------------------------------------------------------------------
// Reviewer status / confidence unions (re-exported from the Evidence interface)
// ---------------------------------------------------------------------------

type ReviewerStatus = ComplianceFinding["reviewer_status"];
type Confidence = ComplianceFinding["confidence"];

// ---------------------------------------------------------------------------
// Row → canonical type
// ---------------------------------------------------------------------------

type FindingRow = typeof complianceFindings.$inferSelect;

function toFinding(row: FindingRow): ComplianceFinding {
  return {
    id: row.id,
    source_page_id: row.source_page_id,
    domain_id: row.domain_id,
    run_id: row.run_id,
    rule_family: row.rule_family as RuleFamily,
    rule_result: row.rule_result as FindingResult,
    severity: row.severity as FindingSeverity,
    description: row.description,
    status: row.status as FindingStatus,
    // Evidence fields
    source_url: row.source_url,
    screenshot_ref: row.screenshot_ref ?? null,
    snippet: row.snippet,
    confidence: row.confidence,
    reviewer_status: row.reviewer_status,
    created_at: ts(row.created_at),
  };
}

// ---------------------------------------------------------------------------
// Input types
// ---------------------------------------------------------------------------

export interface CreateFindingInput {
  source_page_id: string;
  domain_id: string;
  run_id: string;
  rule_family: RuleFamily;
  rule_result: FindingResult;
  severity: FindingSeverity;
  description: string;
  // Evidence fields (required — a finding without evidence is not insertable)
  source_url: string;
  screenshot_ref: string | null;
  snippet: string;
  confidence: Confidence;
  /**
   * Defaults to "pending". Pass "needs_review" for uncertain_needs_review
   * violations so the reviewer gate is set at insert time.
   */
  reviewer_status?: ReviewerStatus;
}

export interface ListFindingsFilter {
  reviewer_status?: ReviewerStatus;
  confidence?: Confidence;
  severity?: FindingSeverity;
}

// ---------------------------------------------------------------------------
// Queries
// ---------------------------------------------------------------------------

export async function insertFinding(
  db: Db,
  input: CreateFindingInput
): Promise<ComplianceFinding> {
  const [row] = await db
    .insert(complianceFindings)
    .values({
      source_page_id: input.source_page_id,
      domain_id: input.domain_id,
      run_id: input.run_id,
      rule_family: input.rule_family,
      rule_result: input.rule_result,
      severity: input.severity,
      description: input.description,
      status: "open",
      source_url: input.source_url,
      screenshot_ref: input.screenshot_ref ?? null,
      snippet: input.snippet,
      confidence: input.confidence,
      reviewer_status: input.reviewer_status ?? "pending",
    })
    .returning();
  if (row == null) throw new Error("insertFinding: no row returned");
  return toFinding(row);
}

export async function findFindingById(
  db: Db,
  id: string
): Promise<ComplianceFinding | null> {
  const [row] = await db
    .select()
    .from(complianceFindings)
    .where(eq(complianceFindings.id, id));
  return row != null ? toFinding(row) : null;
}

export async function listFindingsByRun(
  db: Db,
  runId: string,
  filter?: ListFindingsFilter
): Promise<ComplianceFinding[]> {
  const conditions = [eq(complianceFindings.run_id, runId)];
  if (filter?.reviewer_status != null) {
    conditions.push(eq(complianceFindings.reviewer_status, filter.reviewer_status));
  }
  if (filter?.confidence != null) {
    conditions.push(eq(complianceFindings.confidence, filter.confidence));
  }
  if (filter?.severity != null) {
    conditions.push(eq(complianceFindings.severity, filter.severity));
  }
  const rows = await db
    .select()
    .from(complianceFindings)
    .where(and(...conditions))
    .orderBy(complianceFindings.created_at);
  return rows.map(toFinding);
}

export async function listFindingsByDomain(
  db: Db,
  domainId: string,
  filter?: ListFindingsFilter
): Promise<ComplianceFinding[]> {
  const conditions = [eq(complianceFindings.domain_id, domainId)];
  if (filter?.reviewer_status != null) {
    conditions.push(eq(complianceFindings.reviewer_status, filter.reviewer_status));
  }
  if (filter?.confidence != null) {
    conditions.push(eq(complianceFindings.confidence, filter.confidence));
  }
  if (filter?.severity != null) {
    conditions.push(eq(complianceFindings.severity, filter.severity));
  }
  const rows = await db
    .select()
    .from(complianceFindings)
    .where(and(...conditions))
    .orderBy(complianceFindings.created_at);
  return rows.map(toFinding);
}

export async function setFindingReviewerStatus(
  db: Db,
  id: string,
  reviewerStatus: ReviewerStatus
): Promise<ComplianceFinding> {
  const [row] = await db
    .update(complianceFindings)
    .set({ reviewer_status: reviewerStatus })
    .where(eq(complianceFindings.id, id))
    .returning();
  if (row == null) {
    throw new Error(`setFindingReviewerStatus: finding ${id} not found`);
  }
  return toFinding(row);
}
