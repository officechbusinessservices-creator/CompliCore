/**
 * Repository: runs
 *
 * Functions: insertRun, findRunById, listRunsByWorkspace, setRunStatus
 */

import { eq, and } from "drizzle-orm";
import type { Db } from "../client.js";
import { runs } from "../schema.js";
import type { Run, RunStatus, ISODatetime } from "../../types.js";

// ---------------------------------------------------------------------------
// Timestamp helpers
// ---------------------------------------------------------------------------

function ts(d: Date): ISODatetime {
  return d.toISOString();
}

function tsNull(d: Date | null | undefined): ISODatetime | null {
  return d != null ? d.toISOString() : null;
}

// ---------------------------------------------------------------------------
// Row → canonical type
// ---------------------------------------------------------------------------

type RunRow = typeof runs.$inferSelect;

function toRun(row: RunRow): Run {
  return {
    id: row.id,
    workspace_id: row.workspace_id,
    status: row.status,
    metro: row.metro,
    started_at: tsNull(row.started_at),
    completed_at: tsNull(row.completed_at),
    error: row.error ?? null,
    created_at: ts(row.created_at),
  };
}

// ---------------------------------------------------------------------------
// Input types
// ---------------------------------------------------------------------------

export interface CreateRunInput {
  workspace_id: string;
  metro: string;
}

export interface SetRunStatusInput {
  status: RunStatus;
  error?: string;
  started_at?: ISODatetime;
  completed_at?: ISODatetime;
}

// ---------------------------------------------------------------------------
// Queries
// ---------------------------------------------------------------------------

export async function insertRun(db: Db, input: CreateRunInput): Promise<Run> {
  const [row] = await db
    .insert(runs)
    .values({
      workspace_id: input.workspace_id,
      metro: input.metro,
      status: "pending",
    })
    .returning();
  if (row == null) throw new Error("insertRun: no row returned");
  return toRun(row);
}

export async function findRunById(
  db: Db,
  id: string
): Promise<Run | null> {
  const [row] = await db.select().from(runs).where(eq(runs.id, id));
  return row != null ? toRun(row) : null;
}

export async function listRunsByWorkspace(
  db: Db,
  workspaceId: string,
  opts?: { status?: RunStatus }
): Promise<Run[]> {
  const conditions = [eq(runs.workspace_id, workspaceId)];
  if (opts?.status != null) {
    conditions.push(eq(runs.status, opts.status));
  }
  const rows = await db
    .select()
    .from(runs)
    .where(and(...conditions))
    .orderBy(runs.created_at);
  return rows.map(toRun);
}

export async function setRunStatus(
  db: Db,
  id: string,
  input: SetRunStatusInput
): Promise<Run> {
  const updates: Partial<typeof runs.$inferInsert> = {
    status: input.status,
  };
  if (input.error !== undefined) updates.error = input.error;
  if (input.started_at !== undefined) updates.started_at = new Date(input.started_at);
  if (input.completed_at !== undefined) updates.completed_at = new Date(input.completed_at);

  const [row] = await db
    .update(runs)
    .set(updates)
    .where(eq(runs.id, id))
    .returning();
  if (row == null) throw new Error(`setRunStatus: run ${id} not found`);
  return toRun(row);
}
