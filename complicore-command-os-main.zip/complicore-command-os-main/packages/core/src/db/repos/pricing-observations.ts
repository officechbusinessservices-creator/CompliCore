/**
 * Repository: pricing_observations
 *
 * Functions: insertPricingObservation
 *
 * Pricing observations capture price signals found on any page.
 * Each page may produce at most one pricing observation (the normalize
 * step stops after the first matching price pattern).
 */

import type { Db } from "../client.js";
import { pricingObservations } from "../schema.js";
import type { PricingObservation, PriceUnit } from "../../types.js";

// ---------------------------------------------------------------------------
// Row → canonical type
// ---------------------------------------------------------------------------

type PricingObservationRow = typeof pricingObservations.$inferSelect;

function toPricingObservation(row: PricingObservationRow): PricingObservation {
  return {
    id: row.id,
    source_page_id: row.source_page_id,
    domain_id: row.domain_id,
    price_raw: row.price_raw,
    price_numeric: row.price_numeric ?? null,
    price_unit: row.price_unit as PriceUnit,
    fees_mentioned: (row.fees_mentioned as string[]) ?? [],
    total_cost_shown: row.total_cost_shown,
    price_quote: row.price_quote,
  };
}

// ---------------------------------------------------------------------------
// Input types
// ---------------------------------------------------------------------------

export interface CreatePricingObservationInput {
  source_page_id: string;
  domain_id: string;
  price_raw: string;
  price_numeric: number | null;
  price_unit: PriceUnit;
  fees_mentioned: string[];
  total_cost_shown: boolean;
  price_quote: string;
}

// ---------------------------------------------------------------------------
// Queries
// ---------------------------------------------------------------------------

export async function insertPricingObservation(
  db: Db,
  input: CreatePricingObservationInput,
): Promise<PricingObservation> {
  const [row] = await db
    .insert(pricingObservations)
    .values({
      source_page_id: input.source_page_id,
      domain_id: input.domain_id,
      price_raw: input.price_raw,
      price_numeric: input.price_numeric ?? undefined,
      price_unit: input.price_unit,
      fees_mentioned: input.fees_mentioned,
      total_cost_shown: input.total_cost_shown,
      price_quote: input.price_quote,
    })
    .returning();
  if (row == null) throw new Error("insertPricingObservation: no row returned");
  return toPricingObservation(row);
}
