/**
 * Repository: steps
 *
 * Functions: insertStep, setStepStatus, listStepsByRun
 *
 * Steps are run-scoped records of each pipeline phase.
 * Status transitions: pending → running → completed | failed | skipped
 */

import { eq } from "drizzle-orm";
import type { Db } from "../client.js";
import { steps } from "../schema.js";
import type { Step, StepName, StepStatus, ISODatetime } from "../../types.js";

// ---------------------------------------------------------------------------
// Row → canonical type
// ---------------------------------------------------------------------------

type StepRow = typeof steps.$inferSelect;

function toStep(row: StepRow): Step {
  return {
    id: row.id,
    run_id: row.run_id,
    name: row.name as StepName,
    status: row.status as StepStatus,
    input_count: row.input_count,
    output_count: row.output_count,
    error: row.error ?? null,
    started_at: row.started_at != null ? row.started_at.toISOString() : null,
    completed_at: row.completed_at != null ? row.completed_at.toISOString() : null,
  };
}

// ---------------------------------------------------------------------------
// Input types
// ---------------------------------------------------------------------------

export interface CreateStepInput {
  run_id: string;
  name: StepName;
  input_count?: number;
  started_at?: ISODatetime;
}

export interface UpdateStepStatusInput {
  status: StepStatus;
  output_count?: number;
  error?: string;
  completed_at?: ISODatetime;
}

// ---------------------------------------------------------------------------
// Queries
// ---------------------------------------------------------------------------

export async function insertStep(
  db: Db,
  input: CreateStepInput,
): Promise<Step> {
  const [row] = await db
    .insert(steps)
    .values({
      run_id: input.run_id,
      name: input.name,
      status: "running",
      input_count: input.input_count ?? 0,
      output_count: 0,
      started_at: input.started_at != null ? new Date(input.started_at) : new Date(),
    })
    .returning();
  if (row == null) throw new Error("insertStep: no row returned");
  return toStep(row);
}

export async function setStepStatus(
  db: Db,
  id: string,
  input: UpdateStepStatusInput,
): Promise<Step> {
  const patch: Partial<typeof steps.$inferInsert> = {
    status: input.status,
    completed_at: input.completed_at != null ? new Date(input.completed_at) : new Date(),
  };
  if (input.output_count != null) patch.output_count = input.output_count;
  if (input.error != null) patch.error = input.error;

  const [row] = await db
    .update(steps)
    .set(patch)
    .where(eq(steps.id, id))
    .returning();
  if (row == null) throw new Error(`setStepStatus: step ${id} not found`);
  return toStep(row);
}

export async function listStepsByRun(db: Db, runId: string): Promise<Step[]> {
  const rows = await db
    .select()
    .from(steps)
    .where(eq(steps.run_id, runId))
    .orderBy(steps.started_at);
  return rows.map(toStep);
}
