/**
 * Repository: workspaces
 *
 * Functions: insertWorkspace, findWorkspaceById, findWorkspaceByMetro
 *
 * For v1, one workspace = one operator profile per metro.
 */

import { eq, and } from "drizzle-orm";
import type { Db } from "../client.js";
import { workspaces } from "../schema.js";
import type { ISODatetime } from "../../types.js";

// ---------------------------------------------------------------------------
// Timestamp helpers
// ---------------------------------------------------------------------------

function ts(d: Date): ISODatetime {
  return d.toISOString();
}

// ---------------------------------------------------------------------------
// Canonical type
// ---------------------------------------------------------------------------

export interface Workspace {
  id: string;
  name: string;
  metro: string;
  operator_domain: string;
  created_at: ISODatetime;
  updated_at: ISODatetime;
}

type WorkspaceRow = typeof workspaces.$inferSelect;

function toWorkspace(row: WorkspaceRow): Workspace {
  return {
    id: row.id,
    name: row.name,
    metro: row.metro,
    operator_domain: row.operator_domain,
    created_at: ts(row.created_at),
    updated_at: ts(row.updated_at),
  };
}

// ---------------------------------------------------------------------------
// Input types
// ---------------------------------------------------------------------------

export interface CreateWorkspaceInput {
  name: string;
  metro: string;
  operator_domain: string;
}

// ---------------------------------------------------------------------------
// Queries
// ---------------------------------------------------------------------------

export async function insertWorkspace(
  db: Db,
  input: CreateWorkspaceInput,
): Promise<Workspace> {
  const [row] = await db
    .insert(workspaces)
    .values({
      name: input.name,
      metro: input.metro,
      operator_domain: input.operator_domain,
    })
    .returning();
  if (row == null) throw new Error("insertWorkspace: no row returned");
  return toWorkspace(row);
}

export async function findWorkspaceById(
  db: Db,
  id: string,
): Promise<Workspace | null> {
  const [row] = await db.select().from(workspaces).where(eq(workspaces.id, id));
  return row != null ? toWorkspace(row) : null;
}

export async function findWorkspaceByMetro(
  db: Db,
  metro: string,
  operatorDomain: string,
): Promise<Workspace | null> {
  const [row] = await db
    .select()
    .from(workspaces)
    .where(and(eq(workspaces.metro, metro), eq(workspaces.operator_domain, operatorDomain)));
  return row != null ? toWorkspace(row) : null;
}

/**
 * Returns existing workspace for (metro, operatorDomain) or creates a new one.
 * Idempotent — safe to call at the start of every pipeline run.
 */
export async function ensureWorkspace(
  db: Db,
  input: CreateWorkspaceInput,
): Promise<Workspace> {
  const existing = await findWorkspaceByMetro(db, input.metro, input.operator_domain);
  if (existing != null) return existing;
  return insertWorkspace(db, input);
}
