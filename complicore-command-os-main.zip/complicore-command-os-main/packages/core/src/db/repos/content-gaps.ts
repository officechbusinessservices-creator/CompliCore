/**
 * Repository: content_gaps
 *
 * Functions: insertContentGap, listContentGapsByDomain
 *
 * Content gaps record provably absent required content.
 * Absence ≠ a rule violation — gaps feed the opportunity scoring model
 * via contributing_gap_ids on opportunity_targets.
 */

import { eq } from "drizzle-orm";
import type { Db } from "../client.js";
import { contentGaps } from "../schema.js";
import type { ContentGap, ContentGapType } from "../../types.js";

// ---------------------------------------------------------------------------
// Row → canonical type
// ---------------------------------------------------------------------------

type ContentGapRow = typeof contentGaps.$inferSelect;

function toContentGap(row: ContentGapRow): ContentGap {
  return {
    id: row.id,
    source_page_id: row.source_page_id,
    domain_id: row.domain_id,
    gap_type: row.gap_type as ContentGapType,
    description: row.description,
  };
}

// ---------------------------------------------------------------------------
// Input types
// ---------------------------------------------------------------------------

export interface CreateContentGapInput {
  source_page_id: string;
  domain_id: string;
  gap_type: ContentGapType;
  description: string;
}

// ---------------------------------------------------------------------------
// Queries
// ---------------------------------------------------------------------------

export async function insertContentGap(
  db: Db,
  input: CreateContentGapInput,
): Promise<ContentGap> {
  const [row] = await db
    .insert(contentGaps)
    .values({
      source_page_id: input.source_page_id,
      domain_id: input.domain_id,
      gap_type: input.gap_type,
      description: input.description,
    })
    .returning();
  if (row == null) throw new Error("insertContentGap: no row returned");
  return toContentGap(row);
}

export async function listContentGapsByDomain(
  db: Db,
  domainId: string,
): Promise<ContentGap[]> {
  const rows = await db
    .select()
    .from(contentGaps)
    .where(eq(contentGaps.domain_id, domainId));
  return rows.map(toContentGap);
}
