/**
 * Repository: source_pages
 *
 * Functions: insertSourcePage, findSourcePageById, listSourcePagesByDomain
 */

import { eq } from "drizzle-orm";
import type { Db } from "../client.js";
import { sourcePages } from "../schema.js";
import type { SourcePage, ISODatetime } from "../../types.js";
import type { PageType } from "../../page-taxonomy.js";

// ---------------------------------------------------------------------------
// Timestamp helpers
// ---------------------------------------------------------------------------

function ts(d: Date): ISODatetime {
  return d.toISOString();
}

// ---------------------------------------------------------------------------
// Row → canonical type
// ---------------------------------------------------------------------------

type SourcePageRow = typeof sourcePages.$inferSelect;

function toSourcePage(row: SourcePageRow): SourcePage {
  return {
    id: row.id,
    url_id: row.url_id,
    domain_id: row.domain_id,
    url: row.url,
    raw_html: row.raw_html ?? null,
    text_content: row.text_content ?? null,
    http_status: row.http_status,
    scraped_at: ts(row.scraped_at),
    content_type: row.content_type as PageType,
    word_count: row.word_count ?? null,
  };
}

// ---------------------------------------------------------------------------
// Input types
// ---------------------------------------------------------------------------

export interface CreateSourcePageInput {
  url_id: string;
  domain_id: string;
  url: string;
  raw_html?: string;
  text_content?: string;
  http_status: number;
  content_type: PageType;
  word_count?: number;
}

// ---------------------------------------------------------------------------
// Queries
// ---------------------------------------------------------------------------

export async function insertSourcePage(
  db: Db,
  input: CreateSourcePageInput
): Promise<SourcePage> {
  const [row] = await db
    .insert(sourcePages)
    .values({
      url_id: input.url_id,
      domain_id: input.domain_id,
      url: input.url,
      raw_html: input.raw_html ?? null,
      text_content: input.text_content ?? null,
      http_status: input.http_status,
      content_type: input.content_type,
      word_count: input.word_count ?? null,
    })
    .returning();
  if (row == null) throw new Error("insertSourcePage: no row returned");
  return toSourcePage(row);
}

export async function findSourcePageById(
  db: Db,
  id: string
): Promise<SourcePage | null> {
  const [row] = await db
    .select()
    .from(sourcePages)
    .where(eq(sourcePages.id, id));
  return row != null ? toSourcePage(row) : null;
}

export async function listSourcePagesByDomain(
  db: Db,
  domainId: string
): Promise<SourcePage[]> {
  const rows = await db
    .select()
    .from(sourcePages)
    .where(eq(sourcePages.domain_id, domainId))
    .orderBy(sourcePages.scraped_at);
  return rows.map(toSourcePage);
}
