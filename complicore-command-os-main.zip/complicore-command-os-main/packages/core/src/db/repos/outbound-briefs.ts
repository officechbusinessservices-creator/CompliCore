/**
 * Repository: outbound_briefs
 *
 * Functions: insertOutboundBrief, findOutboundBriefById, listOutboundBriefsByRun
 *
 * Each outbound brief is scoped to one opportunity_target.
 * Reviewer must approve before the brief may be sent.
 */

import { eq } from "drizzle-orm";
import type { Db } from "../client.js";
import { outboundBriefs } from "../schema.js";
import type { OutboundBrief, ISODatetime } from "../../types.js";

// ---------------------------------------------------------------------------
// Row → canonical type
// ---------------------------------------------------------------------------

type BriefRow = typeof outboundBriefs.$inferSelect;

function ts(d: Date): ISODatetime {
  return d.toISOString();
}

function tsNull(d: Date | null | undefined): ISODatetime | null {
  return d != null ? d.toISOString() : null;
}

function toBrief(row: BriefRow): OutboundBrief {
  return {
    id: row.id,
    run_id: row.run_id,
    opportunity_target_id: row.opportunity_target_id,
    content: row.content,
    status: row.status as OutboundBrief["status"],
    reviewer_status: row.reviewer_status,
    created_at: ts(row.created_at),
    approved_at: tsNull(row.approved_at),
  };
}

// ---------------------------------------------------------------------------
// Input types
// ---------------------------------------------------------------------------

export interface CreateOutboundBriefInput {
  run_id: string;
  opportunity_target_id: string;
  content: string;
}

// ---------------------------------------------------------------------------
// Queries
// ---------------------------------------------------------------------------

export async function insertOutboundBrief(
  db: Db,
  input: CreateOutboundBriefInput,
): Promise<OutboundBrief> {
  const [row] = await db
    .insert(outboundBriefs)
    .values({
      run_id: input.run_id,
      opportunity_target_id: input.opportunity_target_id,
      content: input.content,
      status: "draft",
      reviewer_status: "pending",
    })
    .returning();
  if (row == null) throw new Error("insertOutboundBrief: no row returned");
  return toBrief(row);
}

export async function findOutboundBriefById(
  db: Db,
  id: string,
): Promise<OutboundBrief | null> {
  const [row] = await db
    .select()
    .from(outboundBriefs)
    .where(eq(outboundBriefs.id, id));
  return row != null ? toBrief(row) : null;
}

export async function listOutboundBriefsByRun(
  db: Db,
  runId: string,
): Promise<OutboundBrief[]> {
  const rows = await db
    .select()
    .from(outboundBriefs)
    .where(eq(outboundBriefs.run_id, runId))
    .orderBy(outboundBriefs.created_at);
  return rows.map(toBrief);
}
