/**
 * Repository: listings
 *
 * Functions: insertListing
 *
 * Listings capture structured unit specifications extracted from
 * listing_detail pages. Only emitted when at least one unit spec
 * signal (bedrooms, bathrooms, or square footage) was found.
 */

import type { Db } from "../client.js";
import { listings } from "../schema.js";
import type { Listing } from "../../types.js";

// ---------------------------------------------------------------------------
// Row → canonical type
// ---------------------------------------------------------------------------

type ListingRow = typeof listings.$inferSelect;

function toListing(row: ListingRow): Listing {
  return {
    id: row.id,
    source_page_id: row.source_page_id,
    domain_id: row.domain_id,
    unit_name: row.unit_name ?? null,
    bedroom_count: row.bedroom_count ?? null,
    bathroom_count: row.bathroom_count ?? null,
    square_footage: row.square_footage ?? null,
    amenities: (row.amenities as string[]) ?? [],
    minimum_stay_nights: row.minimum_stay_nights ?? null,
    availability_mentioned: row.availability_mentioned,
  };
}

// ---------------------------------------------------------------------------
// Input types
// ---------------------------------------------------------------------------

export interface CreateListingInput {
  source_page_id: string;
  domain_id: string;
  unit_name: string | null;
  bedroom_count: number | null;
  bathroom_count: number | null;
  square_footage: number | null;
  amenities: string[];
  minimum_stay_nights: number | null;
  availability_mentioned: boolean;
}

// ---------------------------------------------------------------------------
// Queries
// ---------------------------------------------------------------------------

export async function insertListing(
  db: Db,
  input: CreateListingInput,
): Promise<Listing> {
  const [row] = await db
    .insert(listings)
    .values({
      source_page_id: input.source_page_id,
      domain_id: input.domain_id,
      unit_name: input.unit_name ?? undefined,
      bedroom_count: input.bedroom_count ?? undefined,
      bathroom_count: input.bathroom_count ?? undefined,
      square_footage: input.square_footage ?? undefined,
      amenities: input.amenities,
      minimum_stay_nights: input.minimum_stay_nights ?? undefined,
      availability_mentioned: input.availability_mentioned,
    })
    .returning();
  if (row == null) throw new Error("insertListing: no row returned");
  return toListing(row);
}
