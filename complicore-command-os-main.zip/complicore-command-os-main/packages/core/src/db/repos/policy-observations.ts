/**
 * Repository: policy_observations
 *
 * Functions: insertPolicyObservation
 *
 * Policy observations capture verbatim policy extracts found on any page.
 * A page with a policy extract is not a finding — only its absence is.
 * These records provide evidence backing for policy_coherence findings.
 */

import type { Db } from "../client.js";
import { policyObservations } from "../schema.js";
import type { PolicyObservation, PolicyType } from "../../types.js";

// ---------------------------------------------------------------------------
// Row → canonical type
// ---------------------------------------------------------------------------

type PolicyObservationRow = typeof policyObservations.$inferSelect;

function toPolicyObservation(row: PolicyObservationRow): PolicyObservation {
  return {
    id: row.id,
    source_page_id: row.source_page_id,
    domain_id: row.domain_id,
    policy_type: row.policy_type as PolicyType,
    policy_summary: row.policy_summary,
    policy_url: row.policy_url ?? null,
  };
}

// ---------------------------------------------------------------------------
// Input types
// ---------------------------------------------------------------------------

export interface CreatePolicyObservationInput {
  source_page_id: string;
  domain_id: string;
  policy_type: PolicyType;
  policy_summary: string;
  policy_url: string | null;
}

// ---------------------------------------------------------------------------
// Queries
// ---------------------------------------------------------------------------

export async function insertPolicyObservation(
  db: Db,
  input: CreatePolicyObservationInput,
): Promise<PolicyObservation> {
  const [row] = await db
    .insert(policyObservations)
    .values({
      source_page_id: input.source_page_id,
      domain_id: input.domain_id,
      policy_type: input.policy_type,
      policy_summary: input.policy_summary,
      policy_url: input.policy_url ?? undefined,
    })
    .returning();
  if (row == null) throw new Error("insertPolicyObservation: no row returned");
  return toPolicyObservation(row);
}
