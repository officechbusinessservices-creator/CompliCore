/**
 * Page taxonomy for CompliCore Command OS.
 *
 * All content encountered during a crawl is classified into one of these types
 * before extraction or rules evaluation begins. Classification drives which
 * extractors run and which rule families apply.
 */

// ---------------------------------------------------------------------------
// Page types
// ---------------------------------------------------------------------------

export const PAGE_TYPES = [
  /** A specific unit listing with rental details, amenities, and availability. */
  "listing_detail",
  /** A page whose primary content is pricing — rate cards, fee tables, quote forms. */
  "pricing",
  /** General terms of service, cancellation policy, or lease terms. */
  "policy_terms",
  /** Privacy policy or data handling disclosure. */
  "privacy",
  /** Contact page — phone, email, form, or chat link. */
  "contact",
  /** Location or neighborhood page — maps, area descriptions, proximity. */
  "location",
  /** Social proof page — reviews, awards, accreditations, certifications. */
  "trust_signals",
  /** Blog post, guide, or editorial content with no rental intent signals. */
  "blog_content",
  /**
   * Page that requires authentication or is dynamically gated (login wall,
   * paywall, session cookie required). Content cannot be evaluated.
   */
  "gated_dynamic",
  /** Root domain page. */
  "homepage",
  /** Catch-all for pages that do not fit any above type. */
  "other",
] as const;

export type PageType = (typeof PAGE_TYPES)[number];

// ---------------------------------------------------------------------------
// Classification result
// ---------------------------------------------------------------------------

/**
 * Produced by the classify step of the pipeline.
 * Each URL gets exactly one PageClassification before scraping begins.
 */
export interface PageClassification {
  page_type: PageType;
  /**
   * Confidence in the classification.
   * - high: strong URL pattern and content signals agree
   * - medium: one signal present (URL or content, not both)
   * - low: inferred from page structure with no clear content signal
   */
  confidence: "high" | "medium" | "low";
  /**
   * Human-readable signals that drove the classification.
   * Example: ["URL contains '/pricing'", "page title includes 'rates'"]
   */
  signals: string[];
}

// ---------------------------------------------------------------------------
// Taxonomy helpers
// ---------------------------------------------------------------------------

/**
 * Page types that carry extractable compliance surface area.
 * Extractors only run against these types.
 */
export const EXTRACTABLE_PAGE_TYPES: ReadonlyArray<PageType> = [
  "listing_detail",
  "pricing",
  "policy_terms",
  "privacy",
  "contact",
  "trust_signals",
  "homepage",
] as const;

/**
 * Page types where a missing counterpart constitutes a content gap.
 * Used by the content gap detector to identify absent page types per domain.
 */
export const REQUIRED_PAGE_TYPES_PER_DOMAIN: ReadonlyArray<PageType> = [
  "pricing",
  "policy_terms",
  "privacy",
  "contact",
] as const;

export function isExtractable(pageType: PageType): boolean {
  return (EXTRACTABLE_PAGE_TYPES as ReadonlyArray<string>).includes(pageType);
}

export function isRequired(pageType: PageType): boolean {
  return (REQUIRED_PAGE_TYPES_PER_DOMAIN as ReadonlyArray<string>).includes(
    pageType,
  );
}
