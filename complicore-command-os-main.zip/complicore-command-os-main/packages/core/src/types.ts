/**
 * Core entity types for CompliCore Command OS.
 *
 * These are the canonical shapes for all 20 data model entities.
 * No DB adapter, ORM, or runtime validation is imported here.
 * All IDs are opaque strings (UUID at runtime).
 * All timestamps are ISO 8601 strings.
 */

import type { PageType } from "./page-taxonomy.js";

// ---------------------------------------------------------------------------
// Shared primitives
// ---------------------------------------------------------------------------

/** ISO 8601 datetime string, e.g. "2026-03-29T00:00:00.000Z" */
export type ISODatetime = string;

// ---------------------------------------------------------------------------
// Evidence — required on every material finding
// ---------------------------------------------------------------------------

/**
 * Every compliance finding, opportunity target, and growth signal must carry
 * a complete evidence record. A finding without evidence is not publishable.
 */
export interface Evidence {
  /** Publicly accessible URL of the source page. */
  source_url: string;
  /**
   * Reference to a Screenshot record that captured this page.
   * Null if screenshot was not captured (e.g., scrape failed before screenshot).
   */
  screenshot_ref: string | null;
  /**
   * Verbatim text extract from the source page that supports the finding.
   * Must be a direct quote — not paraphrased, not AI-generated.
   */
  snippet: string;
  /**
   * Confidence in the finding based on evidence strength.
   * - high: verbatim quote, rule match, and reproducible
   * - medium: verbatim quote and rule match, but some ambiguity
   * - low: inferred, requires human review before publication
   */
  confidence: "high" | "medium" | "low";
  /**
   * Current reviewer gate status.
   * A finding may not be published until status is "approved".
   */
  reviewer_status: "pending" | "approved" | "needs_review" | "rejected";
}

// ---------------------------------------------------------------------------
// Run / Pipeline status
// ---------------------------------------------------------------------------

export type RunStatus =
  | "pending"
  | "running"
  | "completed"
  | "failed"
  | "cancelled";

export type StepName =
  | "discover"
  | "map"
  | "classify"
  | "scrape"
  | "normalize"
  | "rules"
  | "brief";

export type StepStatus =
  | "pending"
  | "running"
  | "completed"
  | "failed"
  | "skipped";

// ---------------------------------------------------------------------------
// Rule families
// ---------------------------------------------------------------------------

export type RuleFamily =
  | "pricing_transparency"
  | "fee_visibility"
  | "policy_coherence"
  | "privacy_presence"
  | "disclosure_signals"
  | "contact_path_completeness"
  | "schema_quality"
  | "trust_signals";

export const RULE_FAMILIES: ReadonlyArray<RuleFamily> = [
  "pricing_transparency",
  "fee_visibility",
  "policy_coherence",
  "privacy_presence",
  "disclosure_signals",
  "contact_path_completeness",
  "schema_quality",
  "trust_signals",
] as const;

// ---------------------------------------------------------------------------
// Content gap types
// ---------------------------------------------------------------------------

export type ContentGapType =
  | "no_pricing"
  | "no_cancellation_policy"
  | "no_privacy_policy"
  | "no_contact_path"
  | "no_fee_disclosure"
  | "no_trust_signals"
  | "other";

// ---------------------------------------------------------------------------
// Workspace
// ---------------------------------------------------------------------------

/**
 * A workspace represents one operator profile in one metro.
 * v1: exactly one workspace per deployment.
 */
export interface Workspace {
  id: string;
  name: string;
  /** City and state, e.g. "Austin, TX" */
  metro: string;
  /** The operator's own domain — excluded from competitor analysis. */
  operator_domain: string;
  created_at: ISODatetime;
  updated_at: ISODatetime;
}

// ---------------------------------------------------------------------------
// Objective
// ---------------------------------------------------------------------------

export type ObjectiveType =
  | "compliance"
  | "market_intelligence"
  | "growth"
  | "acquisition";

export interface Objective {
  id: string;
  workspace_id: string;
  type: ObjectiveType;
  description: string;
  created_at: ISODatetime;
}

// ---------------------------------------------------------------------------
// Run
// ---------------------------------------------------------------------------

/** A single execution of the full ingestion pipeline for one metro. */
export interface Run {
  id: string;
  workspace_id: string;
  status: RunStatus;
  metro: string;
  started_at: ISODatetime | null;
  completed_at: ISODatetime | null;
  error: string | null;
  created_at: ISODatetime;
}

// ---------------------------------------------------------------------------
// Step
// ---------------------------------------------------------------------------

/** One stage within a Run. Steps are sequential per the pipeline definition. */
export interface Step {
  id: string;
  run_id: string;
  name: StepName;
  status: StepStatus;
  /** Number of input records this step received. */
  input_count: number;
  /** Number of output records this step produced. */
  output_count: number;
  error: string | null;
  started_at: ISODatetime | null;
  completed_at: ISODatetime | null;
}

// ---------------------------------------------------------------------------
// Audit event
// ---------------------------------------------------------------------------

export type AuditActor = "system" | "reviewer";

/** Immutable log of all state-changing actions in the system. */
export interface AuditEvent {
  id: string;
  workspace_id: string;
  run_id: string | null;
  actor: AuditActor;
  /** User ID of the reviewer, if actor is "reviewer". */
  actor_id: string | null;
  /** Action taken, e.g. "finding.approved", "report.exported", "run.started" */
  action: string;
  entity_type: string;
  entity_id: string;
  /** Arbitrary payload — captures before/after state or action parameters. */
  payload: Record<string, unknown>;
  created_at: ISODatetime;
}

// ---------------------------------------------------------------------------
// Domain
// ---------------------------------------------------------------------------

export type DomainStatus = "mapped" | "blocked" | "unreachable";

/** A competitor domain discovered for the metro in a given run. */
export interface Domain {
  id: string;
  run_id: string;
  /** Bare domain, e.g. "example.com" */
  domain: string;
  robots_txt_url: string | null;
  /** URL paths disallowed by robots.txt */
  disallowed_paths: string[];
  sitemap_url: string | null;
  status: DomainStatus;
  crawled_at: ISODatetime | null;
}

// ---------------------------------------------------------------------------
// SourceUrl
// ---------------------------------------------------------------------------

export type UrlStatus = "pending" | "scraped" | "failed" | "skipped";

/**
 * A discovered URL belonging to a domain.
 * Named SourceUrl to avoid collision with the global Web API URL class.
 */
export interface SourceUrl {
  id: string;
  domain_id: string;
  url: string;
  content_type_hint: PageType;
  /** Crawl depth from the domain root (0 = homepage, 1 = direct link, etc.) */
  depth: number;
  status: UrlStatus;
  discovered_at: ISODatetime;
}

// ---------------------------------------------------------------------------
// SourcePage
// ---------------------------------------------------------------------------

/** The raw scraped content of a single URL. */
export interface SourcePage {
  id: string;
  url_id: string;
  domain_id: string;
  url: string;
  raw_html: string | null;
  text_content: string | null;
  http_status: number;
  scraped_at: ISODatetime;
  content_type: PageType;
  word_count: number | null;
}

// ---------------------------------------------------------------------------
// Screenshot
// ---------------------------------------------------------------------------

/** A screenshot captured for a source page during the scrape step. */
export interface Screenshot {
  id: string;
  source_page_id: string;
  /** File path or blob storage reference. */
  file_ref: string;
  width: number;
  height: number;
  captured_at: ISODatetime;
}

// ---------------------------------------------------------------------------
// Listing
// ---------------------------------------------------------------------------

/** Structured rental unit data extracted from a listing_detail page. */
export interface Listing {
  id: string;
  source_page_id: string;
  domain_id: string;
  unit_name: string | null;
  bedroom_count: number | null;
  bathroom_count: number | null;
  square_footage: number | null;
  /** Verbatim amenity strings as found on the page. */
  amenities: string[];
  minimum_stay_nights: number | null;
  availability_mentioned: boolean;
}

// ---------------------------------------------------------------------------
// PricingObservation
// ---------------------------------------------------------------------------

export type PriceUnit = "per_night" | "per_month" | "per_week" | "unknown";

/** Pricing data extracted from any page that displays a price. */
export interface PricingObservation {
  id: string;
  source_page_id: string;
  domain_id: string;
  /** Raw price text as found, e.g. "$4,200/mo" */
  price_raw: string;
  /** Parsed numeric value in USD, null if not parseable. */
  price_numeric: number | null;
  price_unit: PriceUnit;
  /** Verbatim fee names found on the page, e.g. ["cleaning fee", "service fee"] */
  fees_mentioned: string[];
  /** True if an all-inclusive total is shown anywhere on the page. */
  total_cost_shown: boolean;
  /** Verbatim 1–2 sentence extract that supports this observation. */
  price_quote: string;
}

// ---------------------------------------------------------------------------
// PolicyObservation
// ---------------------------------------------------------------------------

export type PolicyType =
  | "cancellation"
  | "refund"
  | "lease"
  | "house_rules"
  | "other";

/** A policy statement found on any page. */
export interface PolicyObservation {
  id: string;
  source_page_id: string;
  domain_id: string;
  policy_type: PolicyType;
  /** Verbatim extract, max 300 characters. */
  policy_summary: string;
  /** URL of a dedicated policy page, if the policy is not inline. */
  policy_url: string | null;
}

// ---------------------------------------------------------------------------
// SchemaObservation
// ---------------------------------------------------------------------------

/** Structured data signals found on a page (JSON-LD, OG tags, schema.org). */
export interface SchemaObservation {
  id: string;
  source_page_id: string;
  has_structured_data: boolean;
  /** Schema.org type names found, e.g. ["LodgingBusiness", "Product"] */
  schema_types_found: string[];
  title_present: boolean;
  meta_description_present: boolean;
}

// ---------------------------------------------------------------------------
// ContentGap
// ---------------------------------------------------------------------------

/**
 * A content element that should be present on a page or domain but is absent.
 * Absence is a gap; a policy that exists but is defective is a ComplianceFinding.
 */
export interface ContentGap {
  id: string;
  source_page_id: string;
  domain_id: string;
  gap_type: ContentGapType;
  /** One sentence describing what is absent and why it matters. */
  description: string;
}

// ---------------------------------------------------------------------------
// ComplianceFinding
// ---------------------------------------------------------------------------

export type FindingResult = "FAIL" | "WARN";
export type FindingSeverity = "high" | "medium";
export type FindingStatus = "open" | "approved" | "needs_review" | "rejected";

/**
 * A rule violation found on a specific source page.
 * Extends Evidence — all fields in Evidence are required.
 * A finding without complete evidence cannot be marked "approved".
 */
export interface ComplianceFinding extends Evidence {
  id: string;
  source_page_id: string;
  domain_id: string;
  run_id: string;
  rule_family: RuleFamily;
  rule_result: FindingResult;
  severity: FindingSeverity;
  /** One sentence describing what the rule detected and why it matters. */
  description: string;
  status: FindingStatus;
  created_at: ISODatetime;
}

// ---------------------------------------------------------------------------
// OpportunityTarget
// ---------------------------------------------------------------------------

export type SignalTier = "HIGH" | "MODERATE" | "LOW";

export interface OpportunityScoreBreakdown {
  compliance_failure_density: number;
  content_gap_density: number;
  pricing_opacity_flag: number;
  policy_absence_flag: number;
  schema_quality_fail: number;
}

/**
 * An acquisition or growth target derived from competitor analysis.
 * Score is 0–100 and must trace to specific finding and gap records.
 */
export interface OpportunityTarget {
  id: string;
  domain_id: string;
  run_id: string;
  /** Aggregate score 0–100. */
  score: number;
  signal_tier: SignalTier;
  score_breakdown: OpportunityScoreBreakdown;
  /** IDs of ComplianceFinding records that contributed to this score. */
  contributing_finding_ids: string[];
  /** IDs of ContentGap records that contributed to this score. */
  contributing_gap_ids: string[];
  top_signals: string[];
  /** One sentence — what the signals show. Must not speculate about owner intent. */
  recommendation: string;
  reviewer_status: Evidence["reviewer_status"];
  created_at: ISODatetime;
}

// ---------------------------------------------------------------------------
// OutboundBrief
// ---------------------------------------------------------------------------

export type OutboundBriefStatus = "draft" | "approved" | "sent";

/** A contact-ready brief for a single acquisition target. */
export interface OutboundBrief {
  id: string;
  run_id: string;
  opportunity_target_id: string;
  content: string;
  status: OutboundBriefStatus;
  reviewer_status: Evidence["reviewer_status"];
  created_at: ISODatetime;
  approved_at: ISODatetime | null;
}

// ---------------------------------------------------------------------------
// Report
// ---------------------------------------------------------------------------

export type ReportType =
  | "weekly_brief"
  | "compliance_log"
  | "growth_brief"
  | "acquisition_list";

export type ReportStatus = "draft" | "approved" | "exported";

/**
 * A published output record. The report record is the gating checkpoint —
 * status must be "approved" before export is permitted.
 */
export interface Report {
  id: string;
  run_id: string;
  workspace_id: string;
  type: ReportType;
  status: ReportStatus;
  metro: string;
  generated_at: ISODatetime;
  approved_at: ISODatetime | null;
  exported_at: ISODatetime | null;
}
