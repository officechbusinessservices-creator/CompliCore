# Working Style

- No fluff
- Plan first
- Define DONE before execution
- Revise, do not redo
- Use evidence-backed outputs
- Surface conflicts as NEEDS-REVIEW
- Prefer deterministic workflows over freeform generation
- Use existing files before inventing new abstractions