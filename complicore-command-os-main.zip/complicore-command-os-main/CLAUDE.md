# CompliCore Command OS

## Product
CompliCore Command OS is a compliance-first market, growth, and acquisition intelligence system for corporate housing operators.

## Core Job
Turn public web signals into evidence-backed weekly outputs:
- competitor intelligence
- compliance findings
- growth gaps
- acquisition targets
- outbound-ready briefs

## v1 Scope
- one metro
- one operator profile
- public web only
- reviewer-gated outputs
- evidence-backed findings only

## Non-Goals
- payments
- booking engine
- guest messaging automation
- smart lock integrations
- plugin marketplace
- mobile app
- global compliance engine
- unverified third-party packages
- finance-trading modules

## Stack
- apps/web = dashboard
- apps/worker = jobs
- packages/core = schemas and shared types
- packages/firecrawl = discovery and ingestion
- packages/rules = rules engine

## Build Rules
- show plan before execution
- define DONE for every task
- no guessing
- no fake production data
- every material finding needs evidence
- keep changes scoped
- write tests for core logic

## Core Outcome
One metro in -> one evidence-backed weekly brief out