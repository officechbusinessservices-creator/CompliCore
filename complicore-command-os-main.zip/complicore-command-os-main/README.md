# CompliCore Fleet OS

**You run one command. You get back every compliance gap your competitors have, ranked by acquisition value.**

Corporate housing operators spend thousands per month on manual market research. CompliCore replaces that with a pipeline that discovers competitors, scrapes their sites, evaluates 7 compliance rule families, scores acquisition targets, and delivers a reviewer-gated brief — every week, automatically.

> v1 scope: one metro · one operator profile · public web only · evidence-backed findings only

---

## Quickstart

```bash
git clone https://github.com/officechbusinessservices-creator/complicore-command-os
cd complicore-command-os
pnpm install
echo "DATABASE_URL=postgresql://..." > .env.local
pnpm dev:demo
```

Open `http://localhost:3000`.

No Firecrawl key needed — the mock client replays real fixture data. You get actual findings, targets, and a weekly brief on first run.

---

## What happens when you run it

```
[1/7] discover   → 3 competitor domains found in Austin, TX
[2/7] map        → URLs inventoried across all domains
[3/7] classify   → homepages, pricing pages, policy pages identified
[4/7] scrape     → pages fetched, markdown + screenshots captured
[5/7] normalize  → listings, prices, policies, content gaps extracted
[6/7] rules      → 7 compliance families evaluated on every page
[7/7] brief      → targets scored 0–100, weekly brief generated

Run complete (mock client — no network, instant)
  Domains:   3
  Findings:  21  (6 high severity)
  Targets:    3  (2 HIGH signal)
```

With a real `FIRECRAWL_API_KEY`, the pipeline discovers ~10–15 domains per metro and takes ~4 minutes.

Every finding has a source URL, verbatim snippet, and screenshot. Nothing is paraphrased. Nothing is AI-hallucinated. Every output is blocked behind a human reviewer.

---

## Real findings (Austin, TX · March 2026)

```
apartments.com · privacy_presence · HIGH · FAIL
  "No privacy policy was found on the homepage. Operating a transactional
   website without a privacy policy is a compliance risk in most jurisdictions
   (CCPA, GDPR, state-level requirements)."
  Source: https://apartments.com
  Snippet: "# Discover Your New Home Helping renters find their perfect rental…"

alamocorporatehousing.com · disclosure_signals · HIGH · FAIL
  "Pricing information is displayed without any accompanying policy terms
   (no cancellation, refund, lease, or house rules). Guests are shown a price
   but cannot evaluate the conditions of the agreement."
  Snippet: "One bedroom corporate apartments in San Antonio begin at $92/night…"

apartments.com · fee_visibility · MEDIUM · FAIL
  "No fees are disclosed and no all-inclusive total is shown. Guests cannot
   determine the true cost from this page."
```

**Acquisition targets:**

| Domain | Score | Tier | Findings |
|--------|-------|------|----------|
| apartments.com | 85/100 | HIGH | 6 |
| corporatehousing.com | 85/100 | HIGH | 6 |
| theblueground.com | 85/100 | HIGH | 4 |
| housestay.com | 85/100 | HIGH | 4 |
| cwshousing.com | 70/100 | HIGH | 2 |
| wateroakapartments.com | 70/100 | HIGH | 3 |

---

## Why this matters

A HIGH-signal competitor finding (missing privacy policy + no fee disclosure + no cancellation terms) represents:

- **Legal exposure** quantifiable in five to six figures under CCPA, GDPR, and state consumer protection law
- **Trust gap** that a compliant operator can use in sales conversations and marketing
- **Acquisition signal** — a domain under compliance pressure is a motivated seller

CompliCore surfaces this systematically. One operator with this system has information asymmetry over every competitor running blind.

---

## Compliance rule families

| Rule | What it checks |
|------|----------------|
| `pricing_transparency` | Rate period stated with every price |
| `fee_visibility` | Fees disclosed or all-inclusive total shown |
| `privacy_presence` | Privacy policy linked and reachable |
| `disclosure_signals` | Cancellation, refund, and lease terms present |
| `contact_path_completeness` | Phone, email, form, or chat reachable from page |
| `trust_signals` | Reviews, certifications, or trust badges |
| `schema_quality` | JSON-LD structured data present and valid |

Every rule returns `FAIL`, `WARN`, or `PASS` with a confidence score. Uncertain results are flagged `needs_review` — not published, not dropped.

---

## Architecture

```
pnpm dev:demo
      │
      ├─ packages/core         Drizzle schema + Neon Postgres + typed repos
      │   └─ 14 entities       runs · domains · pages · findings · targets · audit_events
      │
      ├─ packages/firecrawl    Firecrawl wrappers (search, map, classify, scrape, normalize)
      │
      ├─ packages/rules        7 compliance rule families — pure functions, fully tested
      │
      ├─ apps/worker           Pipeline runner
      │   └─ pipeline.ts       discover → map → classify → scrape → normalize → rules → brief
      │
      └─ apps/web              Next.js 15 dashboard (Server Components, no auth yet)
          ├─ /compliance       Finding list + detail + reviewer panel
          ├─ /evidence         Evidence viewer (snippet + screenshot)
          ├─ /acquisition      Target list + detail
          ├─ /growth           Content gap analysis
          ├─ /market           Domain overview
          └─ /reports          Weekly brief viewer
```

**Reviewer gate:**

```
finding inserted → reviewer_status: "pending"
                        │
          ┌─────────────┼──────────────┐
          ▼             ▼              ▼
       approve       flag          reject (note required)
          │         (needs_review)     │
          ▼             │              ▼
    status: approved    │         status: rejected
    → eligible for      │         → excluded from
      published report  ▼           published report
                     pending
```

Every transition writes an `audit_event`. The log is append-only. Nothing is silently updated.

---

## Dashboard

The web app reads directly from Postgres. Server Components — no API layer, no client fetching. Every page shows live data from the last run.

| Page | What you see |
|------|-------------|
| `/` | Run summary, headline metrics, step timeline |
| `/compliance` | All findings, filterable by severity and reviewer status |
| `/compliance/[id]` | Full evidence: snippet, screenshot, source page, audit trail |
| `/evidence/[id]` | Standalone evidence record for any finding or target |
| `/acquisition/[id]` | Target score breakdown, contributing findings, recommendation |
| `/reports/[id]` | Full weekly brief with finding log and outbound briefs |

---

## Stack

- **Next.js 15** (App Router, Server Components)
- **Drizzle ORM + Neon** (serverless Postgres)
- **Firecrawl** (web scraping — swap for any scraper)
- **pnpm workspaces + Turborepo**
- No auth yet — reviewer identity is `reviewer-dev` placeholder

---

## Roadmap

- [ ] Scheduled weekly runs (cron)
- [x] Rate-limit retry with exponential backoff
- [ ] Outbound brief builder — per-target contact drafts with citation
- [ ] Multi-metro support
- [ ] Operator profile comparison across runs
- [ ] Auth + multi-user reviewer roles

---

## License

MIT
