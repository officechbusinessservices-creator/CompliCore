/**
 * Golden: homepage with no contact path — has pricing and privacy link but no phone/email/form.
 * Expected violations: contact_path_completeness → fail
 */
import type { GoldenExample } from "./types.js";

export const contactHomepageMissing: GoldenExample = {
  id: "contact-homepage-missing",
  description: "homepage — no contact path (phone, email, form, or chat link)",
  page: {
    id: "page-golden-006",
    url_id: "url-golden-006",
    domain_id: "domain-golden-001",
    url: "https://example-housing.com/",
    raw_html: null,
    text_content: `# Capital City Suites
Luxury furnished apartments in downtown Austin.
Privacy policy | Terms of service
Award-winning hospitality since 2019.`,
    http_status: 200,
    scraped_at: "2026-03-29T00:00:00.000Z",
    content_type: "homepage",
    word_count: 18,
  },
  expected: {
    extraction: {
      has_listing: false,
      pricing_observation_count: 0,
      policy_observation_count: 0,
      has_schema_observation: false,
      content_gap_types: ["no_pricing", "no_contact_path"],
    },
    violations: [
      { rule_family: "contact_path_completeness", result: "fail" },
      { rule_family: "pricing_transparency", result: "uncertain_needs_review" },
    ],
    passes: ["privacy_presence", "trust_signals", "schema_quality", "policy_coherence"],
  },
};
