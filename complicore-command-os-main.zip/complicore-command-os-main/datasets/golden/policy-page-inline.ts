/**
 * Golden: policy_terms page with inline cancellation policy (no policy URL).
 * Expected violations: policy_coherence → uncertain_needs_review (inline, no URL)
 */
import type { GoldenExample } from "./types.js";

export const policyPageInline: GoldenExample = {
  id: "policy-page-inline",
  description: "policy_terms — cancellation policy inline only, no dedicated URL",
  page: {
    id: "page-golden-004",
    url_id: "url-golden-004",
    domain_id: "domain-golden-001",
    url: "https://example-housing.com/terms",
    raw_html: null,
    text_content: `# Cancellation and Refund Policy
Cancellation policy: Please allow 30 days advance notice before your check-in date for a full refund to be processed.
For questions, contact our support team.`,
    http_status: 200,
    scraped_at: "2026-03-29T00:00:00.000Z",
    content_type: "policy_terms",
    word_count: 35,
  },
  expected: {
    extraction: {
      has_listing: false,
      pricing_observation_count: 0,
      policy_observation_count: 2,
      has_schema_observation: false,
      content_gap_types: [],
    },
    violations: [
      { rule_family: "policy_coherence", result: "uncertain_needs_review" },
    ],
    passes: ["pricing_transparency", "privacy_presence", "schema_quality", "contact_path_completeness", "trust_signals"],
  },
};
