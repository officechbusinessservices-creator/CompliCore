/**
 * Golden: homepage missing privacy policy — has contact and reviews but no privacy link.
 * Expected violations: privacy_presence → fail
 */
import type { GoldenExample } from "./types.js";

export const privacyHomepageMissing: GoldenExample = {
  id: "privacy-homepage-missing",
  description: "homepage — no privacy policy link or mention",
  page: {
    id: "page-golden-005",
    url_id: "url-golden-005",
    domain_id: "domain-golden-001",
    url: "https://example-housing.com/",
    raw_html: null,
    text_content: `# Austin Stays — Corporate Housing
Premium furnished apartments for business travelers.
Contact us: (512) 555-0199 · info@austinstays.com
★★★★☆ 4.8 from 312 guest reviews`,
    http_status: 200,
    scraped_at: "2026-03-29T00:00:00.000Z",
    content_type: "homepage",
    word_count: 20,
  },
  expected: {
    extraction: {
      has_listing: false,
      pricing_observation_count: 0,
      policy_observation_count: 0,
      has_schema_observation: false,
      content_gap_types: ["no_pricing", "no_privacy_policy"],
    },
    violations: [
      { rule_family: "privacy_presence", result: "fail" },
      { rule_family: "pricing_transparency", result: "uncertain_needs_review" },
    ],
    passes: ["contact_path_completeness", "trust_signals", "schema_quality", "policy_coherence"],
  },
};
