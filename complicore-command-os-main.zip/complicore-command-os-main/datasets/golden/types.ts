/**
 * Types for golden evaluation examples.
 * Each example declares the input page and expected outputs for both
 * the extraction (normalize) step and the rules step.
 */

import type { SourcePage } from "../../packages/core/src/types.js";
import type { ContentGapType, RuleFamily } from "../../packages/core/src/types.js";
import type { RuleResult } from "../../packages/rules/src/index.js";

export interface ExpectedViolation {
  rule_family: RuleFamily | "fee_visibility";
  result: Exclude<RuleResult, "pass">;
  /** Minimum number of violations for this rule family (default 1). */
  min_count?: number;
}

export interface GoldenExample {
  id: string;
  description: string;
  /** Synthetic page input to normalizeSourcePage() and evaluateAllRules(). */
  page: SourcePage & { id: string };
  expected: {
    extraction: {
      has_listing: boolean;
      pricing_observation_count: number;
      policy_observation_count: number;
      /** True if raw_html is non-null (schema observation will be attempted). */
      has_schema_observation: boolean;
      /** Content gap types expected in content_gaps[]. */
      content_gap_types: ContentGapType[];
    };
    /** Rule families + result that must appear in violations. */
    violations: ExpectedViolation[];
    /** Rule families that must produce zero violations. */
    passes: (RuleFamily | "fee_visibility")[];
  };
}
