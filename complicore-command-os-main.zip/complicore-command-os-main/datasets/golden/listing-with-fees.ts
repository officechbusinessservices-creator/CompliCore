/**
 * Golden: listing_detail page with price and fees mentioned but no all-in total.
 *
 * Expected extraction:
 *   - listing present (2br/1ba/800sqft)
 *   - 1 pricing observation: $4,500/month, fees: [cleaning fee, security deposit], total_cost_shown: false
 *   - content_gaps: [no_cancellation_policy, no_fee_disclosure] (no_fee_disclosure: false — "fee" present)
 *
 * Expected violations:
 *   - fee_visibility → uncertain_needs_review (fees present but no all-in total)
 *   - schema_quality → fail (no JSON-LD in raw_html)
 */

import type { GoldenExample } from "./types.js";

export const listingWithFees: GoldenExample = {
  id: "listing-with-fees",
  description: "listing_detail with price and partial fee disclosure — no all-in total",
  page: {
    id: "page-golden-001",
    url_id: "url-golden-001",
    domain_id: "domain-golden-001",
    url: "https://example-housing.com/listings/downtown-loft",
    raw_html: "<html><head><title>Downtown Loft</title></head><body><p>Downtown Loft — 2 bedrooms</p></body></html>",
    text_content: `# Downtown Loft
2 bedrooms. 1 bathroom. 800 sq ft.
Amenities: WiFi, parking, laundry.
From $4,500/month.
Cleaning fee: $200. Security deposit required.
Email us at booking@example.com for availability.`,
    http_status: 200,
    scraped_at: "2026-03-29T00:00:00.000Z",
    content_type: "listing_detail",
    word_count: 30,
  },
  expected: {
    extraction: {
      has_listing: true,
      pricing_observation_count: 1,
      policy_observation_count: 0,
      has_schema_observation: true,
      content_gap_types: ["no_cancellation_policy"],
    },
    violations: [
      { rule_family: "fee_visibility", result: "uncertain_needs_review" },
      { rule_family: "schema_quality", result: "fail" },
    ],
    passes: ["pricing_transparency", "privacy_presence", "contact_path_completeness", "trust_signals"],
  },
};
