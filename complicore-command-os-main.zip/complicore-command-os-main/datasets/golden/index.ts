export type { GoldenExample, ExpectedViolation } from "./types.js";
export { listingWithFees } from "./listing-with-fees.js";
export { listingNoPricing } from "./listing-no-pricing.js";
export { pricingPageFeesPartial } from "./pricing-page-fees-partial.js";
export { policyPageInline } from "./policy-page-inline.js";
export { privacyHomepageMissing } from "./privacy-homepage-missing.js";
export { contactHomepageMissing } from "./contact-homepage-missing.js";
// Fixture-promoted examples (stabilized from the Austin mock pipeline run)
export { fixCapListingNoPricing } from "./fixture-cap-listing-no-pricing.js";
export { fixAusListingWithFees } from "./fixture-aus-listing-with-fees.js";
export { fixAusHomepageClean } from "./fixture-aus-homepage-clean.js";

import { listingWithFees } from "./listing-with-fees.js";
import { listingNoPricing } from "./listing-no-pricing.js";
import { pricingPageFeesPartial } from "./pricing-page-fees-partial.js";
import { policyPageInline } from "./policy-page-inline.js";
import { privacyHomepageMissing } from "./privacy-homepage-missing.js";
import { contactHomepageMissing } from "./contact-homepage-missing.js";
import { fixCapListingNoPricing } from "./fixture-cap-listing-no-pricing.js";
import { fixAusListingWithFees } from "./fixture-aus-listing-with-fees.js";
import { fixAusHomepageClean } from "./fixture-aus-homepage-clean.js";

export const ALL_GOLDEN_EXAMPLES = [
  listingWithFees,
  listingNoPricing,
  pricingPageFeesPartial,
  policyPageInline,
  privacyHomepageMissing,
  contactHomepageMissing,
  fixCapListingNoPricing,
  fixAusListingWithFees,
  fixAusHomepageClean,
];
