/**
 * Golden (fixture-promoted): austinstays.com south-congress-2br
 * listing_detail — has price, cleaning fee, inline cancellation policy, schema.org Accommodation
 *
 * Source: datasets/golden/input/austinstays-listing-with-fees.json
 * Expected: datasets/golden/expected/austinstays-listing-with-fees.json
 */
import type { GoldenExample } from "./types.js";

export const fixAusListingWithFees: GoldenExample = {
  id: "fix-aus-listing-with-fees",
  description: "fixture: austinstays listing_detail — price present, cleaning fee without all-in total, cancellation inline",
  page: {
    id: "page-fix-aus-001",
    url_id: "url-fix-aus-001",
    domain_id: "domain-fix-aus",
    url: "https://austinstays.com/listings/south-congress-2br",
    raw_html:
      '<html><head><title>South Congress 2BR</title><script type="application/ld+json">{"@context":"https://schema.org","@type":"Accommodation","name":"South Congress 2BR"}</script></head><body></body></html>',
    text_content:
      "# South Congress 2BR\n\nFrom $4,800/month. Cleaning fee: $200.\n\n2 bedrooms. 2 bathrooms. 1,100 sq ft.\n\nCancellation policy: 30-day notice required.\n\nAmenities: WiFi, parking, in-unit laundry.\n\nContact us: 512-555-0100",
    http_status: 200,
    scraped_at: "2026-03-30T00:00:00.000Z",
    content_type: "listing_detail",
    word_count: 38,
  },
  expected: {
    extraction: {
      has_listing: true,
      pricing_observation_count: 1,
      policy_observation_count: 1,
      has_schema_observation: true,
      content_gap_types: [],
    },
    violations: [
      { rule_family: "fee_visibility", result: "uncertain_needs_review" },
      { rule_family: "policy_coherence", result: "uncertain_needs_review" },
    ],
    passes: ["pricing_transparency", "privacy_presence", "contact_path_completeness", "trust_signals"],
  },
};
