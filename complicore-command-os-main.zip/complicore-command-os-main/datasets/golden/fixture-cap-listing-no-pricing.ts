/**
 * Golden (fixture-promoted): capitalcityliving.com downtown studio
 * listing_detail — no pricing, no schema, amenities present
 *
 * Source: datasets/golden/input/capitalcity-listing-no-pricing.json
 * Expected: datasets/golden/expected/capitalcity-listing-no-pricing.json
 */
import type { GoldenExample } from "./types.js";

export const fixCapListingNoPricing: GoldenExample = {
  id: "fix-cap-listing-no-pricing",
  description: "fixture: capitalcityliving listing_detail — pricing gated behind contact form, no JSON-LD",
  page: {
    id: "page-fix-cap-001",
    url_id: "url-fix-cap-001",
    domain_id: "domain-fix-cap",
    url: "https://capitalcityliving.com/listings/downtown-studio",
    raw_html: "<html><head><title>Downtown Studio</title></head><body></body></html>",
    text_content:
      "# Downtown Studio\n\nContact us for pricing.\n\n1 bedroom. 1 bathroom. 480 sq ft.\n\nAmenities: WiFi, washer/dryer, parking.",
    http_status: 200,
    scraped_at: "2026-03-30T00:00:00.000Z",
    content_type: "listing_detail",
    word_count: 18,
  },
  expected: {
    extraction: {
      has_listing: true,
      pricing_observation_count: 0,
      policy_observation_count: 0,
      has_schema_observation: true,
      content_gap_types: ["no_pricing", "no_cancellation_policy", "no_fee_disclosure"],
    },
    violations: [
      { rule_family: "pricing_transparency", result: "fail" },
      { rule_family: "schema_quality", result: "fail" },
    ],
    passes: ["privacy_presence", "policy_coherence", "contact_path_completeness", "trust_signals"],
  },
};
