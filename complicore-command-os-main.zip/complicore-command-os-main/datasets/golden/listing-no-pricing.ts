/**
 * Golden: listing_detail page where pricing is hidden ("Contact us for pricing").
 *
 * Expected violations:
 *   - pricing_transparency → fail (no pricing observations on listing_detail)
 *   - schema_quality → fail (no JSON-LD)
 */

import type { GoldenExample } from "./types.js";

export const listingNoPricing: GoldenExample = {
  id: "listing-no-pricing",
  description: "listing_detail — pricing hidden behind contact form",
  page: {
    id: "page-golden-002",
    url_id: "url-golden-002",
    domain_id: "domain-golden-001",
    url: "https://example-housing.com/listings/south-congress-suite",
    raw_html: "<html><head><title>South Congress Suite</title></head><body></body></html>",
    text_content: `# South Congress Suite
1 bedroom. 1 bathroom. 650 sq ft.
Contact us for pricing. Amenities: WiFi, gym access.`,
    http_status: 200,
    scraped_at: "2026-03-29T00:00:00.000Z",
    content_type: "listing_detail",
    word_count: 18,
  },
  expected: {
    extraction: {
      has_listing: true,
      pricing_observation_count: 0,
      policy_observation_count: 0,
      has_schema_observation: true,
      content_gap_types: ["no_pricing", "no_cancellation_policy", "no_fee_disclosure"],
    },
    violations: [
      { rule_family: "pricing_transparency", result: "fail" },
      { rule_family: "schema_quality", result: "fail" },
    ],
    passes: ["privacy_presence", "policy_coherence", "contact_path_completeness", "trust_signals"],
  },
};
