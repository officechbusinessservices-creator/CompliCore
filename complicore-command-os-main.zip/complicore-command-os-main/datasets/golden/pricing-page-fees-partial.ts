/**
 * Golden: pricing page with fees mentioned but no all-in total.
 * Expected violations: fee_visibility → uncertain_needs_review
 */
import type { GoldenExample } from "./types.js";

export const pricingPageFeesPartial: GoldenExample = {
  id: "pricing-page-fees-partial",
  description: "pricing page — fees mentioned, no all-inclusive total shown",
  page: {
    id: "page-golden-003",
    url_id: "url-golden-003",
    domain_id: "domain-golden-001",
    url: "https://example-housing.com/pricing",
    raw_html: null,
    text_content: `# Pricing
Suites from $3,200/month.
Cleaning fee: $200. Security deposit required.
Rates vary by season.`,
    http_status: 200,
    scraped_at: "2026-03-29T00:00:00.000Z",
    content_type: "pricing",
    word_count: 15,
  },
  expected: {
    extraction: {
      has_listing: false,
      pricing_observation_count: 1,
      policy_observation_count: 0,
      has_schema_observation: false,
      content_gap_types: ["no_cancellation_policy"],
    },
    violations: [
      { rule_family: "fee_visibility", result: "uncertain_needs_review" },
    ],
    passes: ["pricing_transparency", "schema_quality", "privacy_presence", "contact_path_completeness", "trust_signals"],
  },
};
