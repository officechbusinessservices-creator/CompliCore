/**
 * Golden (fixture-promoted): austinstays.com homepage
 * homepage — has privacy link, schema.org LodgingBusiness, phone, guest reviews
 * Represents the "best-in-class competitor" baseline that passes most rules.
 *
 * Source: datasets/golden/input/austinstays-homepage-clean.json
 * Expected: datasets/golden/expected/austinstays-homepage-clean.json
 */
import type { GoldenExample } from "./types.js";

export const fixAusHomepageClean: GoldenExample = {
  id: "fix-aus-homepage-clean",
  description: "fixture: austinstays homepage — privacy present, schema.org, phone, reviews; only pricing uncertain",
  page: {
    id: "page-fix-aus-home",
    url_id: "url-fix-aus-home",
    domain_id: "domain-fix-aus",
    url: "https://austinstays.com/",
    raw_html:
      '<html><head><title>Austin Stays</title><meta name="description" content="Furnished apartments Austin"/><script type="application/ld+json">{"@context":"https://schema.org","@type":"LodgingBusiness","name":"Austin Stays"}</script></head><body></body></html>',
    text_content:
      "# Austin Stays — Furnished Monthly Apartments\n\nPrivacy policy | Terms of service\n\nContact: 512-555-0100\n\nReviews: ★★★★☆ 4.6 from 312 guests",
    http_status: 200,
    scraped_at: "2026-03-30T00:00:00.000Z",
    content_type: "homepage",
    word_count: 20,
  },
  expected: {
    extraction: {
      has_listing: false,
      pricing_observation_count: 0,
      policy_observation_count: 0,
      has_schema_observation: true,
      content_gap_types: ["no_pricing"],
    },
    violations: [
      { rule_family: "pricing_transparency", result: "uncertain_needs_review" },
    ],
    passes: ["privacy_presence", "contact_path_completeness", "trust_signals", "schema_quality", "policy_coherence"],
  },
};
