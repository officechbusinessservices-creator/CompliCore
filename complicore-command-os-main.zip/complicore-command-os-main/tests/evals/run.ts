/**
 * Evaluation runner for CompliCore Command OS.
 *
 * Three eval suites:
 *   1. Extraction precision — normalizeSourcePage() output matches golden expected
 *   2. Rule precision       — evaluateAllRules() violations match golden expected
 *   3. Evidence coverage    — every violation has non-empty snippet + source_url
 *
 * Fails on:
 *   - Missing evidence (empty snippet or source_url)
 *   - Invalid output contract (bad rule_family, severity, confidence, result, reviewer_status)
 *   - Extraction mismatch (wrong counts, wrong gap types)
 *   - Rule mismatch (expected violation absent, unexpected violation on "passes" family)
 *
 * Run: node --import tsx/esm tests/evals/run.ts
 */

import { normalizeSourcePage } from "../../packages/firecrawl/src/normalize.js";
import { evaluateAllRules, collectViolations } from "../../packages/rules/src/index.js";
import { RULE_FAMILIES } from "../../packages/core/src/types.js";
import { ALL_GOLDEN_EXAMPLES } from "../../datasets/golden/index.js";
import type { GoldenExample } from "../../datasets/golden/types.js";
import type { RuleViolation } from "../../packages/rules/src/index.js";

// ---------------------------------------------------------------------------
// ANSI helpers
// ---------------------------------------------------------------------------

const GREEN = (s: string) => `\x1b[32m${s}\x1b[0m`;
const RED   = (s: string) => `\x1b[31m${s}\x1b[0m`;
const DIM   = (s: string) => `\x1b[2m${s}\x1b[0m`;
const BOLD  = (s: string) => `\x1b[1m${s}\x1b[0m`;

// ---------------------------------------------------------------------------
// Result tracking
// ---------------------------------------------------------------------------

interface CheckResult {
  pass: boolean;
  label: string;
  detail?: string;
}

const results: CheckResult[] = [];

function check(pass: boolean, label: string, detail?: string): void {
  results.push({ pass, label, detail });
  const icon = pass ? GREEN("✓") : RED("✗");
  console.log(`  ${icon} ${label}${detail ? DIM(" — " + detail) : ""}`);
}

// ---------------------------------------------------------------------------
// Output contract validation
// ---------------------------------------------------------------------------

const VALID_SEVERITIES = new Set(["high", "medium"]);
const VALID_CONFIDENCES = new Set(["high", "medium", "low"]);
const VALID_RESULTS = new Set(["fail", "uncertain_needs_review"]);
const VALID_REVIEWER_STATUSES = new Set(["pending", "approved", "needs_review", "rejected"]);
// fee_visibility is a valid rule_family used by the pricing rule, not in RULE_FAMILIES const
const ALL_VALID_FAMILIES = new Set([...RULE_FAMILIES, "fee_visibility"]);

function validateContract(v: RuleViolation, ctx: string): void {
  check(v.snippet.trim().length > 0, `${ctx}: snippet non-empty`, v.snippet.trim().length === 0 ? "(empty snippet — evidence missing)" : undefined);
  check(v.source_url.trim().length > 0, `${ctx}: source_url non-empty`);
  check(ALL_VALID_FAMILIES.has(v.rule_family), `${ctx}: rule_family valid`, ALL_VALID_FAMILIES.has(v.rule_family) ? undefined : `got "${v.rule_family}"`);
  check(VALID_SEVERITIES.has(v.severity), `${ctx}: severity valid`, VALID_SEVERITIES.has(v.severity) ? undefined : `got "${v.severity}"`);
  check(VALID_CONFIDENCES.has(v.confidence), `${ctx}: confidence valid`, VALID_CONFIDENCES.has(v.confidence) ? undefined : `got "${v.confidence}"`);
  check(VALID_RESULTS.has(v.result), `${ctx}: result valid`, VALID_RESULTS.has(v.result) ? undefined : `got "${v.result}"`);
  check(VALID_REVIEWER_STATUSES.has(v.reviewer_status), `${ctx}: reviewer_status valid`, VALID_REVIEWER_STATUSES.has(v.reviewer_status) ? undefined : `got "${v.reviewer_status}"`);
  check(v.description.trim().length > 0, `${ctx}: description non-empty`);
}

// ---------------------------------------------------------------------------
// Eval suites
// ---------------------------------------------------------------------------

function runExtractionPrecision(ex: GoldenExample): void {
  const normalized = normalizeSourcePage(ex.page);
  const exp = ex.expected.extraction;

  check(
    exp.has_listing ? normalized.listing !== null : normalized.listing === null,
    `[${ex.id}] listing ${exp.has_listing ? "present" : "absent"}`,
    !exp.has_listing && normalized.listing !== null ? "expected null" :
    exp.has_listing && normalized.listing === null ? "expected non-null" : undefined,
  );

  check(
    normalized.pricing_observations.length === exp.pricing_observation_count,
    `[${ex.id}] pricing_observations = ${exp.pricing_observation_count}`,
    normalized.pricing_observations.length !== exp.pricing_observation_count
      ? `got ${normalized.pricing_observations.length}` : undefined,
  );

  check(
    normalized.policy_observations.length === exp.policy_observation_count,
    `[${ex.id}] policy_observations = ${exp.policy_observation_count}`,
    normalized.policy_observations.length !== exp.policy_observation_count
      ? `got ${normalized.policy_observations.length}` : undefined,
  );

  check(
    exp.has_schema_observation ? normalized.schema_observation !== null : normalized.schema_observation === null,
    `[${ex.id}] schema_observation ${exp.has_schema_observation ? "present" : "null"}`,
  );

  // Gap types: every expected gap must be present
  for (const gapType of exp.content_gap_types) {
    const found = normalized.content_gaps.some((g) => g.gap_type === gapType);
    check(found, `[${ex.id}] content_gap: ${gapType}`);
  }

  // No unexpected gaps
  for (const gap of normalized.content_gaps) {
    const expected = exp.content_gap_types.includes(gap.gap_type);
    check(expected, `[${ex.id}] no unexpected gap: ${gap.gap_type}`, expected ? undefined : "not in expected list");
  }
}

function runRulePrecision(ex: GoldenExample): void {
  const normalized = normalizeSourcePage(ex.page);
  const context = {
    run_id: "eval-run",
    domain_id: ex.page.domain_id,
    page: ex.page,
    normalized,
    screenshot_ref: null,
  };

  const ruleResults = evaluateAllRules(context);
  const allViolations = collectViolations(ruleResults);

  // Check expected violations are present
  for (const expected of ex.expected.violations) {
    const matching = allViolations.filter(
      (v) => v.rule_family === expected.rule_family && v.result === expected.result,
    );
    const minCount = expected.min_count ?? 1;
    check(
      matching.length >= minCount,
      `[${ex.id}] ${expected.rule_family} → ${expected.result}`,
      matching.length < minCount ? `got ${matching.length}, need ≥${minCount}` : undefined,
    );
  }

  // Check "passes" families produce zero violations
  for (const family of ex.expected.passes) {
    const violations = allViolations.filter((v) => v.rule_family === family);
    check(
      violations.length === 0,
      `[${ex.id}] ${family} → pass (no violations)`,
      violations.length > 0 ? `got ${violations.length} violation(s): ${violations.map((v) => v.result).join(", ")}` : undefined,
    );
  }
}

function runEvidenceCoverage(ex: GoldenExample): void {
  const normalized = normalizeSourcePage(ex.page);
  const context = {
    run_id: "eval-run",
    domain_id: ex.page.domain_id,
    page: ex.page,
    normalized,
    screenshot_ref: null,
  };

  const allViolations = collectViolations(evaluateAllRules(context));

  if (allViolations.length === 0) {
    check(true, `[${ex.id}] evidence coverage — no violations emitted`);
    return;
  }

  for (const v of allViolations) {
    const ctx = `[${ex.id}] ${v.rule_family}`;
    validateContract(v, ctx);
  }
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

console.log(BOLD("\n=== CompliCore Evaluation Harness ===\n"));
console.log(`${ALL_GOLDEN_EXAMPLES.length} golden examples · 3 eval suites\n`);

console.log(BOLD("── Extraction Precision ──────────────────────────"));
for (const ex of ALL_GOLDEN_EXAMPLES) runExtractionPrecision(ex);

console.log(BOLD("\n── Rule Precision ────────────────────────────────"));
for (const ex of ALL_GOLDEN_EXAMPLES) runRulePrecision(ex);

console.log(BOLD("\n── Evidence Coverage + Output Contract ───────────"));
for (const ex of ALL_GOLDEN_EXAMPLES) runEvidenceCoverage(ex);

// ---------------------------------------------------------------------------
// Summary
// ---------------------------------------------------------------------------

const passed = results.filter((r) => r.pass).length;
const failed = results.filter((r) => !r.pass).length;
const total  = results.length;

console.log(BOLD("\n── Summary ───────────────────────────────────────"));
console.log(`  Total:  ${total}`);
console.log(`  ${GREEN("Passed")}: ${passed}`);
if (failed > 0) {
  console.log(`  ${RED("Failed")}: ${failed}`);
  console.log("\nFailed checks:");
  for (const r of results.filter((r) => !r.pass)) {
    console.log(`  ${RED("✗")} ${r.label}${r.detail ? DIM(" — " + r.detail) : ""}`);
  }
}
console.log();

if (failed > 0) process.exit(1);
