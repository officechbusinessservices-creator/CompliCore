/**
 * Weekly brief reproducibility check.
 *
 * Runs the mock pipeline end-to-end and verifies that the output artifacts
 * are structurally correct and deterministic across runs.
 *
 * What is checked:
 *   - exports/findings.json exists and has the expected count
 *   - exports/targets.json exists and contains the expected domains + tiers
 *   - reports/weekly_brief.md exists and contains all required structural sections
 *   - Every finding has non-empty source_url and snippet (evidence completeness)
 *   - Finding count in brief text matches findings.json length
 *   - No finding is missing its rule_family or description
 *
 * Run: pnpm --filter @complicore/tests repro
 *
 * Exit 0: all checks pass
 * Exit 1: one or more checks failed (details printed to stdout)
 */

import { mkdtempSync, rmSync, readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { tmpdir } from "node:os";
import { fileURLToPath } from "node:url";
import { runPipeline } from "../../apps/worker/src/pipeline.js";
import { createMockClient } from "../../apps/worker/src/mock-client.js";

const __dirname = dirname(fileURLToPath(import.meta.url));

// ---------------------------------------------------------------------------
// ANSI helpers
// ---------------------------------------------------------------------------

const GREEN = (s: string) => `\x1b[32m${s}\x1b[0m`;
const RED   = (s: string) => `\x1b[31m${s}\x1b[0m`;
const DIM   = (s: string) => `\x1b[2m${s}\x1b[0m`;
const BOLD  = (s: string) => `\x1b[1m${s}\x1b[0m`;

// ---------------------------------------------------------------------------
// Result tracking
// ---------------------------------------------------------------------------

interface CheckResult {
  pass: boolean;
  label: string;
  detail?: string;
}

const results: CheckResult[] = [];

function check(pass: boolean, label: string, detail?: string): void {
  results.push({ pass, label, detail });
  const icon = pass ? GREEN("✓") : RED("✗");
  console.log(`  ${icon} ${label}${detail ? DIM(" — " + detail) : ""}`);
}

// ---------------------------------------------------------------------------
// Known-good structural expectations from the mock dataset
// These numbers come from the 3 deterministic mock domains.
// ---------------------------------------------------------------------------

const EXPECTED = {
  domainCount: 3,
  domains: ["capitalcityliving.com", "sixthstreetsuites.com", "austinstays.com"],
  findingCount: 21,
  targetCount: 3,
  highTierDomains: ["sixthstreetsuites.com", "capitalcityliving.com"],
  requiredBriefSections: [
    "## Headline Metrics",
    "## Market Intelligence",
    "## Compliance Findings",
    "## Acquisition Targets",
  ],
} as const;

// ---------------------------------------------------------------------------
// Run
// ---------------------------------------------------------------------------

console.log(BOLD("\n=== Weekly Brief Reproducibility Check ===\n"));
console.log("Running mock pipeline in temp directory...\n");

const tmpOut = mkdtempSync(join(tmpdir(), "complicore-repro-"));

try {
  await runPipeline(createMockClient(), {
    metro: "Austin, TX",
    operatorDomain: "mycompany.com",
    outputDir: tmpOut,
    maxUrlsPerDomain: 5,
  });
} catch (err) {
  console.error(RED("Pipeline threw an error:"), err);
  process.exit(1);
}

// ---------------------------------------------------------------------------
// Load artifacts
// ---------------------------------------------------------------------------

const findingsPath = join(tmpOut, "exports", "findings.json");
const targetsPath  = join(tmpOut, "exports", "targets.json");
const briefPath    = join(tmpOut, "reports", "weekly_brief.md");

let findings: unknown[];
let targets: unknown[];
let briefText: string;

try {
  findings = JSON.parse(readFileSync(findingsPath, "utf8")) as unknown[];
  targets  = JSON.parse(readFileSync(targetsPath, "utf8")) as unknown[];
  briefText = readFileSync(briefPath, "utf8");
} catch (err) {
  console.error(RED("Failed to read artifacts:"), err);
  process.exit(1);
}

// ---------------------------------------------------------------------------
// Artifact existence
// ---------------------------------------------------------------------------

console.log(BOLD("── Artifact Files ────────────────────────────────"));
check(Array.isArray(findings), "exports/findings.json exists and is array");
check(Array.isArray(targets),  "exports/targets.json exists and is array");
check(briefText.length > 100,  "reports/weekly_brief.md exists and is non-trivial");

// ---------------------------------------------------------------------------
// Finding counts
// ---------------------------------------------------------------------------

console.log(BOLD("\n── Finding Counts ────────────────────────────────"));
check(
  findings.length === EXPECTED.findingCount,
  `findings count = ${EXPECTED.findingCount}`,
  findings.length !== EXPECTED.findingCount ? `got ${findings.length}` : undefined,
);
check(
  targets.length === EXPECTED.targetCount,
  `targets count = ${EXPECTED.targetCount}`,
  targets.length !== EXPECTED.targetCount ? `got ${targets.length}` : undefined,
);

// ---------------------------------------------------------------------------
// Evidence completeness (every finding must have source_url + snippet)
// ---------------------------------------------------------------------------

console.log(BOLD("\n── Evidence Completeness ─────────────────────────"));

type FindingRecord = {
  source_url?: string;
  snippet?: string;
  rule_family?: string;
  description?: string;
  id?: string;
};

let evidenceFails = 0;
for (const f of findings) {
  const finding = f as FindingRecord;
  const id = finding.id ?? "unknown";
  if (!finding.source_url || finding.source_url.trim().length === 0) {
    check(false, `finding ${id}: source_url non-empty`, "MISSING — evidence contract violated");
    evidenceFails++;
  }
  if (!finding.snippet || finding.snippet.trim().length === 0) {
    check(false, `finding ${id}: snippet non-empty`, "MISSING — evidence contract violated");
    evidenceFails++;
  }
  if (!finding.rule_family || finding.rule_family.trim().length === 0) {
    check(false, `finding ${id}: rule_family non-empty`, "MISSING");
    evidenceFails++;
  }
  if (!finding.description || finding.description.trim().length === 0) {
    check(false, `finding ${id}: description non-empty`, "MISSING");
    evidenceFails++;
  }
}
if (evidenceFails === 0) {
  check(true, `all ${findings.length} findings pass evidence contract`);
}

// ---------------------------------------------------------------------------
// Target domain + tier checks
// ---------------------------------------------------------------------------

console.log(BOLD("\n── Target Tiers ──────────────────────────────────"));

type TargetRecord = { domain?: string; tier?: string; score?: number };

const targetsByDomain = new Map<string, TargetRecord>();
for (const t of targets) {
  const target = t as TargetRecord;
  if (target.domain) targetsByDomain.set(target.domain, target);
}

for (const domain of EXPECTED.domains) {
  check(
    targetsByDomain.has(domain),
    `target present: ${domain}`,
    targetsByDomain.has(domain) ? undefined : "domain missing from targets.json",
  );
}

for (const domain of EXPECTED.highTierDomains) {
  const t = targetsByDomain.get(domain);
  check(
    t?.tier === "HIGH",
    `${domain} tier = HIGH`,
    t?.tier !== "HIGH" ? `got ${t?.tier ?? "missing"}` : undefined,
  );
}

// ---------------------------------------------------------------------------
// Brief structure
// ---------------------------------------------------------------------------

console.log(BOLD("\n── Brief Structure ───────────────────────────────"));

for (const section of EXPECTED.requiredBriefSections) {
  check(
    briefText.includes(section),
    `brief contains section: ${section}`,
    !briefText.includes(section) ? "section header missing" : undefined,
  );
}

// Brief finding count matches findings.json
const briefFindingCountMatch = briefText.match(/Compliance findings \| (\d+)/);
const briefFindingCount = briefFindingCountMatch ? parseInt(briefFindingCountMatch[1] ?? "0", 10) : null;
check(
  briefFindingCount === findings.length,
  `brief finding count (${briefFindingCount}) matches findings.json (${findings.length})`,
  briefFindingCount !== findings.length ? `brief says ${briefFindingCount}, json has ${findings.length}` : undefined,
);

// Brief is marked as draft
check(
  briefText.includes("draft") || briefText.includes("pending reviewer"),
  "brief is marked as draft / pending reviewer",
);

// ---------------------------------------------------------------------------
// Cleanup + summary
// ---------------------------------------------------------------------------

rmSync(tmpOut, { recursive: true, force: true });

const passed = results.filter((r) => r.pass).length;
const failed = results.filter((r) => !r.pass).length;
const total  = results.length;

console.log(BOLD("\n── Summary ───────────────────────────────────────"));
console.log(`  Total:  ${total}`);
console.log(`  ${GREEN("Passed")}: ${passed}`);
if (failed > 0) {
  console.log(`  ${RED("Failed")}: ${failed}`);
  console.log("\nFailed checks:");
  for (const r of results.filter((r) => !r.pass)) {
    console.log(`  ${RED("✗")} ${r.label}${r.detail ? DIM(" — " + r.detail) : ""}`);
  }
}
console.log();

if (failed > 0) process.exit(1);
