#!/usr/bin/env bash
# pre_commit.sh — secret scan + import check on staged files
#
# Usage (git hook):   ln -sf ../../.claude/hooks/pre_commit.sh .git/hooks/pre-commit
# Usage (manual):     bash .claude/hooks/pre_commit.sh
#
# Exit 0: clean | Exit 1: issues found (blocks commit)

set -euo pipefail

ERRORS=0

# ── Staged TypeScript/JavaScript files ──────────────────────────────────────
STAGED=$(git diff --cached --name-only --diff-filter=ACM 2>/dev/null | grep -E '\.(ts|tsx|js|mjs|cjs)$' || true)
ENV_STAGED=$(git diff --cached --name-only --diff-filter=ACM 2>/dev/null | grep -E '^\.env' | grep -v '\.env\.example$' || true)

# 1. Block staging .env files
if [ -n "$ENV_STAGED" ]; then
  echo "ERROR: Staged .env file(s) detected:" >&2
  echo "$ENV_STAGED" >&2
  echo "Remove from staging: git reset HEAD <file>" >&2
  ERRORS=$((ERRORS + 1))
fi

# 2. Secret pattern scan on all staged content
SECRET_PATTERNS=(
  "sk-[a-zA-Z0-9]{20,}"               # OpenAI/Anthropic style keys
  "AKIA[0-9A-Z]{16}"                   # AWS access key IDs
  "ghp_[a-zA-Z0-9]{36}"               # GitHub personal access tokens
  "xoxb-[0-9]+-[a-zA-Z0-9]+"          # Slack bot tokens
  "-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY" # Private keys
  "password[[:space:]]*=[[:space:]]*['\"][^'\"]{6,}" # Hardcoded passwords
  "api_key[[:space:]]*=[[:space:]]*['\"][^'\"]{8,}"  # Generic API keys
  "secret[[:space:]]*=[[:space:]]*['\"][^'\"]{8,}"   # Generic secrets
)

for file in $STAGED $ENV_STAGED; do
  [ -f "$file" ] || continue
  CONTENT=$(git show ":$file" 2>/dev/null) || continue
  for pattern in "${SECRET_PATTERNS[@]}"; do
    if echo "$CONTENT" | grep -qiE "$pattern"; then
      echo "ERROR: Possible secret in $file (pattern: $pattern)" >&2
      ERRORS=$((ERRORS + 1))
    fi
  done
done

# 3. Broken relative import check (import from '../nonexistent')
for file in $STAGED; do
  [ -f "$file" ] || continue
  DIR=$(dirname "$file")
  # Extract relative import paths
  IMPORTS=$(git show ":$file" 2>/dev/null | grep -oE "from ['\"](\./|\.\./)([^'\"]+)['\"]" | grep -oE "(\./|\.\./)[^'\"]*" || true)
  for imp in $IMPORTS; do
    # Strip potential extension
    TARGET_BASE="$DIR/$imp"
    # Check with common extensions
    FOUND=false
    for ext in "" ".ts" ".tsx" "/index.ts" "/index.tsx"; do
      if [ -e "${TARGET_BASE}${ext}" ]; then
        FOUND=true
        break
      fi
    done
    if [ "$FOUND" = false ]; then
      echo "WARNING: Possibly broken import in $file: $imp" >&2
    fi
  done
done

if [ "$ERRORS" -gt 0 ]; then
  echo "" >&2
  echo "pre_commit: $ERRORS error(s) found. Commit blocked." >&2
  exit 1
fi

echo "pre_commit: clean."
exit 0
