#!/usr/bin/env bash
# PostToolUse hook — typecheck changed TypeScript files after Write/Edit
# Exit code does not block (tool already ran). Output is surfaced to Claude.
#
# Receives Claude Code tool JSON on stdin:
# { "tool_name": "Write", "tool_input": { "file_path": "..." } }

set -uo pipefail

INPUT=$(cat)

TOOL=$(echo "$INPUT" | python3 -c "import sys,json; print(json.load(sys.stdin).get('tool_name',''))" 2>/dev/null) || TOOL=""
FILE=$(echo "$INPUT" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('tool_input',{}).get('file_path',''))" 2>/dev/null) || FILE=""

# Only act on Write/Edit/MultiEdit to TypeScript files
if [[ "$TOOL" != "Write" && "$TOOL" != "Edit" && "$TOOL" != "MultiEdit" ]]; then
  exit 0
fi

if [[ "$FILE" != *.ts && "$FILE" != *.tsx ]]; then
  exit 0
fi

# Resolve which package owns this file
REPO_ROOT="$(git -C "$(dirname "$FILE")" rev-parse --show-toplevel 2>/dev/null)" || exit 0
RELATIVE="${FILE#$REPO_ROOT/}"

# Map file path prefix to package directory
PKG_DIR=""
for pkg in packages/core packages/firecrawl packages/rules packages/web packages/worker; do
  if [[ "$RELATIVE" == "$pkg/"* ]]; then
    PKG_DIR="$REPO_ROOT/$pkg"
    break
  fi
done

if [ -z "$PKG_DIR" ]; then
  exit 0
fi

# Skip if no tsconfig in package
if [ ! -f "$PKG_DIR/tsconfig.json" ]; then
  exit 0
fi

echo "POST_TOOL_USE: typechecking $PKG_DIR after edit to $RELATIVE"

cd "$PKG_DIR"
if ! npx tsc --noEmit --pretty false 2>&1 | head -30; then
  echo "TYPECHECK FAILED in $PKG_DIR — review errors above before continuing." >&2
fi

exit 0
