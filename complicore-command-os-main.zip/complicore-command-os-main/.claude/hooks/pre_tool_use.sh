#!/usr/bin/env bash
# PreToolUse hook — blocks destructive shell commands
# Exit 0: allow | Exit 2: block (stderr surfaced to Claude)
#
# Receives Claude Code tool JSON on stdin:
# { "tool_name": "Bash", "tool_input": { "command": "..." } }

set -euo pipefail

INPUT=$(cat)

TOOL=$(python3 -c "
import sys, json
d = json.loads('''$INPUT'''.replace(\"'''\", ''))
print(d.get('tool_name', ''))
" 2>/dev/null) || TOOL=$(echo "$INPUT" | python3 -c "import sys,json; print(json.load(sys.stdin).get('tool_name',''))" 2>/dev/null) || TOOL=""

if [ "$TOOL" != "Bash" ]; then
  exit 0
fi

CMD=$(echo "$INPUT" | python3 -c "
import sys, json
d = json.load(sys.stdin)
print(d.get('tool_input', {}).get('command', ''))
" 2>/dev/null) || CMD=""

# --- Destructive pattern blocklist ---
# Each entry is a regex matched case-insensitively against the command string.
PATTERNS=(
  "rm[[:space:]]+-[^[:space:]]*r"   # rm -r, rm -rf, rm -Rf, etc.
  "git[[:space:]]+push[[:space:]]+.*-f"  # git push --force / -f
  "git[[:space:]]+reset[[:space:]]+--hard"
  "git[[:space:]]+clean[[:space:]]+-[a-z]*f"  # git clean -f, -fd, -fdx
  "git[[:space:]]+branch[[:space:]]+-D"
  "DROP[[:space:]]+(TABLE|DATABASE|SCHEMA)"
  "TRUNCATE[[:space:]]+TABLE"
  "chmod[[:space:]]+-R[[:space:]]+777"
  ":[[:space:]]*>[[:space:]]*[^/]"  # truncate-by-redirect e.g. > file
)

for pattern in "${PATTERNS[@]}"; do
  if echo "$CMD" | grep -qiE "$pattern"; then
    echo "BLOCKED by pre_tool_use: destructive pattern matched: $pattern" >&2
    echo "Command: $CMD" >&2
    echo "Confirm this action manually before proceeding." >&2
    exit 2
  fi
done

# --- .env read guard (belt-and-suspenders over settings.json deny) ---
if echo "$CMD" | grep -qE "(cat|head|tail|less|more)[[:space:]]+.*\.env"; then
  echo "BLOCKED by pre_tool_use: direct shell read of .env file." >&2
  exit 2
fi

exit 0
