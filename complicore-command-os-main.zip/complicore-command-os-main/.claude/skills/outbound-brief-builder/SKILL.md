---
name: outbound-brief-builder
description: Build a reviewer-ready outbound brief for a single acquisition target. Every claim must cite a finding or gap record. No speculation.
type: output
version: 1
---

# Outbound Brief Builder

## Purpose
Produce a structured outbound brief for a single HIGH or MODERATE acquisition target. The brief is contact-ready but must be reviewed and approved before use. It is grounded in the domain's compliance findings and gap profile — not market assumptions.

## When to Use
- After `lead-scoring` returns HIGH or MODERATE for a domain.
- When a reviewer has approved the underlying findings.
- Only on targets where `opportunity_target.reviewer_status` is "pending" or "approved" — never on "needs_review" or "rejected".

## Required Inputs
- `domain`, `domain_id`, `run_id`, `metro`
- `lead_score` — output of `lead-scoring` (score, tier, top_signals, recommendation)
- `account_profile` — output of `account-research`
- `approved_findings` — ComplianceFinding records with `reviewer_status: "approved"`
- `operator_context` — operator name, differentiators (provided by caller)

## Steps
1. Select the top 2–3 findings most relevant to an acquisition conversation (prefer high severity, strong evidence).
2. Write an opening that states the signal, not the conclusion.
3. Connect each signal to an operator differentiator — only if the operator_context supports it.
4. Close with a single specific next step.
5. Each paragraph cites the finding_id that supports it.

## Output Contract
```
## Outbound Brief — [domain] — Run [run_id]
Status: DRAFT — requires reviewer approval before use

### Signal Summary
Target: [domain]
Score: [n]/100 ([tier])
Top signals: [list]

### Brief

[Opening — 2 sentences. States what the signals show. No value judgment.]
[Citation: finding_id: ...]

[Body — 1–2 sentences. Connects operator's differentiator to the gap, if supported by operator_context.]
[Citation: finding_id: ...]

[Close — 1 sentence. Specific next step.]

### Reviewer Notes
- Findings used: [list of finding_ids]
- Any finding with confidence < "high": [flag or "none"]
- Any finding pending review: [flag or "none"]
```

## Forbidden Behavior
- Do not speculate about the target's intent, financial position, or reasons for the gaps.
- Do not use urgency language ("act now", "limited time").
- Do not claim the operator is "better" without citing a specific finding that supports it.
- Do not produce a brief for a LOW-scored target.
- Do not include findings with `reviewer_status: "rejected"` or `"needs_review"`.
- Do not produce this output if `approved_findings` is empty — return: "No approved findings for [domain]. Brief cannot be produced without reviewer-approved evidence."

## Confidence Handling
- If all top signals are medium confidence, mark the brief `[MEDIUM CONFIDENCE — reviewer must verify before use]`.
- If any finding used has no screenshot_ref, note: "Screenshot unavailable for [finding_id] — visual verification recommended."
