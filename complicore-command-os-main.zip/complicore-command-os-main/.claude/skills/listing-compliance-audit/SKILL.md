---
name: listing-compliance-audit
description: Audit listing_detail pages against all 8 rule families. Produces a per-listing findings report with evidence required for each violation.
type: analysis
version: 1
---

# Listing Compliance Audit

## Purpose
Apply all 8 rule families to a specific listing page and produce an audit report. Every finding must cite the source_page_id, verbatim snippet, and rule family that produced it.

## When to Use
- After rules engine has run for a page.
- When a reviewer wants a full audit of a single listing before approving findings.
- To verify a specific page before it appears in the weekly brief.

## Required Inputs
- `source_page_id`
- `url`
- `domain`
- `findings` — ComplianceFinding records for this page
- `normalized` — NormalizedPageData for this page
- `screenshot_ref` (optional)

## Steps
1. For each of the 8 rule families, report the result: pass / fail / uncertain_needs_review / not_applicable.
2. For each violation, show: rule, result, severity, snippet, source URL.
3. Compute a page-level compliance score: `(passing_families / applicable_families) × 100`.
4. List all content gaps detected on this page.

## Output Contract
```
## Listing Compliance Audit
URL: [url]
Domain: [domain]
Source Page ID: [source_page_id]
Compliance Score: [n]% ([passing]/[applicable] rule families)

### Rule Family Results
| Rule Family | Result | Severity | Finding |
|-------------|--------|----------|---------|
| pricing_transparency | ... | ... | [snippet, max 120 chars] |
| fee_visibility       | ...
| policy_coherence     | ...
| privacy_presence     | N/A (not homepage) |
| disclosure_signals   | ...
| contact_path_completeness | ...
| schema_quality       | ...
| trust_signals        | N/A (not homepage) |

### Content Gaps
- [gap_type]: [description]

### Reviewer Actions Required
- [list only findings with reviewer_status: "needs_review"]
```

## Forbidden Behavior
- Do not compute a compliance score if fewer than 3 rule families are applicable.
- Do not mark a rule "pass" if its findings array is empty due to a skip — use "N/A" with the skip reason.
- Do not include findings with `reviewer_status: "rejected"`.
- Do not fabricate snippets. If a finding has no snippet, output `[snippet missing — finding blocked from publication]`.

## Confidence Handling
- Low-confidence findings are included but marked `[LOW CONFIDENCE]` in the Finding column.
- If screenshot_ref is null, note at the top: "No screenshot available for this page."
- Compliance score is labeled `PROVISIONAL` if any applicable rule family result is uncertain_needs_review.
