---
name: weekly-command-brief
description: Assemble the weekly executive brief from approved run outputs. Every section must cite finding or target IDs. Report cannot be exported until all sections pass reviewer gate.
type: output
version: 1
---

# Weekly Command Brief

## Purpose
Assemble the weekly executive brief for one metro from a completed, reviewer-approved run. This is the primary operator-facing output. It must be factual, cited, and actionable. No section may include a paragraph without a citation.

## When to Use
- After a run completes and findings have been through the reviewer workflow.
- After `competitor-gap-scan`, `business-vs-competitors`, and `lead-scoring` have run.
- Only when `report.status` is "draft" — the brief is assembled here and submitted for final approval.

## Required Inputs
- `run_id`, `metro`, `week_ending` (ISO date)
- `approved_findings` — ComplianceFinding records with `reviewer_status: "approved"`
- `opportunity_targets` — OpportunityTarget records (approved or pending)
- `growth_gaps` — output of `business-vs-competitors` (approved)
- `domains_monitored` — count of domains in this run

## Sections to Produce (in order)
1. **Headline Metrics** — counts only, no prose
2. **Market Intelligence** — competitor pricing and positioning signals
3. **Compliance Findings** — top 3 high-severity findings with evidence
4. **Growth Gaps** — top 2 market-level opportunities
5. **Acquisition Targets** — HIGH-tier targets only, with scores and top signals

## Output Contract
```
## Weekly Command Brief — [metro] — Week Ending [week_ending]
Run: [run_id] | Status: DRAFT

### Headline Metrics
- Domains monitored: [n]
- Compliance findings this week: [n] ([n] high, [n] medium)
- Acquisition targets identified: [n] ([n] HIGH signal)
- Growth gaps identified: [n]

### Market Intelligence
[1–2 paragraphs. Each sentence cites a finding_id or source_page_id.]

### Compliance Findings
**Top Findings This Week**
| # | Domain | Rule | Severity | Finding | Source |
|---|--------|------|----------|---------|--------|
| 1 | ...    | ...  | HIGH     | [snippet ≤80 chars] | [URL] |

### Growth Gaps
1. [rule_family] — [operator_differentiation_opportunity]
   Competitors failing: [n] | Signal: [strong/moderate/weak]

2. ...

### Acquisition Targets (HIGH signal only)
| Domain | Score | Top Signals | Recommendation |
|--------|-------|------------|----------------|
| ...    | ...   | ...        | ...            |

---
All findings cited above require reviewer approval before this brief is exported.
Paragraphs with no citation: [n — must be 0 for export]
```

## Forbidden Behavior
- Do not include paragraphs with empty `citation_ids`.
- Do not include MODERATE or LOW acquisition targets in the main brief.
- Do not include findings with `reviewer_status: "needs_review"` or "rejected".
- Do not export the brief if `report.status` is not "approved".
- Do not produce the brief if `approved_findings` is empty — return: "No approved findings for run [run_id]. Brief requires at least one approved finding."
- Do not use superlatives or market predictions.

## Confidence Handling
- If any finding in the Compliance section has `confidence: "medium"`, append `[MEDIUM CONFIDENCE]` to that row.
- If fewer than 3 domains were monitored, add a data note: "Limited competitive sample this week — [n] domains. Findings reflect available data only."
- If a growth gap has `market_gap_signal: "weak"`, mark it `[SINGLE COMPETITOR SIGNAL — verify before acting]`.
