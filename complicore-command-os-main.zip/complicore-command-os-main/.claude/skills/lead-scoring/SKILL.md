---
name: lead-scoring
description: Score acquisition targets using the OpportunityTarget scoring model. Requires an account profile from account-research. Produces a scored and tiered target record.
type: analysis
version: 1
---

# Lead Scoring

## Purpose
Apply the OpportunityTarget scoring model to a domain profile and produce a scored, tiered acquisition signal. Every score component must trace to a specific finding or gap record.

## When to Use
- After `account-research` has produced a domain profile.
- When the growth-analyst agent or a reviewer needs to rank targets for the weekly brief.

## Required Inputs
- `domain`
- `domain_id`
- `run_id`
- `account_profile` — output of `account-research` for this domain
- `findings` — ComplianceFinding records for this domain (approved or pending only)
- `content_gaps` — ContentGap records for this domain
- `total_pages_scraped` — integer

## Scoring Model
Apply exactly this model. Do not modify weights.

| Component | Max Points | Condition |
|-----------|-----------|-----------|
| compliance_failure_density | 30 | (high findings / total pages) × 30 |
| content_gap_density | 20 | (gaps / total pages) × 20 |
| pricing_opacity_flag | 20 | +20 if pricing_transparency FAIL exists |
| policy_absence_flag | 15 | +15 if no cancellation or privacy policy found |
| schema_quality_fail | 15 | +15 if schema_quality FAIL exists |
| **Total** | **100** | |

Tier thresholds: HIGH = 70–100, MODERATE = 40–69, LOW = 0–39.

## Steps
1. Compute each component. Show the arithmetic.
2. Sum components. Clamp to [0, 100].
3. Assign tier.
4. List the top 3 signals that contributed most to the score.
5. Write a one-sentence recommendation — what the web signals show, nothing more.

## Output Contract
```
## Lead Score — [domain] — Run [run_id]

Score: [n]/100 — [HIGH / MODERATE / LOW]

### Score Breakdown
| Component | Points | Basis |
|-----------|--------|-------|
| compliance_failure_density | [n] | [n] high findings / [n] pages × 30 |
| content_gap_density | [n] | [n] gaps / [n] pages × 20 |
| pricing_opacity_flag | [n] | pricing_transparency FAIL: [yes/no] |
| policy_absence_flag | [n] | cancellation policy: [present/absent], privacy: [present/absent] |
| schema_quality_fail | [n] | schema_quality FAIL: [yes/no] |

### Top Signals
1. ...
2. ...
3. ...

### Recommendation
[One sentence. No speculation about owner intent or financial state.]

### Contributing Record IDs
- Findings: [list of finding_ids used]
- Gaps: [list of gap_ids used]
```

## Forbidden Behavior
- Do not deviate from the scoring model weights.
- Do not speculate about distress, motivation, or ownership.
- Do not include findings with `reviewer_status: "rejected"` in density calculations.
- Do not score a domain with fewer than 2 scraped pages.
- Do not produce a HIGH tier score without at least 2 contributing components above 0.

## Confidence Handling
- If total_pages_scraped < 5, label score `[LIMITED SAMPLE — [n] pages]` and note the density metrics may overstate.
- If any contributing finding has `confidence: "low"`, note: "Score includes low-confidence signals — subject to reviewer approval."
