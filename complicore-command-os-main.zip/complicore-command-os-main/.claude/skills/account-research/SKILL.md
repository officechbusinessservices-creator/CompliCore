---
name: account-research
description: Research a single competitor domain using findings and observations from a completed run. Produces a domain profile ready for lead scoring or outbound brief building.
type: analysis
version: 1
---

# Account Research

## Purpose
Produce a structured profile of a single competitor domain from pipeline data. The profile is the input to `lead-scoring` and `outbound-brief-builder`. It must contain only verifiable signals from the current run.

## When to Use
- After a run completes and a domain has been flagged as an acquisition candidate or outreach target.
- Before running `lead-scoring` or `outbound-brief-builder` on a domain.

## Required Inputs
- `domain`
- `domain_id`
- `run_id`
- `source_pages` — all SourcePage records for this domain in the run
- `normalized_data` — NormalizedPageData for all pages
- `findings` — ComplianceFinding records for this domain
- `content_gaps` — ContentGap records for this domain

## Steps
1. Count total pages scraped, pages with pricing, pages with policies.
2. List all ComplianceFinding records by severity. Note finding count per rule family.
3. List all ContentGap records by type.
4. Extract pricing range: min and max price_numeric across all PricingObservations.
5. List policy types present (cancellation, refund, lease, house_rules).
6. Note homepage schema quality (has_structured_data, schema_types_found).
7. Note whether a contact path was found.

## Output Contract
```
## Account Profile — [domain] — Run [run_id]

### Coverage
- Pages scraped: [n]
- Pages with pricing: [n]
- Pages with policies: [n]

### Pricing Range
- Min: $[n]/[unit] — Max: $[n]/[unit]
- Fee disclosure: [present / absent]
- Total cost shown: [yes / no]

### Policy Coverage
- [policy_type]: [present / absent]

### Compliance Findings
| Rule Family | Severity | Finding (snippet, max 100 chars) |
|-------------|----------|----------------------------------|
| ...

### Content Gaps
- [gap_type]: [description]

### Schema
- Structured data: [yes / no]
- Types found: [list or "none"]

### Contact Path
- [present / absent]
```

## Forbidden Behavior
- Do not include data from prior runs — this profile reflects one run only.
- Do not infer business size, revenue, or ownership from web signals.
- Do not include findings with `reviewer_status: "rejected"`.
- Do not produce a profile if the domain has fewer than 2 scraped pages — return: "Insufficient page coverage for [domain]. Minimum 2 pages required."

## Confidence Handling
- If `http_status` is not 200 for any page, note it: "[n] pages returned non-200 status — data may be incomplete."
- Pricing range labeled `PROVISIONAL` if any price_unit is "unknown".
- Findings with `confidence: "low"` included but marked `[LOW CONFIDENCE]`.
