---
name: competitor-gap-scan
description: Scan a set of competitor domains for compliance gaps and content weaknesses using normalized observation data from a completed pipeline run.
type: analysis
version: 1
---

# Competitor Gap Scan

## Purpose
Identify compliance gaps and content weaknesses across competitor domains in a single metro. Output is a ranked gap table with evidence — not a summary, not an opinion.

## When to Use
- After a pipeline run has completed and NormalizedPageData records exist in the DB.
- When the operator wants to know where competitors are weakest before publishing a brief.
- As input to `business-vs-competitors` or `outbound-brief-builder`.

Do not use this skill on raw scraped HTML. Only run against normalized observations.

## Required Inputs
- `run_id` — the completed run to analyze
- `metro` — city and state (e.g., "Austin, TX")
- `domains` — array of domain strings to include (exclude the operator's own domain)
- `normalized_data` — NormalizedPageData records for all pages in the run
- `compliance_findings` — ComplianceFinding records produced by the rules engine for this run

## Steps
1. Group findings by domain.
2. For each domain, count findings by rule_family and severity.
3. Rank domains by total high-severity finding count (descending).
4. For each gap, pull the verbatim snippet from the finding record — do not paraphrase.
5. Flag any domain with zero findings as "no violations detected this run" — do not mark it clean.
6. Surface the top 3 rule families with the most failures across all domains.

## Output Contract
Return a structured gap table:

```
## Competitor Gap Scan — [metro] — Run [run_id]

### Top Rule Family Failures
| Rule Family | Domains Failing | Finding Count |
|-------------|----------------|---------------|
| ...         | ...            | ...           |

### Domain Rankings (by high-severity findings)
| Rank | Domain | High | Medium | Total | Top Finding |
|------|--------|------|--------|-------|-------------|
| ...  | ...    | ...  | ...    | ...   | ...         |

### Evidence Excerpts
For each high-severity finding cited above:
- Domain: ...
- Rule: ...
- Finding: [verbatim snippet, max 200 chars]
- Source URL: ...
```

No narrative prose in the output. Tables only.

## Forbidden Behavior
- Do not summarize findings without citing their source_page_id and snippet.
- Do not infer gaps that are not in the findings data.
- Do not rank domains based on subjective assessment.
- Do not include the operator's own domain in any ranking.
- Do not produce output if no findings exist — return: "No findings found for run [run_id]. Cannot produce gap scan."

## Confidence Handling
- If a finding has `confidence: "low"`, include it in the table but append `[LOW CONFIDENCE — needs review]` to the Top Finding cell.
- If a finding has `reviewer_status: "needs_review"`, mark it `[PENDING REVIEW]` — do not treat it as confirmed.
- If fewer than 3 domains were analyzed, note at the top: "Limited sample: [n] domains. Gap rankings may not be representative of the market."
