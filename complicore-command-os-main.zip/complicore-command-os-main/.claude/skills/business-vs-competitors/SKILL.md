---
name: business-vs-competitors
description: Compare the operator's web presence against competitors on compliance, pricing transparency, content, and trust signals. Evidence-backed head-to-head analysis.
type: analysis
version: 1
---

# Business vs Competitors

## Purpose
Produce a head-to-head comparison of the operator against the competitive set. Output shows where the operator leads, where it lags, and which gaps are actionable this week.

## When to Use
- After `competitor-gap-scan` and `schema-audit` have run for the current period.
- As the growth intelligence input to `weekly-command-brief`.

## Required Inputs
- `run_id`, `metro`, `operator_domain`
- `operator_findings` — ComplianceFinding records for the operator's pages
- `competitor_findings` — ComplianceFinding records for all competitors
- `operator_normalized` — NormalizedPageData for operator pages
- `competitor_normalized` — NormalizedPageData for competitor pages

## Steps
1. Score the operator and each competitor on each rule family (0 = no violations, 1 = medium violations, 2 = high violations).
2. Build a comparison matrix.
3. Identify rule families where the operator scores better than the median competitor — these are strengths.
4. Identify rule families where the operator scores worse — these are priority gaps.
5. Produce an actionable gap list ordered by potential competitive impact.

## Output Contract
```
## Operator vs Competitors — [metro] — Run [run_id]

### Compliance Scorecard
| Rule Family | Operator | Competitor Median | Operator Position |
|-------------|----------|-------------------|-------------------|
| ...         | ...      | ...               | LEADS / LAGS / EVEN |

### Priority Gaps (operator lags)
1. [rule family] — [one sentence on what the gap means operationally]
   Evidence: [snippet from operator page] (source_page_id: ...)

### Strengths (operator leads)
1. [rule family] — [one sentence, grounded in data]
```

## Forbidden Behavior
- Do not use subjective language ("impressive", "poor", "weak").
- Do not include gaps without an evidence snippet from the operator's own pages.
- Do not compare the operator to a single competitor — use the median of the full set.
- Do not produce output with fewer than 2 competitor domains in the set.

## Confidence Handling
- If operator has fewer pages scraped than competitors, note the sample imbalance.
- Any strength or gap with only 1 supporting finding is marked `[SINGLE FINDING — verify]`.
