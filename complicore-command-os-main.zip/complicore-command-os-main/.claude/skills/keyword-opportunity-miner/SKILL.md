---
name: keyword-opportunity-miner
description: Extract keyword and topic gaps from competitor content. Identifies where competitors rank for terms the operator does not cover — based solely on scraped page content.
type: analysis
version: 1
---

# Keyword Opportunity Miner

## Purpose
Identify content and topic gaps between the operator's web presence and competitors. Output is a ranked list of topic areas where competitors have content and the operator does not — or where competitor content is weak enough to be outranked.

This is a content-presence analysis, not an SEO tool. It does not pull search volume, rankings, or external data. Every finding must be derivable from scraped `text_content` records.

## When to Use
- After the scrape and normalize steps have completed for a run.
- When the operator wants to identify content investment priorities.
- As input to `business-vs-competitors` (growth gap section).

Do not use this skill if fewer than 3 competitor domains have been scraped.

## Required Inputs
- `run_id`
- `metro`
- `operator_pages` — SourcePage records for the operator's own domain
- `competitor_pages` — SourcePage records for all competitor domains in the run
- `operator_domain` — the operator's own domain string

## Steps
1. Extract heading and section topics from each page's text_content using `##` and `###` markdown headings and bold terms.
2. Build a topic inventory per domain: list of topics covered (deduplicated).
3. For each topic present in 2+ competitor domains, check if it appears in the operator's pages.
4. If absent from the operator, flag as a topic gap.
5. Score each gap: `high` (present in 3+ competitors), `medium` (2 competitors), `low` (1 competitor).
6. Sort by score descending.

## Output Contract
```
## Keyword Opportunity Report — [metro] — Run [run_id]

### Topic Gaps (operator missing, competitors have)
| Topic | Competitors With It | Gap Score | Example Competitor |
|-------|--------------------|-----------|--------------------|
| ...   | ...                | ...       | ...                |

### Weak Coverage (operator has it, fewer competitors do)
| Topic | Operator Coverage | Competitor Coverage | Signal |
|-------|------------------|--------------------|---------|
| ...   | ...              | ...                | ...     |

### Data Notes
- Operator pages analyzed: [n]
- Competitor pages analyzed: [n] across [m] domains
```

## Forbidden Behavior
- Do not use external search data, estimated traffic, or keyword tools.
- Do not infer topics not present in the scraped text_content.
- Do not suggest the operator "target" keywords — this skill identifies gaps only.
- Do not include blog_content or gated_dynamic pages in topic extraction.
- Do not produce output if `operator_pages` is empty — return: "No operator pages found. Cannot compute gaps without operator baseline."

## Confidence Handling
- If a page's `word_count` is below 100, mark its topics as `[LOW CONTENT — may be incomplete page]`.
- If the operator has only 1 scraped page, note: "Operator baseline is thin. Gaps may reflect incomplete crawl, not actual content absence."
- Topic extraction from headings is heuristic. Annotate any gap with fewer than 2 heading-level signals as `[INFERRED]`.
