---
name: schema-audit
description: Audit structured data quality on listing pages. Reports schema.org coverage, missing types, and SEO exposure gaps across competitor domains.
type: analysis
version: 1
---

# Schema Audit

## Purpose
Evaluate structured data quality on listing_detail pages. Identify which competitors lack machine-readable schema markup and quantify the SEO exposure gap. Output is a per-domain schema coverage report.

## When to Use
- After the normalize step has produced SchemaObservation records for a run.
- When the operator wants to understand SEO vulnerability of competitors.
- As a sub-analysis to feed into `competitor-gap-scan` or `business-vs-competitors`.

## Required Inputs
- `run_id`
- `metro`
- `schema_observations` — SchemaObservation records for all listing_detail pages in the run
- `source_pages` — corresponding SourcePage records (for URL and domain context)

## Steps
1. Filter to listing_detail pages only.
2. For each domain, count pages with `has_structured_data: true` vs. false.
3. For pages with structured data, extract schema_types_found.
4. Classify each page: `strong` (has LodgingBusiness, Accommodation, or Product), `partial` (has structured data but not a lodging type), `none` (no structured data).
5. Rank domains by percentage of listing pages with `none` classification (descending — highest gap first).

## Output Contract
```
## Schema Audit — [metro] — Run [run_id]

### Coverage Summary
| Domain | Listing Pages | Strong | Partial | None | Gap % |
|--------|--------------|--------|---------|------|-------|
| ...    | ...          | ...    | ...     | ...  | ...   |

### Pages with No Structured Data (top 10 by priority)
| Domain | URL | Title Present | Meta Description |
|--------|-----|--------------|-----------------|
| ...    | ... | ...          | ...             |

### Observation
[One sentence: which domain has the worst schema coverage and what schema types were found vs expected.]
```

The "Observation" must be a factual statement derivable from the table — not marketing language.

## Forbidden Behavior
- Do not recommend specific schema markup to add — that is out of scope for this audit.
- Do not evaluate pages other than listing_detail.
- Do not invent schema_types_found if SchemaObservation.has_structured_data is false.
- Do not include pages with `http_status` other than 200.
- Do not produce the audit if schema_observations is empty — return: "No SchemaObservation records for run [run_id]. Run normalize step first."

## Confidence Handling
- Schema detection is derived from HTML parsing. If `raw_html` was null for a page, SchemaObservation will be null — exclude those pages from percentages and note the exclusion count at the bottom of the report.
- If a domain has only 1 listing page audited, note: "[domain]: single-page sample — coverage % may not be representative."
