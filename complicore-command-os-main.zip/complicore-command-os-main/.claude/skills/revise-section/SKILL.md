---
name: revise-section
description: Revise a single section of any v1 output (brief, compliance log, growth report, acquisition list) based on reviewer feedback. Preserve what is correct. Change only what feedback targets.
type: workflow
version: 1
---

# Revise Section

## Purpose
Apply targeted revisions to a single section of an approved or draft output. Used when a reviewer flags a paragraph, finding, or table row for correction. Does not regenerate the entire output — only the flagged section.

## When to Use
- When a reviewer marks a paragraph `needs_review` with specific feedback.
- When a finding's description must be reworded without changing the underlying evidence.
- When the output contract requires a re-run of one section after new findings are approved.

Do not use this skill to revise evidence (snippets, source URLs). Evidence changes require the original finding record to be updated before the section is re-run.

## Required Inputs
- `output_type` — one of: "weekly_brief_section" | "compliance_finding_row" | "acquisition_target_row" | "growth_gap_item" | "outbound_brief_paragraph"
- `section_identifier` — section title, paragraph index, or row ID
- `current_content` — the text being revised (verbatim)
- `reviewer_feedback` — the specific instruction from the reviewer
- `supporting_evidence` — finding_ids or gap_ids that the revised content must still cite
- `run_id`

## Steps
1. Read the current_content and the reviewer_feedback.
2. Identify exactly what must change — no more, no less.
3. Verify the revision does not remove any citation from `supporting_evidence`.
4. Apply the revision.
5. State what changed and why in the change log.

## Output Contract
```
## Section Revision — [output_type] — [section_identifier]
Run: [run_id]

### Original
[verbatim current_content]

### Revised
[revised content]

### Change Log
- What changed: [specific description]
- Why: [reviewer feedback that drove it]
- Citations preserved: [list of finding_ids still present — must match supporting_evidence]
- Citations removed: [none — or flag if any were removed]

### Reviewer Action Required
[none — or flag if the revision introduced new claims needing approval]
```

## Forbidden Behavior
- Do not revise evidence fields (snippet, source_url, screenshot_ref) — these are immutable once a finding is created.
- Do not remove citations unless the reviewer explicitly authorizes it.
- Do not add new claims that are not supported by `supporting_evidence`.
- Do not regenerate the full output — revise only the flagged section.
- Do not mark the section "approved" — that is the reviewer's action.
- Do not apply a revision that contradicts the output contract of the parent skill.

## Confidence Handling
- If the revision is ambiguous (reviewer feedback could be interpreted multiple ways), do not guess. Return: "Feedback is ambiguous: '[feedback]'. Please clarify: [option A] or [option B]?"
- If the revision requires removing a citation and the reviewer has not explicitly authorized it, flag: "Removing citation [finding_id] requires reviewer authorization — not applied."
