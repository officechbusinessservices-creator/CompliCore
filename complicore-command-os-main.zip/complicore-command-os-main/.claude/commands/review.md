Review the specified code, finding, output, or document against CompliCore Command OS standards.

Rules:
- Read the relevant file(s) before reviewing. Do not review from memory.
- Every issue must cite: file path, line number or section, and what the violation is.
- Do not flag style preferences — flag correctness, evidence gaps, schema violations, and constraint breaches only.
- If a finding has no evidence citation, flag it as INVALID — not NEEDS-REVIEW.
- If code writes to the DB without schema validation, flag as HIGH.
- If a rule produces a finding without a source_page reference, flag as HIGH.
- If output would be published without reviewer sign-off, flag as CRITICAL.

Severity levels:
- CRITICAL — blocks merge; violates core constraint (fake data, no evidence, unapproved publish)
- HIGH — likely incorrect or unsafe; must be fixed before phase is DONE
- NEEDS-REVIEW — ambiguous; surface to human reviewer before proceeding
- LOW — minor; fix if in scope, defer otherwise

Output format:
## Summary
One-paragraph verdict.

## Findings
| Severity | Location | Issue |
|----------|----------|-------|

## Recommendation
Approve / Revise / Block — with one-sentence rationale.
