Evaluate the evidence quality of a compliance finding, growth signal, or acquisition target.

Purpose: Before any finding is published or included in a weekly brief, it must pass evidence evaluation. This command scores the evidence behind a single finding.

Inputs expected:
- The finding text or record
- The source_page id(s) cited
- The rule family that produced it (if applicable)

Evaluation criteria:
1. Source — Is the source a real, publicly accessible URL? (not inferred, not assumed)
2. Quote — Is there a verbatim extract from the source that supports the finding?
3. Rule match — Does the finding map to a named rule family in docs/rules-engine.md?
4. Recency — Is the source_page scraped_at timestamp within the current run window?
5. Reproducibility — Could another reviewer reach the same conclusion from the same source?

Scoring:
- STRONG — all 5 criteria met
- SUFFICIENT — criteria 1, 2, 3 met; 4 or 5 may be partially met
- WEAK — criteria 1 and 2 met but rule match is absent or strained
- INSUFFICIENT — source missing, quote missing, or finding is inferred without evidence

Output:
- Score: STRONG / SUFFICIENT / WEAK / INSUFFICIENT
- Criteria table (criterion, met/not met, note)
- Publish verdict: APPROVED / NEEDS-REVIEW / BLOCKED
  - INSUFFICIENT → always BLOCKED
  - WEAK → NEEDS-REVIEW (human reviewer must approve)
  - SUFFICIENT or STRONG → APPROVED

Do not modify the finding. Evaluate only. Flag for revision if blocked.
