Produce a phased implementation plan for the requested feature or phase of CompliCore Command OS.

Rules:
- Read MANIFEST.md and CLAUDE.md before planning.
- Scope to v1 constraints: one metro, one operator profile, public web only, reviewer-gated outputs, evidence-backed findings only.
- Do not plan anything in the non-goals list (payments, booking engine, mobile app, global compliance engine, plugin marketplace, unverified third-party packages).
- Show plan before any execution. Never execute without an approved plan.
- Define DONE as a checklist of verifiable, concrete conditions — not feelings or intentions.
- Flag uncertainty as NEEDS-REVIEW rather than guessing.
- Keep each phase scoped to one clear outcome.

Output format:
1. Goal — one sentence
2. Tasks — ordered list, specific to the phase
3. DONE definition — checklist, every item testable
4. Risks — table with likelihood, impact, mitigation
5. What is explicitly out of scope for this phase

Stop after the plan. Do not write code.
