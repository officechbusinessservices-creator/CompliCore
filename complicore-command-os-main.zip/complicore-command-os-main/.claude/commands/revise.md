Revise an existing plan, finding, output, or document based on new information or feedback.

Rules:
- Read the existing artifact before revising. Do not rewrite from scratch unless the existing content is structurally broken.
- Revise, do not redo. Preserve what is correct. Only change what the feedback targets.
- State what changed and why at the end of the revision. Be specific.
- If the revision conflicts with a v1 constraint (one metro, public web only, evidence-backed, reviewer-gated), flag the conflict as NEEDS-REVIEW before applying.
- If the requested revision adds scope beyond v1, note it as OUT OF SCOPE and do not include it unless explicitly approved.
- If revising a DONE definition, every new condition must be testable and concrete.

Output format:
## What Changed
Bulleted list — each item states the section revised and the reason.

## Revised Artifact
Full revised content (replace the original entirely).

## Conflicts or Flags
Any NEEDS-REVIEW items or out-of-scope additions identified during revision.
